#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "algorithm_port.h"
#ifndef PORT_SOURCE
#error PORT_SOURCE must name hrrr_lrmap_port.c
#endif
#include PORT_SOURCE

static int16_t qraw(double x, double s) {
    long v = lround(x / s);
    if (v > 32767)
        v = 32767;
    if (v < -32768)
        v = -32768;
    return (int16_t)v;
}

int main(int argc, char **argv) {
    if (argc < 3) {
        fprintf(stderr, "usage: %s raw_imu.csv out.csv\n", argv[0]);
        return 2;
    }
    FILE *fi = fopen(argv[1], "r");
    if (!fi) {
        perror("input");
        return 2;
    }
    FILE *fo = fopen(argv[2], "w");
    if (!fo) {
        perror("output");
        return 2;
    }
    char line[4096];
    if (!fgets(line, sizeof(line), fi))
        return 2;
    Monitor_HRRR_Init();
    fprintf(fo, "wall_t,front_t,signal_present,front_samples,estimating,moving,hr_valid,hr_bpm,hr_"
                "conf,rr_valid,rr_bpm,rr_conf,rest,publish\n");
    long rows = 0;
    MonitorAlgorithmOutput_t out = {0};
    while (fgets(line, sizeof(line), fi)) {
        char *p = line, *end;
        double vals[8];
        int ok = 1;
        for (int i = 0; i < 8; i++) {
            vals[i] = strtod(p, &end);
            if (end == p) {
                ok = 0;
                break;
            }
            p = end;
            if (i < 7) {
                if (*p != ',') {
                    ok = 0;
                    break;
                }
                p++;
            }
        }
        if (!ok)
            continue;
        MonitorImuSample_t s = {0};
        s.sample_index = (uint32_t)rows;
        s.ax = qraw(vals[2], 0.000061);
        s.ay = qraw(vals[3], 0.000061);
        s.az = qraw(vals[4], 0.000061);
        s.gx = qraw(vals[5], 0.00875);
        s.gy = qraw(vals[6], 0.00875);
        s.gz = qraw(vals[7], 0.00875);
        Monitor_HRRR_OnSample(&s);
        rows++;
        while (Monitor_HRRR_ServicePending())
            Monitor_HRRR_Process(&out);
        Monitor_HRRR_Process(&out);
        if ((rows % 200) == 0) {
            fprintf(fo, "%.2f,%.2f,%u,%u,%u,%u,%u,%.9g,%u,%u,%.9g,%u,%u,%u\n", rows / 100.0,
                    McuHrrrFrontend_TimeS(&g_lrmap_state.front), g_signal_present,
                    (unsigned)g_lrmap_state.front.sample_count, out.estimating, out.moving,
                    out.hr_valid, out.hr_bpm, out.hr_confidence_percent, out.rr_valid, out.rr_brpm,
                    out.rr_confidence_percent, g_lrmap_state.rest_dec.rest,
                    g_lrmap_state.rest_dec.publish);
        }
    }
    fclose(fi);
    fclose(fo);
    fprintf(stderr, "samples=%ld wall_ticks=%ld front=%u signal=%u\n", rows, rows / 200,
            (unsigned)g_lrmap_state.front.sample_count, g_signal_present);
    return 0;
}
