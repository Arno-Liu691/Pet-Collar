#!/usr/bin/env python3
"""Full reproducible comparison: original Full-C PC algorithm vs final MCU production port vs V6/offline reference.

This script intentionally reruns both C implementations. Reference files are attached only after inference.
The final MCU host path compiles the actual production `hrrr_lrmap_port.c` and production HR/RR sources,
including LSM6DSOX int16 quantisation, PresenceGate, rest/severe logic, staged computation and CMSIS-DSP.

Example:
  python run_full_dataset_and_compare.py \
    --pc-root Pet_Collar_LRMAP_FullC_Reproducible_Final \
    --mcu-root Pet_Collar_Monitoring_CGU6_ProductionBLE_MotionStatus \
    --out validation_out

Requirements: Python 3, numpy, pandas, matplotlib, gcc, bash/sh.
"""

from __future__ import annotations
import argparse, subprocess, sys
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent


def nearest(ref: pd.DataFrame, t: np.ndarray) -> pd.DataFrame:
    rt = ref["time_s"].to_numpy(float)
    idx = np.searchsorted(rt, t, "left")
    idx = np.clip(idx, 0, len(rt) - 1)
    left = np.maximum(idx - 1, 0)
    idx = np.where(np.abs(rt[left] - t) <= np.abs(rt[idx] - t), left, idx)
    return ref.iloc[idx].reset_index(drop=True)


def safe_div(a, b):
    return float(a / b) if b else 0.0


def vital_metrics(split, seg, domain, vital, pc, mcu, ref, mval, mvalid):
    t = mcu.wall_t.to_numpy(float)
    rv = ref.output_valid.astype(bool).to_numpy()
    lo = ref.range_low.to_numpy(float)
    hi = ref.range_high.to_numpy(float)
    # Use the original PC-C package's authoritative eligibility definition.
    eligible = pc.rest_ready.astype(bool).to_numpy() & rv
    pf = pc.formal.astype(bool).to_numpy()
    mf = mcu[mvalid].astype(bool).to_numpy()
    pv = pc.tracked.to_numpy(float)
    mv = mcu[mval].to_numpy(float)
    pcok = pf & eligible & (pv >= lo) & (pv <= hi)
    mcok = mf & eligible & (mv >= lo) & (mv <= hi)
    both = pf & mf
    dd = np.abs(pv[both] - mv[both])
    return dict(
        split=split,
        segment_id=seg,
        domain=domain,
        vital=vital,
        ticks=len(t),
        eligible_n=int(eligible.sum()),
        pc_formal_n=int((pf & eligible).sum()),
        mcu_formal_n=int((mf & eligible).sum()),
        pc_correct_n=int(pcok.sum()),
        mcu_correct_n=int(mcok.sum()),
        pc_coverage=safe_div((pf & eligible).sum(), eligible.sum()),
        mcu_coverage=safe_div((mf & eligible).sum(), eligible.sum()),
        pc_strict_accuracy=safe_div(pcok.sum(), (pf & eligible).sum()),
        mcu_strict_accuracy=safe_div(mcok.sum(), (mf & eligible).sum()),
        both_formal_n=int(both.sum()),
        mean_abs_mcu_vs_pc_bpm=float(dd.mean()) if len(dd) else np.nan,
        median_abs_mcu_vs_pc_bpm=float(np.median(dd)) if len(dd) else np.nan,
        max_abs_mcu_vs_pc_bpm=float(dd.max()) if len(dd) else np.nan,
        pc_only_formal_n=int((pf & ~mf).sum()),
        mcu_only_formal_n=int((mf & ~pf).sum()),
    )


def make_combined(t, mcu, pch, pcr, rh, rr):
    out = pd.DataFrame(
        {
            "time_s": t,
            "signal_present": mcu.signal_present,
            "front_samples": mcu.front_samples,
            "rest": mcu.rest,
            "publish": mcu.publish,
            "moving": mcu.moving,
            "pc_hr_tracked": pch.tracked,
            "pc_hr_formal": pch.formal,
            "mcu_hr_bpm": mcu.hr_bpm,
            "mcu_hr_formal": mcu.hr_valid,
            "v6_hr_reference": rh.estimate,
            "v6_hr_low": rh.range_low,
            "v6_hr_high": rh.range_high,
            "v6_hr_valid": rh.output_valid,
            "pc_rr_tracked": pcr.tracked,
            "pc_rr_formal": pcr.formal,
            "mcu_rr_bpm": mcu.rr_bpm,
            "mcu_rr_formal": mcu.rr_valid,
            "v6_rr_reference": rr.estimate,
            "v6_rr_low": rr.range_low,
            "v6_rr_high": rr.range_high,
            "v6_rr_valid": rr.output_valid,
        }
    )
    return out


def plot_segment(split, seg, t, mcu, pch, pcr, rh, rr, path):
    fig, axs = plt.subplots(2, 1, figsize=(13, 8), sharex=True)
    for name, ax, pc, ref, mval, mvalid, unit in [
        ("HR", axs[0], pch, rh, "hr_bpm", "hr_valid", "bpm"),
        ("RR", axs[1], pcr, rr, "rr_bpm", "rr_valid", "brpm"),
    ]:
        ax.fill_between(t, ref.range_low, ref.range_high, alpha=0.18, label="V6 accepted range")
        ax.plot(t, ref.estimate, "--", linewidth=1.3, label="V6/offline reference")
        ax.plot(t, pc.tracked, linewidth=1.25, label="Original PC-C tracked")
        pf = pc.formal.astype(bool).to_numpy()
        ax.scatter(t[pf], pc.loc[pf, "tracked"], s=13, label="Original PC-C formal")
        mf = mcu[mvalid].astype(bool).to_numpy()
        ax.plot(
            t[mf],
            mcu.loc[mf, mval],
            marker="o",
            markersize=3,
            linewidth=1.3,
            label="Final MCU formal",
        )
        ax.set_ylabel(f"{name} ({unit})")
        ax.set_title(f"{seg} | {split} | {name}")
        ax.grid(alpha=0.2)
        ax.legend(fontsize=8, ncol=2)
    axs[1].set_xlabel("Time (s)")
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=175)
    plt.close(fig)


def aggregate(d: pd.DataFrame, keys):
    rows = []
    groups = d.groupby(keys, dropna=False) if keys else [((), d)]
    for k, s in groups:
        if not isinstance(k, tuple):
            k = (k,)
        base = {keys[i]: k[i] for i in range(len(keys))}
        for vital, v in s.groupby("vital"):
            E = int(v.eligible_n.sum())
            pf = int(v.pc_formal_n.sum())
            mf = int(v.mcu_formal_n.sum())
            pc = int(v.pc_correct_n.sum())
            mc = int(v.mcu_correct_n.sum())
            rows.append(
                {
                    **base,
                    "vital": vital,
                    "eligible_n": E,
                    "pc_formal_n": pf,
                    "mcu_formal_n": mf,
                    "pc_correct_n": pc,
                    "mcu_correct_n": mc,
                    "pc_coverage": safe_div(pf, E),
                    "mcu_coverage": safe_div(mf, E),
                    "pc_strict_accuracy": safe_div(pc, pf),
                    "mcu_strict_accuracy": safe_div(mc, mf),
                    "pc_only_formal_n": int(v.pc_only_formal_n.sum()),
                    "mcu_only_formal_n": int(v.mcu_only_formal_n.sum()),
                }
            )
    return pd.DataFrame(rows)


def summary_plot(overall: pd.DataFrame, vital: str, metric: str, path: Path):
    s = overall[overall.vital == vital].iloc[0]
    vals = [s[f"pc_{metric}"], s[f"mcu_{metric}"]]
    fig, ax = plt.subplots(figsize=(5.5, 4))
    ax.bar(["Original PC-C", "Final MCU"], vals)
    ax.set_ylim(0, 1.05)
    ax.set_ylabel(metric.replace("_", " ").title())
    ax.set_title(f'{vital.upper()} {metric.replace("_"," ")} vs V6/offline reference')
    for i, v in enumerate(vals):
        ax.text(i, v + 0.018, f"{100*v:.2f}%", ha="center")
    ax.grid(axis="y", alpha=0.2)
    fig.tight_layout()
    fig.savefig(path, dpi=175)
    plt.close(fig)


def main(pc_root: Path, mcu_root: Path, out: Path):
    pc_root = pc_root.resolve()
    mcu_root = mcu_root.resolve()
    out = out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    pc_out = out / "pc_c_original"
    mcu_out = out / "mcu_final"
    plots = out / "plots"
    combined = out / "combined"
    plots.mkdir(exist_ok=True)
    combined.mkdir(exist_ok=True)
    subprocess.run(
        [
            sys.executable,
            str(pc_root / "scripts" / "reproduce_all_c.py"),
            "--output-root",
            str(pc_out),
            "--no-plots",
        ],
        cwd=pc_root,
        check=True,
    )
    exe = out / "mcu_final_replay"
    subprocess.run([str(HERE / "build_final_mcu_host.sh"), str(mcu_root), str(exe)], check=True)
    manifest = pd.read_csv(pc_root / "dataset" / "SPLIT_MANIFEST.csv")
    rows = []
    for _, r in manifest.iterrows():
        split = str(r["split"])
        seg = str(r["segment_id"])
        domain = str(r.get("domain", ""))
        (mcu_out / split).mkdir(parents=True, exist_ok=True)
        subprocess.run(
            [
                str(exe),
                str(pc_root / "dataset" / split / seg / "input" / "raw_imu.csv"),
                str(mcu_out / split / f"{seg}.csv"),
            ],
            check=True,
        )
        pch = pd.read_csv(pc_out / split / seg / "hr_output.csv")
        pcr = pd.read_csv(pc_out / split / seg / "rr_output.csv")
        mcu = pd.read_csv(mcu_out / split / f"{seg}.csv")
        t = mcu.wall_t.to_numpy(float)
        rh = nearest(
            pd.read_csv(pc_root / "dataset" / split / seg / "reference" / "hr_reference.csv"), t
        )
        rr = nearest(
            pd.read_csv(pc_root / "dataset" / split / seg / "reference" / "rr_reference.csv"), t
        )
        rows += [
            vital_metrics(split, seg, domain, "hr", pch, mcu, rh, "hr_bpm", "hr_valid"),
            vital_metrics(split, seg, domain, "rr", pcr, mcu, rr, "rr_bpm", "rr_valid"),
        ]
        c = make_combined(t, mcu, pch, pcr, rh, rr)
        (combined / split).mkdir(parents=True, exist_ok=True)
        c.to_csv(combined / split / f"{seg}_comparison.csv", index=False)
        plot_segment(split, seg, t, mcu, pch, pcr, rh, rr, plots / split / f"{seg}.png")
    d = pd.DataFrame(rows)
    d.to_csv(out / "comparison_by_segment.csv", index=False)
    overall = aggregate(d, [])
    overall.to_csv(out / "comparison_overall.csv", index=False)
    bysplit = aggregate(d, ["split"])
    bysplit.to_csv(out / "comparison_by_split.csv", index=False)
    for vital in ["hr", "rr"]:
        for metric in ["coverage", "strict_accuracy"]:
            summary_plot(overall, vital, metric, plots / f"summary_{vital}_{metric}.png")
    print(overall.to_string(index=False))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--pc-root", type=Path, required=True)
    ap.add_argument("--mcu-root", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    a = ap.parse_args()
    main(a.pc_root, a.mcu_root, a.out)
