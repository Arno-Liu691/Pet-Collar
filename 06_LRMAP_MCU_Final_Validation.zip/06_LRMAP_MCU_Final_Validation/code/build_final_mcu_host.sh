#!/usr/bin/env bash
set -euo pipefail
if [ $# -lt 2 ]; then
  echo "Usage: $0 <final_mcu_project_root> <output_binary>" >&2
  exit 2
fi
MCU=$(cd "$1" && pwd)
OUT="$2"
HERE=$(cd "$(dirname "$0")" && pwd)
PORT="$MCU/Core/Src/hrrr_lrmap_port.c"
gcc -O3 -std=c11 \
  -DPORT_SOURCE='"'"$PORT"'"' \
  -I"$MCU/Core/Inc" \
  -I"$MCU/Core/HRRR/full_pipeline" \
  -I"$MCU/Core/HRRR/algorithm" \
  -I"$MCU/Core/HRRR/generated" \
  -I"$MCU/Core/CMSIS_DSP/Include" \
  -I"$MCU/Core/CMSIS_DSP/PrivateInclude" \
  -I"$MCU/Drivers/CMSIS/Include" \
  "$HERE/host_mcu_port_replay.c" \
  "$MCU/Core/HRRR/full_pipeline/mcu_filters.c" \
  "$MCU/Core/HRRR/full_pipeline/mcu_hrrr_frontend.c" \
  "$MCU/Core/HRRR/full_pipeline/mcu_hrrr_full.c" \
  "$MCU/Core/HRRR/full_pipeline/mcu_dsp_core.c" \
  "$MCU/Core/HRRR/algorithm/mcu_rest_detector.c" \
  "$MCU/Core/HRRR/algorithm/mcu_hrrr_lrmap.c" \
  "$MCU/Core/HRRR/generated/mcu_lr_models.c" \
  "$MCU/Core/CMSIS_DSP/Source/CommonTables/arm_common_tables.c" \
  "$MCU/Core/CMSIS_DSP/Source/CommonTables/arm_const_structs.c" \
  "$MCU/Core/CMSIS_DSP/Source/TransformFunctions/arm_cfft_f32.c" \
  "$MCU/Core/CMSIS_DSP/Source/TransformFunctions/arm_cfft_radix8_f32.c" \
  "$MCU/Core/CMSIS_DSP/Source/TransformFunctions/arm_rfft_fast_f32.c" \
  "$MCU/Core/CMSIS_DSP/Source/TransformFunctions/arm_bitreversal2.c" \
  "$MCU/Core/CMSIS_DSP/Source/TransformFunctions/arm_rfft_fast_init_f32.c" \
  "$MCU/Core/CMSIS_DSP/Source/TransformFunctions/arm_cfft_init_f32.c" \
  -lm -o "$OUT"
echo "Built: $OUT"
