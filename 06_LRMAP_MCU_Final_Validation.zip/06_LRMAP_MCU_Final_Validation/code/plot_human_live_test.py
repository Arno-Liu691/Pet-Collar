#!/usr/bin/env python3
"""Plot final MCU live Feature-result CSV with the 7-state monitor status.

Example:
  python plot_human_live_test.py --features features.csv --out human_live_test.png

The optional manual respiration band is expressed as seconds per breath.
Default 3.5--4.5 s/breath -> 13.33--17.14 brpm.
"""

from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

STATUS_ORDER = [
    "NO_SIGNAL",
    "MOVING",
    "REST_PENDING",
    "MEASURING",
    "REST_VALID",
    "DISTURBANCE",
    "SEVERE_RECOVERY",
]


def pick_time(df: pd.DataFrame) -> np.ndarray:
    for c in ["recording_relative_time_s", "source_elapsed_time_s", "device_time_s_100hz"]:
        if c in df.columns:
            return pd.to_numeric(df[c], errors="coerce").to_numpy(float)
    return np.arange(len(df), dtype=float)


def valid_series(df, key):
    aliases = {"hr": ["hr", "hr_bpm"], "rr": ["rr", "rr_brpm"]}
    col = next((c for c in aliases.get(key, [key]) if c in df.columns), None)
    if col is None:
        raise KeyError(f"No column found for {key}: {aliases.get(key,[key])}")
    x = pd.to_numeric(df[col], errors="coerce").to_numpy(float)
    # Recorder stores invalid vitals as NaN in the production app; dedicated valid flags are also accepted.
    vcol = f"{key}_valid"
    if vcol in df.columns:
        v = df[vcol].astype(bool).to_numpy()
    else:
        v = np.isfinite(x) & (x > 0)
    return x, v


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--features", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument(
        "--breath-min-s", type=float, default=3.5, help="Shortest manually observed breath period"
    )
    ap.add_argument(
        "--breath-max-s", type=float, default=4.5, help="Longest manually observed breath period"
    )
    a = ap.parse_args()
    df = pd.read_csv(a.features)
    t = pick_time(df)
    hr, hv = valid_series(df, "hr")
    rr, rv = valid_series(df, "rr")
    if "motion_status" in df.columns:
        s = df["motion_status"].fillna("NO_SIGNAL").astype(str)
    elif "motion_status_code" in df.columns:
        s = df["motion_status_code"].map(dict(enumerate(STATUS_ORDER))).fillna("NO_SIGNAL")
    else:
        s = pd.Series(["NO_SIGNAL"] * len(df))
    si = np.array([STATUS_ORDER.index(x) if x in STATUS_ORDER else 0 for x in s], dtype=int)
    lo = 60.0 / a.breath_max_s
    hi = 60.0 / a.breath_min_s
    fig, axs = plt.subplots(
        3, 1, figsize=(13, 8.4), sharex=True, gridspec_kw={"height_ratios": [1, 1, 0.62]}
    )
    axs[0].plot(t[hv], hr[hv], marker="o", markersize=2, linewidth=1.4)
    axs[0].set_ylabel("HR (bpm)")
    axs[0].set_title("Final MCU live human test")
    axs[0].grid(alpha=0.2)
    axs[1].axhspan(
        lo, hi, alpha=0.16, label=f"Manual breathing: {a.breath_min_s:g}-{a.breath_max_s:g} s/cycle"
    )
    axs[1].plot(t[rv], rr[rv], marker="o", markersize=2, linewidth=1.4)
    axs[1].set_ylabel("RR (brpm)")
    axs[1].grid(alpha=0.2)
    axs[1].legend(loc="upper right")
    axs[2].step(t, si, where="post")
    axs[2].set_yticks(range(len(STATUS_ORDER)), STATUS_ORDER)
    axs[2].set_ylabel("Status")
    axs[2].set_xlabel("Recording time (s)")
    axs[2].grid(alpha=0.2)
    fig.tight_layout()
    a.out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(a.out, dpi=180)
    plt.close(fig)


if __name__ == "__main__":
    main()
