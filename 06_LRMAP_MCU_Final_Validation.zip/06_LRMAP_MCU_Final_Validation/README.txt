LRMAP_MCU_Final_Validation_20260817

Documentation:
  README.txt and RUN_COMMANDS.txt describe the reproducible comparison.
  SOURCE_DIFF_CORE_SUMMARY.txt records the production-port source scope.

Reproduction code:
  code/host_mcu_port_replay.c
  code/build_final_mcu_host.sh
  code/run_full_dataset_and_compare.py
  code/plot_human_live_test.py
  code/requirements.txt

Main result tables:
  results/comparison_overall.csv
  results/comparison_by_split.csv
  results/comparison_by_segment.csv
  results/quantized_core_vs_final_port.csv

Plots:
  plots/development, plots/holdout, plots/challenge : 15 segment comparisons
  plots/summary_*.png : overall metric comparison
  plots/human_live_test10.png : latest live human test

The comparison plots show:
  V6/offline accepted range + reference center
  original PC-C tracked/formal output
  final MCU production-port formal output

Important interpretation:
  The final production wrapper is output-equivalent to the same final quantized optimized core.
  The final MCU is not bit-identical to the initial float PC-C; remaining numerical/path differences are documented, especially D045 RR.
