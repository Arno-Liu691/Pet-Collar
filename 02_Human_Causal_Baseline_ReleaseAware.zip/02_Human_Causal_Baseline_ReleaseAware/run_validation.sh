#!/usr/bin/env bash
set -euo pipefail

bash build_linux.sh
mkdir -p validation/results

for dataset in stable rr_change disruption; do
  ./human_causal_baseline \
    "validation/datasets/${dataset}/input.csv" \
    "validation/results/${dataset}_results.csv"
done

python3 validation/evaluate.py
