# Stage 02 — Human Causal Baseline, Release-Aware

This appendix package contains the causal human IMU baseline used before canine-specific physiological modelling. It estimates resting heart rate (HR) and respiratory rate (RR) from a 100 Hz six-axis IMU stream and is intended as a reproducible engineering baseline rather than a canine or clinical estimator.

## Repository role

Suggested Git path:

```text
algorithms/02_Human_Causal_Baseline_ReleaseAware/
```

The stage establishes the first complete causal pipeline used later in the project:

```text
6-axis IMU
  -> rest opportunity detection
  -> acceleration preprocessing and 25 Hz storage
  -> RR candidate estimation
  -> HR multi-candidate evidence
  -> release-aware temporal tracking
  -> SQI and motion-aware reportability
```

The key architectural contribution is the separation between a current-window candidate, a tracked physiological path, signal quality, and user-facing reportability.

## Input and operating profile

- Input sampling rate: 100 Hz.
- Input channels: acceleration X/Y/Z in g; gyroscope X/Y/Z in deg/s.
- Vital-rate processing rate: 25 Hz after anti-alias smoothing and 4:1 decimation.
- HR search range: 60–120 bpm.
- RR search range: 8–32 brpm.
- HR window: 18 s.
- RR window: 10 s.
- Estimate cadence: 1 s after the shared 18 s ring is ready.
- HR preprocessing: first difference of detrended acceleration.
- RR preprocessing: detrended acceleration.
- Gyroscope use: rest detection and motion-quality assessment.

## Main source files

```text
algorithm/rest_detector.c
algorithm/rest_detector.h
algorithm/vital_estimator.c
algorithm/vital_estimator.h
src/main_pc.c
src/csv_reader.c
include/csv_reader.h
```

`METHOD_SPECIFICATION.md` records the algorithm parameters and decision structure. The `validation/` directory contains the three human development/regression recordings used to verify the frozen stage behaviour.

## Build

Linux:

```bash
bash build_linux.sh
```

Windows with MinGW:

```bat
build_windows.bat
```

Run:

```bash
./human_causal_baseline input.csv output.csv
```

Input columns:

```text
sample_index,time_s,ax,ay,az,gx,gy,gz
```

## Validation

```bash
bash run_validation.sh
```

The script rebuilds the current source, runs the stable, RR-change and disruption recordings, and writes:

```text
validation/results/metrics_summary.csv
```

These recordings are development/regression evidence. They are not an independent holdout and do not establish canine accuracy.
