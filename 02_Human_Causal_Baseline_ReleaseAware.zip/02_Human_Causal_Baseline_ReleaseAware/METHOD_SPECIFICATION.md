# Stage 02 — Method Specification

## Signal path

| Item | Definition |
|---|---|
| Input | 100 Hz, ax/ay/az [g], gx/gy/gz [deg/s] |
| Internal vital-rate sampling | 25 Hz, 4:1 decimation |
| Gravity EMA alpha | 0.003328 |
| Anti-alias EMA alpha | 0.34065 |
| Stored scale | 131072 |
| HR input | First difference of detrended acceleration |
| RR input | Detrended acceleration |
| Vital axes | Accelerometer X/Y/Z |
| Gyroscope role | Rest detection and motion context |
| HR search | 60–120 bpm, 1 bpm grid |
| RR search | 8–32 brpm, 1 brpm grid |
| HR window | 18 s |
| RR window | 10 s |
| Estimate cadence | 1 s |
| Shared acceleration ring | 18 s XYZ int16_t, 2700 bytes |

## Rest detector

A two-second local motion window is evaluated once per second. Thirty seconds of local labels are retained.

Clean-window limits:

- gyro p95 <= 35 deg/s;
- gyro RMS <= 20 deg/s;
- acceleration-magnitude standard deviation <= 0.030 g;
- acceleration-magnitude range <= 0.35 g;
- jerk p95 <= 3.0 g/s.

Strong-motion exit is triggered by any of:

- gyro maximum >= 250 deg/s;
- gyro p95 >= 150 deg/s;
- acceleration range >= 2.0 g;
- jerk p95 >= 30 g/s.

State rules:

- enter pending when 10 s clean ratio >= 0.75;
- enter measurement when 20 s clean ratio >= 0.75 or 10 s clean ratio >= 0.85;
- leave measurement on strong motion, five consecutive disturbances, or 10 s clean ratio < 0.45.

The rest detector determines whether a measurement opportunity exists. It does not prove that an HR/RR estimate is valid.

## Vital motion context

The vital estimator applies a second motion-quality layer while measurement remains active.

- Moderate: acceleration range >= 0.25 g, jerk p95 >= 3.5 g/s, or gyro p95 >= 35 deg/s. Motion quality = 0.18 and a 10 s recovery hold is applied.
- Mild: disturbance, acceleration range >= 0.05 g, jerk p95 >= 1.5 g/s, or gyro p95 >= 8 deg/s. Motion quality = 0.48 with a minimum 2 s hold.
- Low-amplitude sway: gyro p95 >= 3 deg/s or gyro RMS >= 1.8 deg/s. Motion quality = 0.90.
- During the 10 s recovery hold, the quality cap is 0.38 in the first half and 0.58 in the second half.

## Candidate quality

SNR quality:

- HR: clamp((SNR - 2.2) / 6.8)
- RR: clamp((SNR - 1.8) / 7.0)

Prominence quality:

- clamp((prominence - 1.0) / 1.2)

Base HR candidate quality:

```text
0.34*SNR + 0.20*prominence + 0.08*axis_support
+ 0.25*continuity + 0.13*harmonic_quality
```

HR transition quality:

```text
0.44*SNR + 0.24*prominence + 0.10*axis_support
+ 0.22*harmonic_quality
```

Base RR candidate quality:

```text
0.36*SNR + 0.24*prominence + 0.08*axis_support
+ 0.24*continuity + 0.08*harmonic_quality
```

RR transition quality:

```text
0.48*SNR + 0.27*prominence + 0.10*axis_support
+ 0.15*harmonic_quality
```

## HR structural evidence

The 18 s HR window is also evaluated as two 9 s halves. An 8 s recent window provides change-sensitive evidence.

Half consistency:

```text
0.38*frequency_agreement
+ 0.18*centre_agreement
+ 0.18*amplitude_agreement
+ 0.26*split_presence
```

Recent consistency:

```text
0.35*local_presence
+ 0.15*local_frequency_agreement
+ 0.50*recent_global_frequency_agreement
```

Periodicity uses normalized autocorrelation near one and two candidate periods with approximately 0.70/0.30 weighting.

Peak shape combines local spectral contrast and half-power width with 0.70/0.30 weighting.

Structural quality:

```text
0.22*half_consistency
+ 0.30*recent_consistency
+ 0.18*peak_shape
+ 0.12*axis_support
+ 0.18*periodicity
```

Evidence quality:

```text
0.64*transition_quality + 0.36*structural_quality
```

## RR-to-HR harmonic evidence

RR is estimated before HR. HR candidates are compared with integer multiples of RR for k = 2..12 using a 2.5 bpm tolerance. Harmonic support is treated as graded evidence rather than a hard rejection rule.

Base harmonic quality by multiplier:

- k <= 2: 0.20;
- k = 3: 0.25;
- k = 4: 0.45;
- k = 5: 0.72;
- k = 6: 0.82;
- k >= 7: 0.96.

The penalty is weakened when RR SQI is low or when the dominant HR and RR axes differ.

## HR tracking and stale-path release

The estimator keeps a spectral anchor separate from the user-facing HR track. A structurally supported challenger can release a contradicted incumbent branch.

Key parameters:

- normal HR step: 2 bpm/s;
- confirmed transition step: 3 bpm/s;
- confirmed release step: 4 bpm/s;
- major-change distance: 8 bpm;
- clear candidate margin: 0.06;
- consensus radius: 12 bpm;
- challenger match tolerance: 4 bpm;
- challenger evidence decay: 0.82 per estimate;
- challenger confirmation: 1.05 accumulated evidence;
- maximum challenger gap: one estimate;
- release support: two hits;
- recent challenger match: <= 6 bpm;
- recent rejection of incumbent: >= 8 bpm;
- minimum release evidence: 0.50;
- recent consistency for release: >= 0.68;
- half consistency for release: >= 0.58;
- structural support: periodicity >= 0.28 or axis support >= 0.55;
- lower-bound protection: challenger > HR minimum + 10 bpm;
- release convergence: anchor within 4 bpm.

## RR tracking

- normal RR step: 2 brpm/s;
- major-change distance: 4 brpm;
- initialization: two consistent observations;
- pending switch: two confirmations;
- transition confirmation SQI: 62.

## SQI and reportability

The final HR SQI combines base candidate quality with half-window, recent-window, peak-shape, periodicity, candidate-margin, axis-stability and accumulated-support terms. Agreement between the selected output and current evidence is applied multiplicatively. Persistent HR/RR harmonic suspicion is subtracted with weight 0.10. Motion quality is applied last.

Thresholds:

- HR VALID: SQI >= 65;
- HR VALID_LOW: SQI >= 45;
- RR VALID: SQI >= 55 and peak power >= 1e-10;
- report hold: up to 4 s;
- moderate or strong motion suppresses reportability.
