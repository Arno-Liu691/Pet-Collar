#!/usr/bin/env bash
set -euo pipefail

gcc -std=c11 -O2 -Wall -Wextra -Wpedantic \
  -Iinclude -Ialgorithm \
  src/main_pc.c src/csv_reader.c \
  algorithm/rest_detector.c algorithm/vital_estimator.c \
  -o human_causal_baseline -lm

echo "Build successful: human_causal_baseline"
