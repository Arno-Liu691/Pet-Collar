# Human development/regression results

Three 100 Hz human recordings are included: stable, RR-change and disruption. Metrics use estimable post-warm-up rows after the shared 18 s ring is ready. Algorithm time `t` is aligned with reference time `t-1`.

## HR reportable

| Recording | Coverage | MAE | Correlation |
|---|---:|---:|---:|
| Stable | 99.5% | 2.58 bpm | 0.631 |
| RR-change | 98.1% | 3.50 bpm | 0.653 |
| Disruption | 69.7% | 4.91 bpm | 0.752 |

## HR accepted (`VALID` + `VALID_LOW`)

| Recording | Coverage | MAE |
|---|---:|---:|
| Stable | 86.9% | 2.35 bpm |
| RR-change | 80.1% | 3.35 bpm |
| Disruption | 48.9% | 4.57 bpm |

## RR reportable versus 10 s trailing RR reference

| Recording | Coverage | MAE | Correlation |
|---|---:|---:|---:|
| Stable | 99.5% | 0.30 brpm | 0.938 |
| RR-change | 96.6% | 0.85 brpm | 0.956 |
| Disruption | 62.9% | 1.08 brpm | 0.738 |

The results establish a human IMU feasibility and causal engineering baseline. They do not establish canine accuracy or clinical performance. The disruption recording demonstrates conservative motion/SQI gating and also shows that a persistent non-cardiac mechanical band can remain a plausible HR candidate.
