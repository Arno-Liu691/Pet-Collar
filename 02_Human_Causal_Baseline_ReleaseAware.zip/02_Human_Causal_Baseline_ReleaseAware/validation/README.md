# Human development/regression validation

This directory contains three 100 Hz human recordings representing stable rest, a controlled respiratory-rate change, and a disruption sequence.

All three recordings influenced method development. They therefore serve as regression evidence, not as an independent holdout.

Run from the package root:

```bash
bash run_validation.sh
```

The evaluation aligns algorithm time `t` with reference time `t-1`, matching the one-second streaming update convention. Coverage is calculated over estimable rows after the shared 18 s acceleration ring is ready and a reference value is available.
