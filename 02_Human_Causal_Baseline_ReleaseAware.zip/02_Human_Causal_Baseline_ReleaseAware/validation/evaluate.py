#!/usr/bin/env python3
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"

DATASETS = {
    "stable": "HR",
    "rr_change": "HR",
    "disruption": "Unnamed: 11",
}


def corr(a, b):
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    if len(a) < 3 or np.std(a) == 0 or np.std(b) == 0:
        return np.nan
    return float(np.corrcoef(a, b)[0, 1])


def metrics(frame, mask, eligible, output_col, reference_col):
    use = mask & eligible & frame[output_col].gt(0)
    err = frame.loc[use, output_col] - frame.loc[use, reference_col]
    return {
        "count": int(use.sum()),
        "eligible_count": int(eligible.sum()),
        "coverage": float(use.sum() / eligible.sum()) if eligible.sum() else np.nan,
        "mae": float(err.abs().mean()) if len(err) else np.nan,
        "rmse": float(np.sqrt(np.mean(err * err))) if len(err) else np.nan,
        "bias": float(err.mean()) if len(err) else np.nan,
        "correlation": corr(frame.loc[use, output_col], frame.loc[use, reference_col]),
    }


rows = []
for name, hr_col in DATASETS.items():
    out = pd.read_csv(RESULTS / f"{name}_results.csv")
    ref = pd.read_csv(ROOT / "datasets" / name / "reference.csv").set_index("time_s")
    mapped = (out["algorithm_time_s"] - 1).round().astype(int)
    out["hr_reference"] = mapped.map(ref[hr_col])
    out["rr_reference"] = mapped.map(ref["rr_10s_trailing_bpm"])

    hr_eligible = out["vital_estimate_returned"].eq(1) & out["hr_reference"].notna()
    rr_eligible = out["vital_estimate_returned"].eq(1) & out["rr_reference"].notna()

    definitions = [
        ("HR_REPORTABLE", out["hr_reportable"].eq(1), hr_eligible, "hr_bpm", "hr_reference"),
        ("HR_VALID", out["hr_valid"].eq(1), hr_eligible, "hr_bpm", "hr_reference"),
        (
            "HR_ACCEPTED",
            out["hr_status"].isin(["VALID", "VALID_LOW"]),
            hr_eligible,
            "hr_bpm",
            "hr_reference",
        ),
        ("RR_REPORTABLE", out["rr_reportable"].eq(1), rr_eligible, "rr_bpm", "rr_reference"),
        ("RR_VALID", out["rr_valid"].eq(1), rr_eligible, "rr_bpm", "rr_reference"),
    ]
    for mode, mask, eligible, output_col, reference_col in definitions:
        rows.append(
            {
                "dataset": name,
                "mode": mode,
                **metrics(out, mask, eligible, output_col, reference_col),
            }
        )

summary = pd.DataFrame(rows)
RESULTS.mkdir(exist_ok=True)
summary.to_csv(RESULTS / "metrics_summary.csv", index=False)
print(summary.to_string(index=False, float_format=lambda x: f"{x:.4f}"))
