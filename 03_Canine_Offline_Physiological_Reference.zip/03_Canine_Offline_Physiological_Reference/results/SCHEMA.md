# Result schema

Project: `03_Canine_Offline_Physiological_Reference`

## Core interval fields
- `estimate`, `primary_low`, `primary_high`: primary reference trajectory and interval.
- `secondary_mode`, `secondary_low`, `secondary_high`: active disjoint alternative when supported; `NaN` means no active secondary.
- `conservative_low`, `conservative_high`: outer bounds spanning the active interval set.
- `output_valid`: whether the window is released as a reference output.

## RR adjudication fields
- `high_confirmed`: signed morphology supports the higher f/2f branch.
- `low_confirmed`: signed morphology supports the lower branch.
- `ambiguous`: signed evidence is insufficient to resolve the branch; the baseline interval/modes are preserved.
- `boundary_rescued`: a persistent numerical boundary failure was reconstructed by the strict Back Acc+Gyro rescue.
- `unresolved_persistent_boundary`: rescue was triggered but did not meet release criteria.
- `not_eligible`: formal duration/eligibility was not met.

`rr_suppressed_branch` is diagnostic only: it records a harmonic competitor removed by a confirmed signed decision and is not an active alternative.

## Missing values
Floating `NaN` means not applicable/not available; it is not a measured zero. Boolean fields are serialized as `True`/`False`.
