from __future__ import annotations
import argparse, json
from dataclasses import asdict
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import numpy as np, pandas as pd
from canine_offline_reference import ReferenceConfig, estimate_recording
from canine_offline_reference.io import (
    discover_human_recordings,
    load_human_recording,
    centered_reference,
    motion_condition,
)
from canine_offline_reference.metrics import annotate_reference, trajectory_metrics
from canine_offline_reference.plotting import plot_human_final


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--human-root", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()
    out = Path(args.output)
    (out / "tables").mkdir(parents=True, exist_ok=True)
    (out / "figures" / "human").mkdir(parents=True, exist_ok=True)
    cfg = ReferenceConfig()
    all_rows = []
    metrics = []
    for folder in discover_human_recordings(args.human_root):
        raw, ref, streams = load_human_recording(folder)
        recording = folder.name
        result = estimate_recording(streams, cfg, enforce_formal_duration=False)
        annotated = {}
        for vital in ("hr", "rr"):
            frame = result[vital]
            half = (cfg.hr_window_s if vital == "hr" else cfg.rr_window_s) / 2.0
            reference = centered_reference(ref, frame["time_s"].to_numpy(float), vital, half)
            condition = motion_condition(recording, vital, frame["time_s"].to_numpy(float), half)
            a = annotate_reference(frame, reference, recording, vital, condition)
            annotated[vital] = a
            all_rows.append(a)
            metrics.append(trajectory_metrics(a, "final", only_nominal=False))
            if "04_disruption" in recording:
                metrics.append(trajectory_metrics(a, "final", only_nominal=True))
        plot_human_final(
            recording,
            raw,
            annotated["hr"],
            annotated["rr"],
            out / "figures" / "human" / f"{recording}.png",
        )
    pd.concat(all_rows, ignore_index=True).to_csv(
        out / "tables" / "human_window_results.csv", index=False
    )
    pd.DataFrame(metrics).to_csv(out / "tables" / "human_trajectory_metrics.csv", index=False)


if __name__ == "__main__":
    main()
