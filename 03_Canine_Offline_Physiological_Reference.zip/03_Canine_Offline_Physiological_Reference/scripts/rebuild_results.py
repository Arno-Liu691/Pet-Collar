from __future__ import annotations
import argparse, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PY = sys.executable


def run(cmd):
    print("+", " ".join(map(str, cmd)), flush=True)
    subprocess.check_call(cmd, cwd=ROOT)


def main():
    ap = argparse.ArgumentParser(
        description="Recompute the reference result tree from packaged raw inputs."
    )
    ap.add_argument(
        "--destination",
        required=True,
        help="Target directory for rebuilt tables/figures; choose an empty directory outside results/ when comparing builds.",
    )
    ap.add_argument("--jobs", type=int, default=4)
    args = ap.parse_args()
    out = Path(args.destination).resolve()
    out.mkdir(parents=True, exist_ok=True)
    run(
        [
            PY,
            "scripts/run_canine.py",
            "--canine-root",
            "inputs/canine_selected_segments/dogs",
            "--output",
            str(out),
            "--jobs",
            str(args.jobs),
        ]
    )
    run(
        [
            PY,
            "scripts/run_human.py",
            "--human-root",
            "inputs/human_ground_truth",
            "--output",
            str(out),
        ]
    )
    run([PY, "scripts/summarize_outputs.py", "--output", str(out)])
    print("Rebuilt results written to", out)


if __name__ == "__main__":
    main()
