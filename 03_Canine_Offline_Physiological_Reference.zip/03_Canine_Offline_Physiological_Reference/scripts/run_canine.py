from __future__ import annotations

import argparse
import json
import os
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import numpy as np
import pandas as pd
from scipy import signal
import matplotlib.pyplot as plt

from canine_offline_reference import ReferenceConfig, estimate_recording
from canine_offline_reference.io import canine_segment_folders, load_canine_segment
from canine_offline_reference.plotting import full_spectra, plot_canine


def _peaks(grid, score, count=3):
    inds = signal.find_peaks(score, distance=max(1, int(2.0 / (grid[1] - grid[0]))))[0]
    if len(inds) == 0:
        inds = np.array([int(np.argmax(score))])
    ranked = inds[np.argsort(score[inds])[::-1]][:count]
    return [(float(grid[index]), float(score[index])) for index in ranked]


def _worker(args):
    folder, cfg_values = args
    cfg = ReferenceConfig(**cfg_values)
    streams, metadata = load_canine_segment(folder)
    result = estimate_recording(streams, cfg, enforce_formal_duration=True)
    spectra = full_spectra(streams, cfg)
    return metadata, result["hr"], result["rr"], spectra


def _summary(metadata, vital, frame):
    valid = frame["output_valid"].to_numpy(bool)
    out = {
        "segment_id": metadata["segment_id"],
        "dog_id": metadata["dog_id"],
        "breed": metadata["breed"],
        "test_num": metadata["test_num"],
        "duration_s": metadata["duration_s"],
        "quiet_1s_fraction": metadata["quiet_1s_fraction"],
        "vital": vital,
        "eligible_windows": int(len(frame)),
        "valid_windows": int(valid.sum()),
        "output_rate": float(valid.mean()) if len(frame) else 0.0,
    }
    for target, column in (
        ("median_estimate", "estimate"),
        ("median_primary_low", "primary_low"),
        ("median_primary_high", "primary_high"),
        ("median_conservative_low", "conservative_low"),
        ("median_conservative_high", "conservative_high"),
        ("median_evidence", "evidence"),
        ("median_block_support_fraction", "physical_block_support_fraction"),
    ):
        out[target] = float(np.nanmedian(frame.loc[valid, column])) if valid.any() else np.nan
    out["median_primary_width"] = (
        float(np.nanmedian(frame.loc[valid, "primary_high"] - frame.loc[valid, "primary_low"]))
        if valid.any()
        else np.nan
    )
    out["median_union_width"] = (
        float(
            np.nanmedian(
                (frame.loc[valid, "primary_high"] - frame.loc[valid, "primary_low"])
                + np.where(
                    np.isfinite(frame.loc[valid, "secondary_low"]),
                    frame.loc[valid, "secondary_high"] - frame.loc[valid, "secondary_low"],
                    0.0,
                )
            )
        )
        if valid.any()
        else np.nan
    )
    out["two_mode_fraction"] = (
        float(np.mean(frame.loc[valid, "interval_mode_count"] == 2)) if valid.any() else np.nan
    )
    out["motion_rejections"] = int(np.sum(frame["rejection_reason"] == "motion_contamination"))
    out["duration_rejections"] = int(np.sum(frame["rejection_reason"] == "insufficient_duration"))
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--canine-root", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--jobs", type=int, default=max(1, min(4, os.cpu_count() or 1)))
    args = parser.parse_args()
    out = Path(args.output)
    (out / "tables").mkdir(parents=True, exist_ok=True)
    (out / "figures" / "canine").mkdir(parents=True, exist_ok=True)
    cfg = ReferenceConfig()
    folders = canine_segment_folders(args.canine_root)
    tasks = [(str(folder), asdict(cfg)) for folder in folders]
    completed = []
    with ProcessPoolExecutor(max_workers=args.jobs) as pool:
        futures = [pool.submit(_worker, task) for task in tasks]
        for future in as_completed(futures):
            completed.append(future.result())
    completed.sort(key=lambda item: item[0]["segment_id"])

    vital_rows = {"hr": [], "rr": []}
    summaries = []
    frequency_rows = []
    for metadata, hr, rr, spectra in completed:
        segment_id = metadata["segment_id"]
        for vital, frame in (("hr", hr), ("rr", rr)):
            annotated = frame.copy()
            annotated.insert(0, "segment_id", segment_id)
            annotated.insert(1, "dog_id", metadata["dog_id"])
            annotated.insert(2, "vital", vital)
            vital_rows[vital].append(annotated)
            summaries.append(_summary(metadata, vital, frame))
        for location, values in spectra.items():
            for vital in ("hr", "rr"):
                grid = values[f"{vital}_grid"]
                score = values[f"{vital}_score"]
                for rank, (rate, peak_score) in enumerate(_peaks(grid, score), start=1):
                    frequency_rows.append(
                        {
                            "segment_id": segment_id,
                            "dog_id": metadata["dog_id"],
                            "location": location,
                            "vital": vital,
                            "rank": rank,
                            "rate": rate,
                            "score_z": peak_score,
                        }
                    )
        streams, _ = load_canine_segment(
            next(folder for folder in folders if folder.name == segment_id)
        )
        plot_canine(
            segment_id, streams, hr, rr, spectra, out / "figures" / "canine" / f"{segment_id}.png"
        )

    pd.concat(vital_rows["hr"], ignore_index=True).to_csv(
        out / "tables" / "canine_hr_window_results.csv", index=False
    )
    pd.concat(vital_rows["rr"], ignore_index=True).to_csv(
        out / "tables" / "canine_rr_window_results.csv", index=False
    )
    summary_frame = pd.DataFrame(summaries)
    summary_frame.to_csv(out / "tables" / "canine_segment_vital_summary.csv", index=False)
    pd.DataFrame(frequency_rows).to_csv(out / "tables" / "canine_frequency_peaks.csv", index=False)
    (out / "config_frozen.json").write_text(json.dumps(asdict(cfg), indent=2), encoding="utf-8")
    fig, axes = plt.subplots(2, 1, figsize=(14, 9.5))
    for ax, vital in zip(axes, ("hr", "rr")):
        frame = summary_frame[
            (summary_frame["vital"] == vital) & (summary_frame["valid_windows"] > 0)
        ].copy()
        frame = frame.sort_values("segment_id")
        y = np.arange(len(frame))
        center = frame["median_estimate"].to_numpy(float)
        low = frame["median_primary_low"].to_numpy(float)
        high = frame["median_primary_high"].to_numpy(float)
        color = plt.cm.viridis(np.clip(frame["two_mode_fraction"].fillna(0).to_numpy(float), 0, 1))
        ax.errorbar(
            center,
            y,
            xerr=np.vstack([center - low, high - center]),
            fmt="none",
            ecolor="#90a4ae",
            capsize=3,
            alpha=0.9,
        )
        ax.scatter(center, y, c=color, s=42)
        ax.set_yticks(y, frame["segment_id"])
        ax.set_xlabel("HR (bpm)" if vital == "hr" else "RR (brpm)")
        ax.set_title(
            ("HR" if vital == "hr" else "RR")
            + " median primary intervals; colour reflects two-mode fraction"
        )
        ax.grid(axis="x", alpha=0.22)
    fig.tight_layout()
    fig.savefig(out / "figures" / "canine_summary.png", dpi=180, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
