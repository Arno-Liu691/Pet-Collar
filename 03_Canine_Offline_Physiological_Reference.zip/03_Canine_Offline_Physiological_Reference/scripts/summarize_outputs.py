from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd


def signed_summary(rr_all):
    rows = []
    for seg, f in rr_all.groupby("segment_id", sort=True):
        v = f.output_valid.fillna(False).to_numpy(bool)

        def first(col, default=np.nan):
            if col not in f.columns or not len(f):
                return default
            x = f[col].iloc[0]
            return default if pd.isna(x) else x

        vals = f.loc[v, "estimate"].to_numpy(float) if v.any() else np.array([])
        widths = (
            (f.loc[v, "primary_high"] - f.loc[v, "primary_low"]).to_numpy(float)
            if v.any()
            else np.array([])
        )
        rows.append(
            {
                "segment_id": seg,
                "dog_id": int(f.dog_id.iloc[0]),
                "state": first("rr_signed_state", ""),
                "winner": first("rr_signed_winner", ""),
                "confidence": float(first("rr_signed_confidence", 0.0)),
                "winner_share": float(first("rr_signed_winner_share", 0.0)),
                "vote_high": float(first("rr_signed_vote_high", np.nan)),
                "vote_low": float(first("rr_signed_vote_low", np.nan)),
                "vote_ambiguous": float(first("rr_signed_vote_ambiguous", np.nan)),
                "abab_support_low": float(first("rr_signed_abab_support_low", np.nan)),
                "phase_support_low": float(first("rr_signed_phase_support_low", np.nan)),
                "median_rr": float(np.nanmedian(vals)) if len(vals) else np.nan,
                "p10_rr": float(np.nanpercentile(vals, 10)) if len(vals) else np.nan,
                "p90_rr": float(np.nanpercentile(vals, 90)) if len(vals) else np.nan,
                "unique_rr_values": int(pd.Series(vals).nunique()) if len(vals) else 0,
                "median_primary_width": float(np.nanmedian(widths)) if len(widths) else np.nan,
                "width_sd": float(np.nanstd(widths)) if len(widths) else np.nan,
                "two_mode_fraction": (
                    float(np.mean(f.loc[v, "interval_mode_count"] == 2)) if v.any() else np.nan
                ),
                "boundary_rescue_triggered": bool(first("rr_boundary_rescue_triggered", False)),
                "boundary_rescue_success": bool(first("rr_boundary_rescue_success", False)),
                "boundary_rescue_support_fraction": float(
                    first("rr_boundary_rescue_support_fraction", 0.0)
                ),
                "suppressed_branch": float(first("rr_suppressed_branch", np.nan)),
                "suppressed_branch_type": first("rr_suppressed_branch_type", ""),
                "suppressed_branch_reason": first("rr_suppressed_branch_reason", ""),
            }
        )
    return pd.DataFrame(rows)


def formal_reference(hr_all, rr_all):
    rows = []
    for seg in sorted(set(hr_all.segment_id) | set(rr_all.segment_id)):
        h = hr_all[hr_all.segment_id.eq(seg)]
        r = rr_all[rr_all.segment_id.eq(seg)]
        hv = h.output_valid.fillna(False)
        rv = r.output_valid.fillna(False)
        rescue = False
        if "rr_boundary_rescue_success" in r.columns and len(r):
            x = r.rr_boundary_rescue_success.iloc[0]
            rescue = False if pd.isna(x) else bool(x)
        rows.append(
            {
                "segment_id": seg,
                "dog_id": int((h.dog_id.iloc[0] if len(h) else r.dog_id.iloc[0])),
                "hr_median": float(np.nanmedian(h.loc[hv, "estimate"])) if hv.any() else np.nan,
                "hr_primary_low": (
                    float(np.nanmedian(h.loc[hv, "primary_low"])) if hv.any() else np.nan
                ),
                "hr_primary_high": (
                    float(np.nanmedian(h.loc[hv, "primary_high"])) if hv.any() else np.nan
                ),
                "hr_output_rate": float(hv.mean()) if len(hv) else 0,
                "rr_median": float(np.nanmedian(r.loc[rv, "estimate"])) if rv.any() else np.nan,
                "rr_primary_low": (
                    float(np.nanmedian(r.loc[rv, "primary_low"])) if rv.any() else np.nan
                ),
                "rr_primary_high": (
                    float(np.nanmedian(r.loc[rv, "primary_high"])) if rv.any() else np.nan
                ),
                "rr_output_rate": float(rv.mean()) if len(rv) else 0,
                "rr_signed_state": r.rr_signed_state.iloc[0] if len(r) else "",
                "rr_signed_confidence": float(r.rr_signed_confidence.iloc[0]) if len(r) else np.nan,
                "rr_signed_winner_share": (
                    float(r.rr_signed_winner_share.iloc[0]) if len(r) else np.nan
                ),
                "rr_two_mode_fraction": (
                    float(np.mean(r.loc[rv, "interval_mode_count"] == 2)) if rv.any() else np.nan
                ),
                "rr_boundary_rescue_success": rescue,
                "rr_suppressed_branch": (
                    float(r.rr_suppressed_branch.iloc[0])
                    if len(r)
                    and "rr_suppressed_branch" in r.columns
                    and pd.notna(r.rr_suppressed_branch.iloc[0])
                    else np.nan
                ),
                "rr_suppressed_branch_type": (
                    r.rr_suppressed_branch_type.iloc[0]
                    if len(r) and "rr_suppressed_branch_type" in r.columns
                    else ""
                ),
                "rr_suppressed_branch_reason": (
                    r.rr_suppressed_branch_reason.iloc[0]
                    if len(r) and "rr_suppressed_branch_reason" in r.columns
                    else ""
                ),
            }
        )
    return pd.DataFrame(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", required=True)
    args = ap.parse_args()
    out = Path(args.output) / "tables"
    hr = pd.read_csv(out / "canine_hr_window_results.csv")
    rr = pd.read_csv(out / "canine_rr_window_results.csv")
    signed_summary(rr).to_csv(out / "canine_rr_signed_gate_summary.csv", index=False)
    formal_reference(hr, rr).to_csv(out / "canine_formal_reference.csv", index=False)


if __name__ == "__main__":
    main()
