from __future__ import annotations

import numpy as np
from scipy.signal import butter, detrend, find_peaks, hilbert, sosfiltfilt, welch

EPS = 1e-12


def as_2d(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    return x[:, None] if x.ndim == 1 else x


def robust_scale(x: np.ndarray) -> np.ndarray:
    x = as_2d(x)
    med = np.nanmedian(x, axis=0, keepdims=True)
    mad = np.nanmedian(np.abs(x - med), axis=0, keepdims=True)
    return (x - med) / (1.4826 * mad + EPS)


def bandpass(x: np.ndarray, fs: float, low: float, high: float, order: int = 4) -> np.ndarray:
    x = as_2d(x)
    nyq = fs / 2.0
    high = min(high, nyq * 0.95)
    if not (0 < low < high < nyq):
        raise ValueError(f"Invalid band {low}-{high} Hz for fs={fs}")
    sos = butter(order, [low, high], btype="bandpass", fs=fs, output="sos")
    return sosfiltfilt(sos, x, axis=0)


def pca_components(x: np.ndarray, n_components: int = 3) -> np.ndarray:
    z = robust_scale(x)
    u, s, _ = np.linalg.svd(z, full_matrices=False)
    k = min(n_components, u.shape[1])
    return u[:, :k] * s[:k]


def envelope_bank(x: np.ndarray, fs: float, bands) -> list[np.ndarray]:
    out = []
    for low, high in bands:
        y = bandpass(x, fs, low, high)
        out.append(np.abs(hilbert(y, axis=0)))
    return out


def normalized_psd(x: np.ndarray, fs: float, fmin: float, fmax: float):
    x = np.asarray(x, dtype=float)
    nperseg = min(len(x), max(256, int(fs * 12)))
    f, p = welch(
        detrend(x, type="linear"),
        fs=fs,
        window="hann",
        nperseg=nperseg,
        noverlap=nperseg // 2,
        nfft=max(4096, 2 ** int(np.ceil(np.log2(max(len(x), 2))))),
        detrend=False,
        scaling="density",
    )
    mask = (f >= fmin) & (f <= fmax)
    ff, pp = f[mask], p[mask]
    if len(pp) == 0 or not np.isfinite(pp).any():
        return ff, np.zeros_like(ff)
    pp = np.maximum(pp, 0.0)
    pp /= np.trapz(pp, ff) + EPS
    return ff, pp


def spectral_candidate(x: np.ndarray, fs: float, fmin: float, fmax: float):
    f, p = normalized_psd(x, fs, fmin, fmax)
    if len(p) < 3:
        return np.nan, 0.0, np.nan
    min_prominence = max(float(np.max(p)) * 0.035, float(np.median(p)) * 0.30)
    peaks, props = find_peaks(p, prominence=min_prominence)
    if len(peaks) == 0:
        # A maximum at the search boundary or a monotonic spectral slope is not
        # evidence of a physiological oscillation.
        return np.nan, 0.0, np.nan
    i = int(peaks[np.argmax(p[peaks])])
    peak = float(p[i])
    prominence = float(props["prominences"][np.where(peaks == i)[0][0]])
    med = float(np.median(p)) + EPS
    q = peak / med
    concentration = peak / (float(np.sum(p)) + EPS)
    prom_fraction = prominence / (peak + EPS)
    score = float(
        np.clip(
            (np.log1p(q) / 5.0) * 0.48
            + min(concentration * 12.0, 1.0) * 0.22
            + min(prom_fraction, 1.0) * 0.30,
            0,
            1,
        )
    )
    # Half-power local width is retained as a physically meaningful uncertainty cue.
    half = peak * 0.5
    left = i
    right = i
    while left > 0 and p[left] >= half:
        left -= 1
    while right < len(p) - 1 and p[right] >= half:
        right += 1
    width_hz = float(f[right] - f[left]) if right > left else float(f[1] - f[0])
    return float(f[i]), score, width_hz


def autocorrelation_candidate(x: np.ndarray, fs: float, fmin: float, fmax: float):
    x = np.asarray(x, dtype=float)
    x = detrend(x, type="linear")
    x = x / (np.std(x) + EPS)
    n = len(x)
    nfft = 1 << int(np.ceil(np.log2(max(2 * n - 1, 2))))
    spec = np.fft.rfft(x, n=nfft)
    ac = np.fft.irfft(spec * np.conj(spec), n=nfft)[:n]
    ac /= np.arange(n, 0, -1)
    ac /= ac[0] + EPS
    lo = max(1, int(np.floor(fs / fmax)))
    hi = min(n - 1, int(np.ceil(fs / fmin)))
    if hi <= lo:
        return np.nan, 0.0
    segment = ac[lo : hi + 1]
    min_distance = max(2, int(0.10 * (hi - lo)))
    peaks, props = find_peaks(segment, prominence=0.025, distance=min_distance)
    if len(peaks) == 0:
        return np.nan, 0.0
    local_i = int(peaks[np.argmax(segment[peaks])])
    i = local_i + lo
    # Parabolic interpolation reduces integer-lag quantisation.
    lag = float(i)
    if 1 <= i < n - 1:
        den = ac[i - 1] - 2 * ac[i] + ac[i + 1]
        if abs(den) > EPS:
            lag += 0.5 * (ac[i - 1] - ac[i + 1]) / den
    peak = float(ac[i])
    baseline = float(np.median(segment))
    prom = float(props["prominences"][np.where(peaks == local_i)[0][0]])
    score = float(np.clip((peak - baseline) / (1.0 - baseline + EPS), 0, 1))
    score *= float(np.clip(prom / 0.20, 0, 1))
    return float(fs / lag), score


def cepstrum_candidate(x: np.ndarray, fs: float, fmin: float, fmax: float):
    x = detrend(np.asarray(x, dtype=float), type="linear")
    nfft = max(4096, 2 ** int(np.ceil(np.log2(max(len(x), 2)))))
    log_mag = np.log(np.abs(np.fft.rfft(x, n=nfft)) + EPS)
    cep = np.fft.irfft(log_mag, n=nfft)
    lo = max(1, int(np.floor(fs / fmax)))
    hi = min(len(cep) - 1, int(np.ceil(fs / fmin)))
    if hi <= lo:
        return np.nan, 0.0
    q = np.abs(cep[lo : hi + 1])
    peaks, props = find_peaks(q, prominence=max(float(np.max(q)) * 0.04, EPS))
    if len(peaks) == 0:
        return np.nan, 0.0
    local_i = int(peaks[np.argmax(q[peaks])])
    i = local_i + lo
    peak = float(abs(cep[i]))
    med = float(np.median(q)) + EPS
    prom = float(props["prominences"][np.where(peaks == local_i)[0][0]])
    score = float(np.clip(np.log1p(peak / med) / 4.0, 0, 1))
    score *= float(np.clip(prom / (peak + EPS), 0, 1))
    return float(fs / i), score


def motion_features(acc: np.ndarray, gyro: np.ndarray, fs: float) -> dict:
    acc = as_2d(acc)
    gyro = as_2d(gyro)
    amag = np.linalg.norm(acc, axis=1)
    gmag = np.linalg.norm(gyro, axis=1)
    jerk = np.abs(np.diff(amag, prepend=amag[0])) * fs
    acc_dyn = np.abs(amag - np.median(amag))
    return {
        "acc_dyn_p95_g": float(np.percentile(acc_dyn, 95)),
        "acc_dyn_p99_g": float(np.percentile(acc_dyn, 99)),
        "acc_dyn_max_g": float(np.max(acc_dyn)),
        "acc_dyn_range_g": float(np.percentile(amag, 95) - np.percentile(amag, 5)),
        "gyro_p95_dps": float(np.percentile(gmag, 95)),
        "gyro_p99_dps": float(np.percentile(gmag, 99)),
        "gyro_max_dps": float(np.max(gmag)),
        "jerk_p95_gps": float(np.percentile(jerk, 95)),
        "jerk_p99_gps": float(np.percentile(jerk, 99)),
        "jerk_max_gps": float(np.max(jerk)),
    }


def stationarity_score(features: dict) -> float:
    # Continuous soft guard. Values are intentionally broad and apply equally to
    # human and canine data; evidence coherence remains the main quality signal.
    penalties = [
        max(0.0, features["acc_dyn_p95_g"] - 0.03) / 0.20,
        max(0.0, features["acc_dyn_range_g"] - 0.06) / 0.50,
        max(0.0, features["gyro_p95_dps"] - 15.0) / 120.0,
        max(0.0, features["jerk_p95_gps"] - 1.5) / 20.0,
        max(0.0, features["acc_dyn_p99_g"] - 0.20) / 0.80,
        max(0.0, features["gyro_p99_dps"] - 60.0) / 180.0,
        max(0.0, features["jerk_p99_gps"] - 8.0) / 35.0,
    ]
    score = float(np.exp(-sum(penalties)))
    if (
        features["acc_dyn_max_g"] >= 1.5
        or features["gyro_max_dps"] >= 150.0
        or features["jerk_max_gps"] >= 30.0
    ):
        score = min(score, 0.02)
    return score
