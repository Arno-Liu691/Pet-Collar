from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np
from scipy.signal import find_peaks

from .config import ReferenceConfig
from .signal import (
    EPS,
    autocorrelation_candidate,
    bandpass,
    cepstrum_candidate,
    envelope_bank,
    pca_components,
    spectral_candidate,
)


@dataclass
class Candidate:
    value: float
    score: float
    family: str
    source: str


def _best_channel(candidates: Iterable[Candidate]) -> Candidate | None:
    valid = [c for c in candidates if np.isfinite(c.value) and np.isfinite(c.score)]
    return max(valid, key=lambda c: c.score) if valid else None


def _event_candidate(x: np.ndarray, fs: float, lo_bpm: float, hi_bpm: float):
    x = np.asarray(x, dtype=float)
    z = (x - np.median(x)) / (1.4826 * np.median(np.abs(x - np.median(x))) + EPS)
    distance = max(1, int(fs * 60.0 / hi_bpm * 0.72))
    peaks, props = find_peaks(z, distance=distance, prominence=0.5)
    if len(peaks) < 5:
        return np.nan, 0.0
    ibi = np.diff(peaks) / fs
    ok = (ibi >= 60.0 / hi_bpm) & (ibi <= 60.0 / lo_bpm)
    ibi = ibi[ok]
    if len(ibi) < 4:
        return np.nan, 0.0
    med = float(np.median(ibi))
    cv = float(1.4826 * np.median(np.abs(ibi - med)) / (med + EPS))
    consistency = float(np.clip(1.0 - cv / 0.30, 0, 1))
    density = float(np.clip(len(ibi) / max(5.0, len(x) / fs * lo_bpm / 60.0), 0, 1))
    return 60.0 / med, consistency * density


def hr_candidates(
    acc: np.ndarray, gyro: np.ndarray, cfg: ReferenceConfig, source: str
) -> list[Candidate]:
    fs = cfg.fs_hz
    fmin, fmax = np.asarray(cfg.hr_range_bpm) / 60.0
    out: list[Candidate] = []
    for modality, raw in (("acc", acc), ("gyro", gyro)):
        raw = np.asarray(raw, dtype=float)
        channels = np.column_stack([raw, pca_components(raw, min(3, raw.shape[1]))])

        direct = bandpass(channels, fs, max(0.5, fmin * 0.8), min(8.0, fs * 0.45))
        psd_rows = []
        acf_rows = []
        for j in range(direct.shape[1]):
            f, s, _ = spectral_candidate(direct[:, j], fs, fmin, fmax)
            psd_rows.append(Candidate(f * 60.0, s, f"hr_direct_psd_{modality}", source))
            f, s = autocorrelation_candidate(direct[:, j], fs, fmin, fmax)
            acf_rows.append(Candidate(f * 60.0, s, f"hr_direct_acf_{modality}", source))
        for c in (_best_channel(psd_rows), _best_channel(acf_rows)):
            if c is not None:
                out.append(c)

        env_psd_rows = []
        env_acf_rows = []
        event_rows = []
        for bank_idx, env in enumerate(envelope_bank(channels, fs, cfg.hr_filterbanks_hz)):
            env_hr = bandpass(env, fs, max(0.5, fmin * 0.8), min(fmax * 1.15, 4.5))
            for j in range(env_hr.shape[1]):
                f, s, _ = spectral_candidate(env_hr[:, j], fs, fmin, fmax)
                env_psd_rows.append(
                    Candidate(f * 60.0, s, f"hr_envelope_psd_{modality}", f"{source}:b{bank_idx}")
                )
                f, s = autocorrelation_candidate(env_hr[:, j], fs, fmin, fmax)
                env_acf_rows.append(
                    Candidate(f * 60.0, s, f"hr_envelope_acf_{modality}", f"{source}:b{bank_idx}")
                )
                f, s = _event_candidate(env_hr[:, j], fs, *cfg.hr_range_bpm)
                event_rows.append(Candidate(f, s, f"hr_event_{modality}", f"{source}:b{bank_idx}"))
        for c in (
            _best_channel(env_psd_rows),
            _best_channel(env_acf_rows),
            _best_channel(event_rows),
        ):
            if c is not None:
                out.append(c)
    return [
        c
        for c in out
        if c.score >= cfg.min_candidate_score
        and cfg.hr_range_bpm[0] <= c.value <= cfg.hr_range_bpm[1]
    ]


def rr_candidates(
    acc: np.ndarray, gyro: np.ndarray, cfg: ReferenceConfig, source: str
) -> list[Candidate]:
    fs = cfg.fs_hz
    fmin, fmax = np.asarray(cfg.rr_range_brpm) / 60.0
    out: list[Candidate] = []
    for modality, raw in (("acc", acc), ("gyro", gyro)):
        low = bandpass(raw, fs, max(0.04, fmin * 0.7), min(1.2, fmax * 1.35))
        pca = pca_components(low, min(3, low.shape[1]))
        channel_sets = (("axis", low), ("pca", pca))
        for projection, channels in channel_sets:
            psd_rows = []
            acf_rows = []
            cep_rows = []
            for j in range(channels.shape[1]):
                f, s, _ = spectral_candidate(channels[:, j], fs, fmin, fmax)
                psd_rows.append(Candidate(f * 60.0, s, f"rr_{projection}_psd_{modality}", source))
                f, s = autocorrelation_candidate(channels[:, j], fs, fmin, fmax)
                acf_rows.append(Candidate(f * 60.0, s, f"rr_{projection}_acf_{modality}", source))
                f, s = cepstrum_candidate(channels[:, j], fs, fmin, fmax)
                cep_rows.append(
                    Candidate(f * 60.0, s, f"rr_{projection}_cepstrum_{modality}", source)
                )
            for c in (_best_channel(psd_rows), _best_channel(acf_rows), _best_channel(cep_rows)):
                if c is not None:
                    out.append(c)
    return [
        c
        for c in out
        if c.score >= cfg.min_candidate_score
        and cfg.rr_range_brpm[0] <= c.value <= cfg.rr_range_brpm[1]
    ]
