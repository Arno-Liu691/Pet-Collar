from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

import numpy as np
import pandas as pd
from scipy import ndimage, signal

from .config import ReferenceConfig
from .core import EvidenceBundle, robust_z, second_window, viterbi_track

EPS = 1e-12


def _corr(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    a = a - np.mean(a)
    b = b - np.mean(b)
    d = np.linalg.norm(a) * np.linalg.norm(b)
    return float(np.dot(a, b) / d) if d > 1e-12 else np.nan


def _source_block_indices(streams: Mapping[str, tuple[np.ndarray, np.ndarray]]):
    """Return block indices matching core._physical_blocks insertion order."""
    mapping = {}
    idx = 0
    for source in streams:
        mapping[source] = [idx, idx + 1]
        idx += 2
    return mapping


def _source_hr_track(bundle: EvidenceBundle, cfg: ReferenceConfig, indices: list[int]):
    # Build an entirely source-local baseline spectral surface from its ACC+GYR physical blocks.
    raw = np.sum(bundle.block_score[:, indices, :], axis=1)
    z = np.vstack([robust_z(row) for row in raw])
    persistence = np.quantile(z, 0.70, axis=0)
    peaks = signal.find_peaks(
        persistence,
        distance=max(1, int(round(6.0 / (bundle.grid[1] - bundle.grid[0])))),
    )[0]
    if len(peaks) == 0:
        peaks = np.array([int(np.argmax(persistence))])
    anchor = float(bundle.grid[peaks[np.argmax(persistence[peaks])]])
    track, smoothed = viterbi_track(
        z,
        bundle.grid,
        anchor,
        cfg.hr_transition_scale_bpm,
        cfg.hr_transition_penalty,
        cfg.hr_anchor_prior_scale_bpm,
        cfg.hr_anchor_prior_penalty,
    )
    confidence = np.zeros(len(track), float)
    for i, center in enumerate(track):
        center_mask = np.abs(bundle.grid - center) <= 5.0
        peak = float(np.max(smoothed[i, center_mask]))
        remote = smoothed[i].copy()
        remote[center_mask] = -np.inf
        remote_peak = float(np.max(remote))
        margin = peak - remote_peak
        confidence[i] = float(np.clip((margin + 0.20) / 1.50, 0.0, 1.0))
    return track, confidence, anchor


def apply_hr_location_adjudication(
    frame: pd.DataFrame,
    bundle: EvidenceBundle,
    streams: Mapping[str, tuple[np.ndarray, np.ndarray]],
    cfg: ReferenceConfig,
    source_frames: Mapping[str, pd.DataFrame] | None = None,
) -> pd.DataFrame:
    """Represent strong multi-location HR disagreement as disjoint modes.

    The combined Viterbi point estimate is deliberately left unchanged.  This
    module changes uncertainty semantics only: if two independently tracked
    physical locations support persistent, well-separated HR ridges, the
    remote ridge is disclosed as a secondary interval instead of widening one
    connected primary interval across unsupported rates.

    Single-location recordings (the human tests) are returned unchanged apart
    from diagnostic columns.
    """
    out = frame.copy()
    sources = list(streams.keys())
    out["hr_location_mode_count"] = 1
    out["hr_location_disagreement_bpm"] = 0.0
    out["hr_location_secondary_added"] = False
    out["hr_location_tracks"] = ""
    out["hr_interval_strategy"] = "single_location_or_no_conflict"
    if len(sources) < 2:
        return out

    source_tracks = {}
    source_conf = {}
    source_valid = {}
    if source_frames is not None and all(source in source_frames for source in sources):
        for source in sources:
            sf = source_frames[source]
            source_tracks[source] = sf["estimate"].to_numpy(float)
            source_conf[source] = sf["evidence"].to_numpy(float)
            source_valid[source] = sf["output_valid"].to_numpy(bool)
    else:
        block_map = _source_block_indices(streams)
        for source in sources:
            tr, cf, _ = _source_hr_track(bundle, cfg, block_map[source])
            source_tracks[source] = tr
            source_conf[source] = cf
            source_valid[source] = np.ones(len(tr), bool)

    # For >2 sources use the pair with maximum separation at each time.
    tcount = len(out)
    for i in range(tcount):
        vals = [(s, float(source_tracks[s][i]), float(source_conf[s][i])) for s in sources]
        vals.sort(key=lambda x: x[1])
        low_s, low_v, low_c = vals[0]
        high_s, high_v, high_c = vals[-1]
        sep = high_v - low_v
        out.at[i, "hr_location_disagreement_bpm"] = sep
        out.at[i, "hr_location_tracks"] = ";".join(f"{s}:{v:.2f}" for s, v, _ in vals)

    sep_series = out["hr_location_disagreement_bpm"].to_numpy(float)
    persistent_sep = ndimage.median_filter(
        sep_series, size=min(9, max(1, len(sep_series) // 2 * 2 + 1)), mode="nearest"
    )

    for i in range(tcount):
        vals = [(s, float(source_tracks[s][i]), float(source_conf[s][i])) for s in sources]
        vals.sort(key=lambda x: x[1])
        low_s, low_v, low_c = vals[0]
        high_s, high_v, high_c = vals[-1]
        sep = high_v - low_v
        # Persistent location tracks are more informative here than a single-row
        # spectral uniqueness margin.  A conflict is declared only when two
        # physical locations follow distinct, coherent ridges over time.
        r0 = max(0, i - 4)
        r1 = min(tcount, i + 5)
        low_local = np.asarray(source_tracks[low_s][r0:r1], float)
        high_local = np.asarray(source_tracks[high_s][r0:r1], float)
        local_span = max(
            float(np.percentile(low_local, 90) - np.percentile(low_local, 10)),
            float(np.percentile(high_local, 90) - np.percentile(high_local, 10)),
        )
        both_source_valid = bool(source_valid[low_s][i] and source_valid[high_s][i])
        conflict = (
            both_source_valid
            and sep >= cfg.hr_location_split_min_bpm
            and persistent_sep[i] >= cfg.hr_location_persistent_min_bpm
            and min(low_c, high_c) >= cfg.hr_location_min_source_confidence
            and local_span <= 8.0
            and float(bundle.stationarity[i]) >= cfg.hr_location_min_stationarity
        )
        if not conflict:
            continue

        center = float(out.at[i, "estimate"])
        primary_s, primary_v, primary_c = min(vals, key=lambda x: abs(x[1] - center))
        secondary_s, secondary_v, secondary_c = max(vals, key=lambda x: abs(x[1] - center))
        # If the combined track sits in an unsupported midpoint rather than near
        # either physical mode, do not narrow it; simply disclose the conflict.
        primary_match = abs(primary_v - center) <= 7.0

        existing_secondary = (
            out.at[i, "secondary_mode"] if "secondary_mode" in out.columns else np.nan
        )
        existing_ratio = (
            float(out.at[i, "second_mode_ratio"]) if "second_mode_ratio" in out.columns else 0.0
        )
        loc_ratio = float(
            np.clip(
                0.60 + 0.20 * min(primary_c, secondary_c) + 0.20 * (min(sep, 30.0) - 12.0) / 18.0,
                0.60,
                1.0,
            )
        )

        # Preserve a stronger pre-existing secondary if it is essentially the
        # same remote branch; otherwise location evidence takes precedence.
        secondary_mode = secondary_v
        if np.isfinite(existing_secondary) and abs(float(existing_secondary) - secondary_v) <= 5.0:
            secondary_mode = 0.5 * (float(existing_secondary) + secondary_v)
            loc_ratio = max(loc_ratio, existing_ratio)

        old_half = float(out.at[i, "primary_halfwidth"])
        block_spread = float(out.at[i, "block_spread"])
        cons_spread = (
            float(out.at[i, "consensus_spread"])
            if np.isfinite(out.at[i, "consensus_spread"])
            else 0.0
        )
        excursion = float(out.at[i, "local_track_excursion"])
        evidence = float(out.at[i, "evidence"])
        # Within-mode uncertainty only.  The remote location is represented by a
        # second interval and therefore must not inflate the connected primary.
        proposed_half = (
            6.3
            + 0.35 * min(block_spread, 10.0)
            + 0.10 * min(cons_spread, 12.0)
            + 0.22 * min(excursion, 12.0)
            + 2.0 * (1.0 - evidence)
        )
        proposed_half = float(np.clip(proposed_half, 5.0, 11.0))

        # To call the modes disjoint, keep at least a 1 bpm unsupported gap. If
        # that would force either interval below 4.5 bpm halfwidth, retain the
        # original connected interval instead of pretending to know more.
        max_disjoint_half = (abs(secondary_mode - center) - 1.0) / 2.0
        if primary_match and max_disjoint_half >= cfg.hr_location_min_disjoint_halfwidth_bpm:
            primary_half = min(old_half, proposed_half, max_disjoint_half)
            secondary_half = min(
                max(cfg.hr_location_min_disjoint_halfwidth_bpm, 0.75 * proposed_half),
                max_disjoint_half,
            )
            low_limit, high_limit = cfg.hr_range_bpm
            p_low = max(low_limit, center - primary_half)
            p_high = min(high_limit, center + primary_half)
            s_low = max(low_limit, secondary_mode - secondary_half)
            s_high = min(high_limit, secondary_mode + secondary_half)
            # Guard against numerical overlap after clipping.
            if p_high < s_low or s_high < p_low:
                out.at[i, "primary_halfwidth"] = primary_half
                out.at[i, "primary_low"] = p_low
                out.at[i, "primary_high"] = p_high
                out.at[i, "secondary_mode"] = secondary_mode
                out.at[i, "secondary_low"] = s_low
                out.at[i, "secondary_high"] = s_high
                out.at[i, "interval_mode_count"] = 2
                out.at[i, "second_mode_ratio"] = max(existing_ratio, loc_ratio)
                out.at[i, "conservative_low"] = min(p_low, s_low)
                out.at[i, "conservative_high"] = max(p_high, s_high)
                out.at[i, "hr_location_mode_count"] = 2
                out.at[i, "hr_location_secondary_added"] = True
                out.at[i, "hr_interval_strategy"] = "disjoint_location_modes"
                continue

        # Conflict is real but not separable at a defensible width.
        out.at[i, "hr_location_mode_count"] = 2
        out.at[i, "hr_interval_strategy"] = "location_conflict_disclosed_no_narrowing"

    return out


def _signed_band(x: np.ndarray, fs: float, lo: float = 0.12, hi: float = 0.90):
    """Linear signed preprocessing used by the RR adjudicator.

    No magnitude, abs(time signal), square, or energy envelope is used.  The
    only operations are detrending and linear zero-phase band-pass filtering.
    """
    sos = signal.butter(4, [lo, hi], btype="bandpass", fs=fs, output="sos")
    return signal.sosfiltfilt(sos, signal.detrend(np.asarray(x, float), type="linear"))


def _fold(y: np.ndarray, fs: float, rate: float, points: int = 64):
    length = fs * 60.0 / rate
    count = int((len(y) - 1) // length)
    phase = np.arange(points) / points
    xx = np.arange(len(y))
    cycles = []
    for k in range(count):
        idx = (k + phase) * length
        if idx[-1] >= len(y) - 1:
            break
        cycles.append(np.interp(idx, xx, y))
    cycles = np.asarray(cycles)
    if len(cycles) < 6:
        return np.nan, np.nan, np.nan
    adjacent = np.nanmedian([_corr(cycles[i], cycles[i + 1]) for i in range(len(cycles) - 1)])
    skip = np.nanmedian([_corr(cycles[i], cycles[i + 2]) for i in range(len(cycles) - 2)])
    return float(adjacent), float(skip), float(skip - adjacent)


def _search_fold(y: np.ndarray, fs: float, lo: float, hi: float, step: float = 0.25):
    best = (-9.0, np.nan, np.nan, np.nan)
    if hi < lo:
        return best
    for rate in np.arange(lo, hi + 1e-9, step):
        a, s, d = _fold(y, fs, rate)
        if np.isfinite(a) and a > best[0]:
            best = (float(a), float(rate), float(s), float(d))
    return best


def _phase_coupling(y: np.ndarray, fs: float, low_rate: float, high_rate: float) -> float:
    """Return |mean(exp(j(phi_2f-2phi_f)))| using narrow signed components.

    This is only corroborating evidence.  It is not used when the candidate
    pair is not close to 2:1 or when a narrow filter cannot be formed safely.
    """
    if not (np.isfinite(low_rate) and np.isfinite(high_rate)):
        return np.nan
    if abs(high_rate - 2.0 * low_rate) > 4.0:
        return np.nan
    f1 = low_rate / 60.0
    f2 = high_rate / 60.0
    nyq = fs / 2.0
    bw1 = max(0.035, 0.16 * f1)
    bw2 = max(0.045, 0.12 * f2)
    lo1, hi1 = max(0.06, f1 - bw1), min(nyq * 0.95, f1 + bw1)
    lo2, hi2 = max(0.12, f2 - bw2), min(nyq * 0.95, f2 + bw2)
    if hi1 <= lo1 or hi2 <= lo2:
        return np.nan
    try:
        s1 = signal.butter(3, [lo1, hi1], btype="bandpass", fs=fs, output="sos")
        s2 = signal.butter(3, [lo2, hi2], btype="bandpass", fs=fs, output="sos")
        a1 = signal.hilbert(signal.sosfiltfilt(s1, y))
        a2 = signal.hilbert(signal.sosfiltfilt(s2, y))
        theta = np.unwrap(np.angle(a2)) - 2.0 * np.unwrap(np.angle(a1))
        # Ignore filter transients at both edges.
        trim = int(min(len(theta) // 5, max(fs * 4.0, 1)))
        if len(theta) > 2 * trim + int(fs * 10):
            theta = theta[trim:-trim]
        if len(theta) < int(fs * 8):
            return np.nan
        return float(abs(np.mean(np.exp(1j * theta))))
    except Exception:
        return np.nan


def _crossing_times(y: np.ndarray, fs: float):
    inds = np.where((y[:-1] <= 0) & (y[1:] > 0))[0]
    out = []
    for i in inds:
        den = y[i + 1] - y[i]
        frac = (-y[i] / den) if abs(den) > 1e-12 else 0.0
        out.append((i + frac) / fs)
    return np.asarray(out)


def _full_cycle_rate(crossings: np.ndarray):
    delta = np.diff(crossings)
    ok = (delta >= 1.0) & (delta <= 6.0)
    if ok.sum() < 4:
        return np.nan, 0, np.nan
    ibi = delta[ok]
    rate = 60.0 / np.median(ibi)
    rr = 60.0 / ibi
    mad = 1.4826 * np.median(np.abs(rr - rate))
    return float(rate), int(ok.sum()), float(mad / (rate + EPS))


def _local_fold_rate(y: np.ndarray, fs: float, target: float, half_window: float = 3.0):
    lo = max(6.0, target - half_window)
    hi = min(22.5, target + half_window)
    best = _search_fold(y, fs, lo, hi, step=0.25)
    return best


def _longest_true_run(mask: np.ndarray) -> int:
    longest = current = 0
    for flag in np.asarray(mask, bool):
        current = current + 1 if flag else 0
        longest = max(longest, current)
    return int(longest)


def _best_rate_cluster(candidates, cfg: ReferenceConfig):
    """Return the strongest cross-axis Back Acc+Gyro rate cluster.

    candidates are (modality, axis, rate, repeatability).  The cluster is
    deliberately defined without population physiology: support must come from
    multiple signed axes and from both acceleration and angular velocity.
    """
    vals = [
        c
        for c in candidates
        if np.isfinite(c[2])
        and np.isfinite(c[3])
        and c[3] >= cfg.rr_boundary_rescue_min_axis_repeatability
    ]
    if not vals:
        return None
    best = None
    for seed in vals:
        members = [
            q for q in vals if abs(q[2] - seed[2]) <= cfg.rr_boundary_rescue_cluster_halfwidth_brpm
        ]
        rates = np.asarray([q[2] for q in members], float)
        reps = np.asarray([q[3] for q in members], float)
        modalities = {q[0] for q in members}
        score = (
            len(members),
            len(modalities),
            float(np.sum(reps)),
            -float(np.std(rates)) if len(rates) else -999.0,
        )
        if best is None or score > best[0]:
            best = (score, members)
    if best is None:
        return None
    members = best[1]
    rates = np.asarray([q[2] for q in members], float)
    reps = np.asarray([q[3] for q in members], float)
    med = float(np.median(rates))
    spread = float(1.4826 * np.median(np.abs(rates - med))) if len(rates) > 1 else 0.0
    return {
        "rate": med,
        "spread": spread,
        "repeatability": float(np.median(reps)),
        "axis_count": int(len(members)),
        "modalities": "".join(sorted({q[0] for q in members})),
        "members": members,
    }


def _attempt_rr_boundary_rescue(
    out: pd.DataFrame,
    streams: Mapping[str, tuple[np.ndarray, np.ndarray]],
    cfg: ReferenceConfig,
):
    """Try to reconstruct RR after a persistent lower-boundary tracker lock.

    This is intentionally *triggered* rather than a global re-estimator.  It is
    entered only after the baseline has been pinned to its numerical lower
    boundary for a complete RR analysis window and the ordinary f-vs-2f gate
    could not decide.  Rescue requires independent Back signed Acc+Gyro
    mechanical-cycle agreement.  If that evidence is insufficient, None is
    returned and the caller falls back to rejection/unresolved.
    """
    if "back" not in streams:
        return None
    anchor_vals = pd.to_numeric(out.get("anchor", np.nan), errors="coerce").to_numpy(float)
    anchor = float(np.nanmedian(anchor_vals)) if np.isfinite(anchor_vals).any() else np.nan
    low_limit, high_limit = cfg.rr_range_brpm
    if not np.isfinite(anchor) or anchor < low_limit + cfg.rr_boundary_rescue_anchor_margin_brpm:
        return None

    search_lo = max(
        low_limit + cfg.rr_boundary_rescue_exclude_boundary_brpm,
        anchor - cfg.rr_boundary_rescue_anchor_search_halfwidth_brpm,
    )
    search_hi = min(
        high_limit - cfg.rr_boundary_rescue_exclude_boundary_brpm,
        anchor + cfg.rr_boundary_rescue_anchor_search_halfwidth_brpm,
    )
    if search_hi - search_lo < 6.0:
        return None

    back_acc, back_gyro = streams["back"]
    channels = []
    for modality, arr in (("A", back_acc), ("G", back_gyro)):
        for axis in range(3):
            channels.append((modality, axis, _signed_band(arr[:, axis], cfg.fs_hz)))

    n = min(len(acc) for acc, _ in streams.values())
    rates = np.full(len(out), np.nan)
    spreads = np.full(len(out), np.nan)
    repeats = np.full(len(out), np.nan)
    axis_counts = np.zeros(len(out), int)
    modality_flags = np.full(len(out), "", dtype=object)
    supported = np.zeros(len(out), bool)

    for ti in range(len(out)):
        i0, i1, _ = second_window(n, cfg.fs_hz, int(ti), cfg.rr_window_s / 2.0, cfg.rr_min_window_s)
        if i1 - i0 < int(cfg.rr_min_window_s * cfg.fs_hz):
            continue
        candidates = []
        for modality, axis, y in channels:
            best = _search_fold(y[i0:i1], cfg.fs_hz, search_lo, search_hi, step=cfg.rr_step_brpm)
            if np.isfinite(best[1]):
                candidates.append((modality, axis, float(best[1]), float(best[0])))
        cluster = _best_rate_cluster(candidates, cfg)
        if cluster is None:
            continue
        good = (
            cluster["axis_count"] >= cfg.rr_boundary_rescue_min_axes
            and cluster["modalities"] == "AG"
            and cluster["repeatability"] >= cfg.rr_boundary_rescue_min_cluster_repeatability
            and cluster["spread"] <= cfg.rr_boundary_rescue_max_axis_spread_brpm
        )
        if not good:
            continue
        rates[ti] = cluster["rate"]
        spreads[ti] = cluster["spread"]
        repeats[ti] = cluster["repeatability"]
        axis_counts[ti] = cluster["axis_count"]
        modality_flags[ti] = cluster["modalities"]
        supported[ti] = True

    support_fraction = float(np.mean(supported)) if len(supported) else 0.0
    if (
        supported.sum() < 2
        or support_fraction < cfg.rr_boundary_rescue_min_supported_window_fraction
    ):
        return None

    idx = np.arange(len(out))
    # Fill isolated unsupported windows only after a large majority of local
    # windows have independently passed the Acc+Gyro support criteria.
    rates_f = np.interp(idx, np.flatnonzero(supported), rates[supported])
    spread_f = np.interp(idx, np.flatnonzero(supported), spreads[supported])
    repeat_f = np.interp(idx, np.flatnonzero(supported), repeats[supported])
    axis_f = np.interp(idx, np.flatnonzero(supported), axis_counts[supported])
    rates_f = ndimage.median_filter(rates_f, size=3, mode="nearest")
    track = np.round(rates_f / cfg.rr_step_brpm) * cfg.rr_step_brpm

    evidence = out["evidence"].to_numpy(float)
    stationarity = out["stationarity"].to_numpy(float)
    half = np.zeros(len(out), float)
    for i in range(len(out)):
        local = track[max(0, i - 8) : min(len(track), i + 9)]
        excursion = float(np.percentile(local, 90) - np.percentile(local, 10))
        axis_penalty = 0.75 if axis_f[i] < 4.5 else (0.35 if axis_f[i] < 5.5 else 0.0)
        repeat_penalty = 1.2 * max(0.0, 0.75 - repeat_f[i])
        within = (
            cfg.rr_base_halfwidth_brpm
            + 0.55 * min(spread_f[i], 5.0)
            + 0.42 * excursion
            + repeat_penalty
            + 0.55 * (1.0 - evidence[i])
            + 0.35 * max(0.0, 0.65 - stationarity[i])
            + axis_penalty
        )
        half[i] = float(np.clip(within, cfg.rr_base_halfwidth_brpm, cfg.rr_max_halfwidth_brpm))

    low = np.maximum(low_limit, track - half)
    high = np.minimum(high_limit, track + half)
    rescued = out.copy()
    rescued["rr_boundary_rescue_triggered"] = True
    rescued["rr_boundary_rescue_success"] = True
    rescued["rr_boundary_rescue_support_fraction"] = support_fraction
    rescued["rr_boundary_rescue_rate"] = track
    rescued["rr_boundary_rescue_repeatability"] = repeat_f
    rescued["rr_boundary_rescue_axis_count"] = np.rint(axis_f).astype(int)
    rescued["rr_boundary_rescue_axis_spread"] = spread_f
    rescued["rr_boundary_rescue_search_low"] = search_lo
    rescued["rr_boundary_rescue_search_high"] = search_hi

    original_reason = rescued["rejection_reason"].fillna("").astype(str).to_numpy()
    for i in range(len(rescued)):
        rescued.at[i, "estimate"] = float(track[i])
        rescued.at[i, "primary_low"] = float(low[i])
        rescued.at[i, "primary_high"] = float(high[i])
        rescued.at[i, "primary_halfwidth"] = float(half[i])
        # A previously secondary branch can become the rescued primary branch.
        sec = (
            float(rescued.at[i, "secondary_mode"])
            if np.isfinite(rescued.at[i, "secondary_mode"])
            else np.nan
        )
        if (not np.isfinite(sec)) or abs(sec - track[i]) <= 4.0:
            rescued.at[i, "secondary_mode"] = np.nan
            rescued.at[i, "secondary_low"] = np.nan
            rescued.at[i, "secondary_high"] = np.nan
            rescued.at[i, "interval_mode_count"] = 1
            rescued.at[i, "second_mode_ratio"] = 0.0
            rescued.at[i, "conservative_low"] = float(low[i])
            rescued.at[i, "conservative_high"] = float(high[i])
        else:
            rescued.at[i, "conservative_low"] = min(
                float(low[i]), float(rescued.at[i, "secondary_low"])
            )
            rescued.at[i, "conservative_high"] = max(
                float(high[i]), float(rescued.at[i, "secondary_high"])
            )

        # Rescue may overturn only the baseline's numerical boundary-lock
        # rejection.  Motion, weak-evidence, and duration gates retain authority.
        if original_reason[i] == "boundary_lock" and supported[i]:
            rescued.at[i, "output_valid"] = True
            rescued.at[i, "rejection_reason"] = ""

    rescued["rr_signed_state"] = "boundary_rescued"
    rescued["rr_signed_winner"] = "rescue"
    rescued["rr_signed_adjudicated"] = True
    rescued["rr_mechanical_target"] = float(np.nanmedian(track))
    rescued["rr_signed_uncertainty_action"] = "persistent_boundary_rescued_by_back_signed_acc_gyro"
    return rescued


def apply_rr_signed_adjudication(
    frame: pd.DataFrame,
    streams: Mapping[str, tuple[np.ndarray, np.ndarray]],
    cfg: ReferenceConfig,
) -> pd.DataFrame:
    """Conservative signed-XYZ f-vs-2f adjudication for offline canine RR.

    The gate has no authority to reject a baseline-valid RR window.  It returns
    one of three states:
      * high_confirmed: signed morphology supports the high branch;
      * low_confirmed: signed morphology supports the low branch;
      * ambiguous: signed evidence cannot safely reduce f/2f uncertainty.

    In the ambiguous state the baseline estimate, intervals, and secondary mode
    are left untouched.  Thus a false abstention loses only an opportunity to
    refine the estimate; it does not lose the original result.

    The decision uses only signed XYZ after linear filtering.  Besides adjacent
    cycle repeatability, it explicitly uses A-B-A-B evidence (i vs i+2) and
    f/2f phase coupling as corroboration.  Neither search range is enlarged.
    """
    out = frame.copy()
    out["rr_signed_adjudicated"] = False
    out["rr_signed_state"] = "not_applicable"
    out["rr_signed_winner"] = "abstain"
    out["rr_signed_confidence"] = 0.0
    out["rr_signed_winner_share"] = 0.0
    out["rr_signed_vote_high"] = np.nan
    out["rr_signed_vote_low"] = np.nan
    out["rr_signed_vote_ambiguous"] = np.nan
    out["rr_signed_abab_support_low"] = np.nan
    out["rr_signed_phase_support_low"] = np.nan
    out["rr_mechanical_target"] = np.nan
    out["rr_signed_uncertainty_action"] = "baseline_preserved"
    out["rr_boundary_rescue_triggered"] = False
    out["rr_boundary_rescue_success"] = False
    out["rr_boundary_rescue_support_fraction"] = 0.0
    out["rr_boundary_rescue_rate"] = np.nan
    out["rr_boundary_rescue_repeatability"] = np.nan
    out["rr_boundary_rescue_axis_count"] = 0
    out["rr_boundary_rescue_axis_spread"] = np.nan
    out["rr_boundary_rescue_search_low"] = np.nan
    out["rr_boundary_rescue_search_high"] = np.nan
    # Audit-only branch disclosure. These fields do not participate in scoring
    # or alter the final estimate; they preserve a pre-adjudication competing
    # harmonic branch that was explicitly suppressed by a confirmed signed decision.
    out["rr_suppressed_branch"] = np.nan
    out["rr_suppressed_branch_type"] = ""
    out["rr_suppressed_branch_reason"] = ""

    if len(streams) < 2 or "back" not in streams:
        return out
    valid = out["output_valid"].to_numpy(bool)
    duration = min(len(acc) for acc, _ in streams.values()) / cfg.fs_hz
    if duration < cfg.rr_formal_min_duration_s or not valid.any():
        out["rr_signed_state"] = "not_eligible"
        return out

    current_median = float(np.nanmedian(out.loc[valid, "estimate"]))
    channel_rows = []
    signed_channels = []
    for loc, (acc, gyro) in streams.items():
        for modality, arr in (("A", acc), ("G", gyro)):
            for axis in range(3):
                y = _signed_band(arr[:, axis], cfg.fs_hz)
                low_center = current_median / 2.0 if current_median >= 26.0 else current_median
                low = _search_fold(
                    y, cfg.fs_hz, max(6.0, low_center - 3.0), min(22.5, low_center + 3.0)
                )
                if not np.isfinite(low[1]):
                    continue
                high_center = 2.0 * low[1]
                high = _search_fold(
                    y, cfg.fs_hz, max(24.0, high_center - 2.0), min(45.0, high_center + 2.0)
                )
                if not np.isfinite(high[1]):
                    continue
                phase_r = _phase_coupling(y, cfg.fs_hz, low[1], high[1])
                raw_advantage = high[0] - low[0]

                # A stable A-B-A-B pattern at the high-period folding is strong
                # evidence that the low period is the complete mechanical cycle.
                abab = max(0.0, high[2]) if np.isfinite(high[2]) else 0.0
                abab_support = max(0.0, abab - cfg.rr_signed_abab_delta_min)

                # Phase locking is corroboration only, and only matters when the
                # low fold itself has meaningful repeatability.
                phase_support = 0.0
                if np.isfinite(phase_r) and low[0] >= cfg.rr_signed_min_fold_repeatability:
                    phase_support = max(0.0, phase_r - cfg.rr_signed_phase_coupling_min)

                decision_score = (
                    raw_advantage
                    - cfg.rr_signed_abab_weight * abab_support
                    - cfg.rr_signed_phase_weight * phase_support
                )
                channel_rows.append(
                    {
                        "loc": loc,
                        "modality": modality,
                        "axis": axis,
                        "low": low,
                        "high": high,
                        "phase_r": phase_r,
                        "raw_advantage": raw_advantage,
                        "abab_support": abab_support,
                        "phase_support": phase_support,
                        "decision_score": decision_score,
                        "y": y,
                    }
                )
                signed_channels.append((loc, modality, axis, y))

    if not channel_rows:
        out["rr_signed_state"] = "ambiguous"
        return out

    vote_high = vote_low = vote_amb = 0.0
    abab_low_total = phase_low_total = 0.0
    for row in channel_rows:
        weight = 1.25 if row["loc"] == "back" else 1.0
        score = row["decision_score"]
        if score > cfg.rr_signed_fold_advantage:
            vote_high += weight
        elif score < -cfg.rr_signed_fold_advantage:
            vote_low += weight
        else:
            vote_amb += weight
        abab_low_total += weight * row["abab_support"]
        phase_low_total += weight * row["phase_support"]

    denom = vote_high + vote_low + vote_amb + EPS
    confidence = abs(vote_high - vote_low) / denom
    winner = "high" if vote_high > vote_low else "low"
    share = max(vote_high, vote_low) / denom
    adjudicate = (
        confidence >= cfg.rr_signed_min_vote_confidence and share >= cfg.rr_signed_min_winner_share
    )

    out["rr_signed_vote_high"] = vote_high
    out["rr_signed_vote_low"] = vote_low
    out["rr_signed_vote_ambiguous"] = vote_amb
    out["rr_signed_confidence"] = confidence
    out["rr_signed_winner_share"] = share
    out["rr_signed_abab_support_low"] = abab_low_total / denom
    out["rr_signed_phase_support_low"] = phase_low_total / denom
    out["rr_signed_winner"] = winner if adjudicate else "abstain"
    out["rr_signed_state"] = f"{winner}_confirmed" if adjudicate else "ambiguous"
    if not adjudicate:
        # A persistent numerical boundary lock is first offered an independent
        # Back signed Acc+Gyro mechanical rescue.  Only if that evidence fails
        # do we fall back to the conservative unresolved/rejection behaviour.
        boundary = out["estimate"].to_numpy(float) <= cfg.rr_range_brpm[0] + 0.5
        longest = _longest_true_run(boundary)
        if longest >= int(round(cfg.rr_persistent_boundary_lock_s)):
            out["rr_boundary_rescue_triggered"] = True
            rescued = _attempt_rr_boundary_rescue(out, streams, cfg)
            if rescued is not None:
                return rescued
            was_valid = out["output_valid"].to_numpy(bool)
            out.loc[was_valid, "output_valid"] = False
            out.loc[was_valid, "rejection_reason"] = "persistent_boundary_ambiguity"
            out["rr_signed_state"] = "unresolved_persistent_boundary"
            out["rr_signed_uncertainty_action"] = (
                "segment_rr_reference_rejected_after_failed_boundary_rescue"
            )
        return out

    # Establish a global branch target only as a search centre.  It is never
    # copied across time; both high and low branches are reconstructed locally.
    low_candidates = [r["low"][1] for r in channel_rows if r["decision_score"] < -0.05]
    high_candidates = [r["high"][1] for r in channel_rows if r["decision_score"] > 0.05]
    if winner == "low" and low_candidates:
        target = float(np.median(low_candidates))
        global_spread = (
            float(1.4826 * np.median(np.abs(np.asarray(low_candidates) - target)))
            if len(low_candidates) > 1
            else 1.5
        )
    elif winner == "high" and high_candidates:
        target = float(np.median(high_candidates))
        global_spread = (
            float(1.4826 * np.median(np.abs(np.asarray(high_candidates) - target)))
            if len(high_candidates) > 1
            else 1.5
        )
    else:
        target = current_median
        global_spread = 2.0
    out["rr_mechanical_target"] = target

    # Preserve the important pre-adjudication harmonic competitor for audit
    # transparency. This is diagnostic only: it is not an active secondary mode
    # after signed confirmation and never feeds back into the estimator.
    def _parse_rates(text):
        vals = []
        if text is None:
            return vals
        for token in str(text).split(";"):
            try:
                x = float(token)
            except Exception:
                continue
            if np.isfinite(x):
                vals.append(x)
        return vals

    pool = []
    if len(out):
        try:
            a0 = float(out["anchor"].iloc[0])
            if np.isfinite(a0):
                pool.append(a0)
        except Exception:
            pass
        if "anchor_alternatives" in out.columns:
            pool.extend(_parse_rates(out["anchor_alternatives"].iloc[0]))

    if winner == "high":
        desired = 0.5 * target
        plausible = [x for x in pool if cfg.rr_range_brpm[0] <= x <= 22.5]
        branch_type = "f/2"
    else:
        desired = 2.0 * target
        plausible = [x for x in pool if 24.0 <= x <= cfg.rr_range_brpm[1]]
        branch_type = "2f"
    if plausible:
        suppressed = min(plausible, key=lambda x: abs(x - desired))
        # Only disclose a branch that was genuinely close enough to the expected
        # harmonic counterpart; do not manufacture a diagnostic value.
        if abs(suppressed - desired) <= 4.0:
            out["rr_suppressed_branch"] = float(suppressed)
            out["rr_suppressed_branch_type"] = branch_type
            out["rr_suppressed_branch_reason"] = f"signed_{winner}_confirmed"

    # Back zero crossings are useful for a confirmed high branch because the
    # complete signed oscillation itself is then the high-rate mechanical cycle.
    back_crossings = []
    if winner == "high":
        for row in channel_rows:
            if row["loc"] == "back":
                back_crossings.append(_crossing_times(row["y"], cfg.fs_hz))

    n = min(len(acc) for acc, _ in streams.values())
    morph = np.full(len(out), np.nan)
    local_spread = np.full(len(out), np.nan)
    local_n = np.zeros(len(out), int)

    for ti in range(len(out)):
        i0, i1, _ = second_window(n, cfg.fs_hz, int(ti), cfg.rr_window_s / 2.0, cfg.rr_min_window_s)
        start, end = i0 / cfg.fs_hz, i1 / cfg.fs_hz
        rates = []

        if winner == "high":
            for crossings in back_crossings:
                c = crossings[(crossings >= start) & (crossings <= end)]
                if len(c) < 5:
                    continue
                rr = 60.0 / np.diff(c)
                ok_rr = (rr >= max(24.0, target - 5.0)) & (rr <= min(45.0, target + 5.0))
                rr = rr[ok_rr]
                if len(rr) >= 4:
                    rates.append(float(60.0 / np.median(60.0 / rr)))
        else:
            # Re-estimate the low branch inside each local RR window so that the
            # rescued trajectory follows local evidence instead of a constant
            # fallback line.
            for row in channel_rows:
                if row["decision_score"] >= 0.0:
                    continue
                seg = row["y"][i0:i1]
                if len(seg) < int(cfg.rr_min_window_s * cfg.fs_hz):
                    continue
                best = _local_fold_rate(seg, cfg.fs_hz, target, half_window=3.0)
                if np.isfinite(best[1]) and best[0] >= cfg.rr_signed_local_min_repeatability:
                    rates.append(float(best[1]))

        if rates:
            arr = np.asarray(rates, float)
            med = float(np.median(arr))
            # Remove clearly discordant axes while preserving local variation.
            arr = arr[np.abs(arr - med) <= (3.5 if winner == "high" else 2.5)]
            if len(arr):
                morph[ti] = float(np.median(arr))
                local_spread[ti] = (
                    float(1.4826 * np.median(np.abs(arr - np.median(arr))))
                    if len(arr) > 1
                    else global_spread
                )
                local_n[ti] = len(arr)

    ok = np.isfinite(morph)
    if ok.sum() >= 2:
        morph = np.interp(np.arange(len(morph)), np.flatnonzero(ok), morph[ok])
        local_spread = (
            np.interp(
                np.arange(len(local_spread)),
                np.flatnonzero(np.isfinite(local_spread)),
                local_spread[np.isfinite(local_spread)],
            )
            if np.isfinite(local_spread).sum() >= 2
            else np.full(len(out), global_spread)
        )
    else:
        # If local morphology cannot be reconstructed, do not force a global
        # constant.  Preserve the baseline track and mark no adjudication.
        out["rr_signed_state"] = "ambiguous_local_reconstruction"
        out["rr_signed_winner"] = "abstain"
        out["rr_signed_adjudicated"] = False
        return out

    # Light smoothing only: 3 samples.  The original 5+3 cascade was capable of
    # erasing legitimate slow RR changes in highly overlapping 30 s windows.
    morph = ndimage.median_filter(morph, size=3, mode="nearest")

    current = out["estimate"].to_numpy(float)
    # Never let morphology completely overwrite temporal information.  Even at
    # perfect global vote confidence, retain at least 25% of the baseline track.
    fusion_weight = float(min(cfg.rr_signed_max_morphology_weight, confidence))
    fused = fusion_weight * morph + (1.0 - fusion_weight) * current
    track = np.round(fused / cfg.rr_step_brpm) * cfg.rr_step_brpm

    # Dynamic uncertainty: no manual ±4 cap.  The signed gate may reduce only
    # the f/2f branch component of uncertainty.  Within-branch variability is
    # still driven by the baseline interval, local axis spread, temporal
    # excursion, evidence, stationarity, and local axis support.
    baseline_half = out["primary_halfwidth"].to_numpy(float)
    evidence = out["evidence"].to_numpy(float)
    stationarity = out["stationarity"].to_numpy(float)
    half = np.zeros(len(track), float)
    for i in range(len(track)):
        local = track[max(0, i - 8) : min(len(track), i + 9)]
        excursion = float(np.percentile(local, 90) - np.percentile(local, 10))
        sp = float(local_spread[i]) if np.isfinite(local_spread[i]) else global_spread
        axis_penalty = 0.75 if local_n[i] < 3 else (0.35 if local_n[i] < 5 else 0.0)
        within_branch = (
            cfg.rr_base_halfwidth_brpm
            + 0.45 * min(sp, 4.0)
            + 0.42 * excursion
            + 0.75 * (1.0 - confidence)
            + 0.55 * (1.0 - evidence[i])
            + 0.35 * max(0.0, 0.65 - stationarity[i])
            + axis_penalty
        )
        # Signed confirmation cannot make the interval wider than baseline, but
        # neither can it push below the estimator's original RR base width.
        half[i] = float(
            np.clip(
                min(baseline_half[i], within_branch),
                cfg.rr_base_halfwidth_brpm,
                cfg.rr_max_halfwidth_brpm,
            )
        )

    low = np.maximum(cfg.rr_range_brpm[0], track - half)
    high = np.minimum(cfg.rr_range_brpm[1], track + half)

    # Apply only to windows already accepted by the baseline validity gate.
    for i in np.flatnonzero(valid):
        out.at[i, "estimate"] = float(track[i])
        out.at[i, "primary_low"] = float(low[i])
        out.at[i, "primary_high"] = float(high[i])
        out.at[i, "primary_halfwidth"] = float(half[i])
        old_secondary = (
            float(out.at[i, "secondary_mode"])
            if np.isfinite(out.at[i, "secondary_mode"])
            else np.nan
        )
        remove_secondary = (
            (not np.isfinite(old_secondary))
            or abs(old_secondary - track[i]) <= 3.0
            or min(abs(2.0 * old_secondary - track[i]), abs(old_secondary - 2.0 * track[i])) <= 6.0
        )
        if remove_secondary:
            out.at[i, "secondary_mode"] = np.nan
            out.at[i, "secondary_low"] = np.nan
            out.at[i, "secondary_high"] = np.nan
            out.at[i, "interval_mode_count"] = 1
            out.at[i, "second_mode_ratio"] = 0.0
            out.at[i, "conservative_low"] = float(low[i])
            out.at[i, "conservative_high"] = float(high[i])
        else:
            out.at[i, "interval_mode_count"] = 2
            out.at[i, "conservative_low"] = min(float(low[i]), float(out.at[i, "secondary_low"]))
            out.at[i, "conservative_high"] = max(float(high[i]), float(out.at[i, "secondary_high"]))
        out.at[i, "rr_signed_adjudicated"] = True
        out.at[i, "rr_signed_uncertainty_action"] = (
            "branch_uncertainty_reduced_dynamic_within_branch_retained"
        )
    return out
