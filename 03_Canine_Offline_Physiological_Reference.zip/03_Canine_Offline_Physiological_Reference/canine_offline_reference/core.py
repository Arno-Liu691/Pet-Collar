from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

import numpy as np
from scipy import ndimage, signal

from .candidates import Candidate, hr_candidates, rr_candidates
from .config import ReferenceConfig
from .signal import motion_features, stationarity_score

EPS = 1e-12


@dataclass
class EvidenceBundle:
    vital: str
    grid: np.ndarray
    times_s: np.ndarray
    spectral_score: np.ndarray
    spectral_z: np.ndarray
    block_score: np.ndarray
    consensus_score: np.ndarray
    consensus_center: np.ndarray
    consensus_evidence: np.ndarray
    consensus_spread: np.ndarray
    consensus_family_count: np.ndarray
    consensus_source_count: np.ndarray
    stationarity: np.ndarray
    motion: list[dict]
    anchor: float
    anchor_alternatives: list[float]
    anchor_alternative_strengths: list[float]


def robust_z(v: np.ndarray) -> np.ndarray:
    v = np.asarray(v, float)
    med = np.nanmedian(v)
    mad = np.nanmedian(np.abs(v - med)) + 1e-9
    return (v - med) / (1.4826 * mad)


def fft_prominence(x: np.ndarray, fs: float, lo: float, hi: float, nfft: int = 16384):
    x = np.asarray(x, float)
    if x.ndim == 1:
        x = x[:, None]
    x = signal.detrend(x, axis=0, type="linear")
    window = signal.windows.hann(len(x), sym=False)[:, None]
    spec = np.fft.rfft(x * window, n=nfft, axis=0)
    power = (np.abs(spec) ** 2).sum(axis=1)
    freq = np.fft.rfftfreq(nfft, 1.0 / fs)
    mask = (freq >= lo) & (freq <= hi)
    freq = freq[mask]
    db = 10.0 * np.log10(power[mask] + 1e-30)
    kernel = min(61, (len(db) // 2) * 2 + 1)
    kernel = max(3, kernel)
    baseline = signal.medfilt(db, kernel_size=kernel)
    return freq, db - baseline


def second_window(n: int, fs: float, sec: int, half_s: float, min_s: float):
    duration = n / fs
    center = min(sec + 0.5, duration - 0.005)
    start = max(0.0, center - half_s)
    end = min(duration, center + half_s)
    if end - start < min_s:
        if start <= 1e-9:
            end = min(duration, min_s)
        else:
            start = max(0.0, duration - min_s)
    return int(round(start * fs)), int(round(end * fs)), center


def _physical_blocks(streams: Mapping[str, tuple[np.ndarray, np.ndarray]]):
    blocks = {}
    for source, (acc, gyro) in streams.items():
        blocks[f"{source}:acc"] = np.asarray(acc, float)
        blocks[f"{source}:gyro"] = np.asarray(gyro, float)
    return blocks


def _method_group(family: str) -> str:
    if family.startswith("rr_"):
        if "cepstrum" in family:
            return "rr_cepstrum"
        if "acf" in family:
            return "rr_acf"
        return "rr_psd"
    if "event" in family:
        return "hr_event"
    if "envelope" in family and "acf" in family:
        return "hr_envelope_acf"
    if "envelope" in family and "psd" in family:
        return "hr_envelope_psd"
    if "direct" in family and "acf" in family:
        return "hr_direct_acf"
    return "hr_direct_psd"


def _method_weight(group: str) -> float:
    return {
        "rr_psd": 1.20,
        "rr_acf": 1.00,
        "rr_cepstrum": 0.30,
        "hr_envelope_psd": 1.15,
        "hr_envelope_acf": 1.10,
        "hr_direct_acf": 0.55,
        "hr_direct_psd": 0.45,
        "hr_event": 0.45,
    }.get(group, 1.0)


def _candidate_density(
    candidates: list[Candidate], grid: np.ndarray, sigma: float, expected_sources: int
):
    # One correlated family/source pair contributes at most one candidate.
    best = {}
    for candidate in candidates:
        source = candidate.source.split(":b")[0]
        key = (_method_group(candidate.family), source)
        if key not in best or candidate.score > best[key].score:
            best[key] = candidate
    candidates = list(best.values())
    if not candidates:
        return np.zeros_like(grid), np.nan, 0.0, np.nan, 0, 0

    group_count = {}
    for candidate in candidates:
        group = _method_group(candidate.family)
        group_count[group] = group_count.get(group, 0) + 1
    density = np.zeros_like(grid)
    for candidate in candidates:
        group = _method_group(candidate.family)
        modality_weight = 0.68 if candidate.family.endswith("_gyro") else 1.0
        weight = _method_weight(group) * modality_weight * candidate.score / group_count[group]
        # Direct candidates only: the spectral f+2f surface already represents
        # harmonic relations. Adding synthetic 1/2x or 2x copies here would bias RR.
        density += weight * np.exp(-0.5 * ((grid - candidate.value) / sigma) ** 2)

    center0 = float(grid[int(np.argmax(density))])
    local = np.array([abs(c.value - center0) <= 2.5 * sigma for c in candidates])
    if not local.any():
        return density, center0, 0.0, np.nan, 0, 0
    values = np.array([c.value for c in candidates], float)[local]
    weights = np.array([c.score for c in candidates], float)[local]
    order = np.argsort(values)
    values, weights = values[order], weights[order]
    center = float(values[np.searchsorted(np.cumsum(weights), weights.sum() / 2.0)])
    spread_values = np.abs(values - center)
    order = np.argsort(spread_values)
    spread_values, spread_weights = spread_values[order], weights[order]
    spread = float(
        1.4826
        * spread_values[np.searchsorted(np.cumsum(spread_weights), spread_weights.sum() / 2.0)]
    )
    families = len({_method_group(c.family) for c, ok in zip(candidates, local) if ok})
    sources = len({c.source.split(":b")[0] for c, ok in zip(candidates, local) if ok})
    coherence = float(weights.sum() / (sum(c.score for c in candidates) + EPS))
    family_support = min(1.0, families / 3.0)
    source_support = min(1.0, sources / max(1, expected_sources))
    evidence = float(
        np.clip(0.45 * coherence + 0.35 * family_support + 0.20 * source_support, 0.0, 1.0)
    )
    return density, center, evidence, spread, families, sources


def _whole_rr_anchor(blocks: Mapping[str, np.ndarray], cfg: ReferenceConfig):
    peaks_by_block = {}
    for name, raw in blocks.items():
        f, power = signal.welch(
            signal.detrend(raw, axis=0),
            fs=cfg.fs_hz,
            nperseg=min(4096, len(raw)),
            noverlap=min(3072, len(raw) - 1),
            nfft=65536,
            axis=0,
            average="median",
        )
        power = power.sum(axis=1)
        rr_spectral_high = 1.05 if cfg.rr_range_brpm[1] <= 30.0 else 1.60
        mask = (f >= 0.08) & (f <= rr_spectral_high)
        rate = f[mask] * 60.0
        db = 10.0 * np.log10(power[mask] + 1e-30)
        kernel = min(101, (len(db) // 2) * 2 + 1)
        prom = db - signal.medfilt(db, kernel_size=max(3, kernel))
        inds = signal.find_peaks(
            prom, distance=max(1, int(1.5 / (rate[1] - rate[0]))), prominence=0.1
        )[0]
        peaks_by_block[name] = (rate[inds], prom[inds])

    fine = np.arange(cfg.rr_range_brpm[0], cfg.rr_range_brpm[1] + 1e-9, 0.1)
    score = np.zeros_like(fine)
    for i, value in enumerate(fine):
        direct_support, harmonic_support = [], []
        for rates, prominence in peaks_by_block.values():
            direct = prominence[np.abs(rates - value) <= 1.3]
            harmonic = prominence[np.abs(rates - 2.0 * value) <= 2.0]
            direct_support.append(max(0.0, float(direct.max())) if len(direct) else 0.0)
            harmonic_support.append(max(0.0, float(harmonic.max())) if len(harmonic) else 0.0)
        direct_blocks = sum(x > 0.2 for x in direct_support)
        harmonic_blocks = sum(x > 0.2 for x in harmonic_support)
        score[i] = (
            sum(direct_support)
            + 0.65 * sum(harmonic_support)
            + 1.0 * min(direct_blocks, 2)
            + 0.8 * min(harmonic_blocks, 2)
            - (8.0 if direct_blocks == 0 else 0.0)
        )
    peak_inds = signal.find_peaks(score, distance=max(1, int(2.0 / 0.1)))[0]
    if len(peak_inds) == 0:
        peak_inds = np.array([int(np.argmax(score))])
    ranked = peak_inds[np.argsort(score[peak_inds])[::-1]]
    anchor = float(fine[ranked[0]])
    # Keep the leading alternate families even when the main direct peak is much
    # stronger. Their role is ambiguity disclosure (especially f versus 2f),
    # not competition for the primary anchor.
    alternatives = [float(fine[i]) for i in ranked[1:6]]
    denominator = max(float(score[ranked[0]]), EPS)
    strengths = [float(np.clip(score[i] / denominator, 0.0, 1.0)) for i in ranked[1:6]]
    return anchor, alternatives, strengths


def _hr_anchor(score: np.ndarray, grid: np.ndarray):
    normalized = np.vstack([robust_z(row) for row in score])
    persistence = np.quantile(normalized, 0.70, axis=0)
    peaks = signal.find_peaks(persistence, distance=max(1, int(6.0 / (grid[1] - grid[0]))))[0]
    if len(peaks) == 0:
        peaks = np.array([int(np.argmax(persistence))])
    ranked = peaks[np.argsort(persistence[peaks])[::-1]]
    anchor = float(grid[ranked[0]])
    alternatives = [
        float(grid[i]) for i in ranked[1:6] if persistence[i] >= persistence[ranked[0]] - 2.0
    ]
    strengths = [
        float(np.exp(np.clip(persistence[i] - persistence[ranked[0]], -20.0, 0.0)))
        for i in ranked[1:6]
        if persistence[i] >= persistence[ranked[0]] - 2.0
    ]
    return anchor, alternatives, strengths


def build_evidence(
    streams: Mapping[str, tuple[np.ndarray, np.ndarray]], vital: str, cfg: ReferenceConfig
) -> EvidenceBundle:
    if not streams:
        raise ValueError("At least one synchronized stream is required")
    lengths = {len(a) for a, _ in streams.values()} | {len(g) for _, g in streams.values()}
    if len(lengths) != 1:
        raise ValueError("All ACC/GYR streams must be exactly synchronized")
    n = lengths.pop()
    total_seconds = int(np.ceil(n / cfg.fs_hz))
    times = np.arange(total_seconds, dtype=float) + 0.5
    blocks = _physical_blocks(streams)
    grid = cfg.hr_grid if vital == "hr" else cfg.rr_grid
    half = (cfg.hr_window_s if vital == "hr" else cfg.rr_window_s) / 2.0
    minimum = cfg.hr_min_window_s if vital == "hr" else cfg.rr_min_window_s
    sigma = cfg.hr_consensus_sigma_bpm if vital == "hr" else cfg.rr_consensus_sigma_brpm

    envelopes = None
    if vital == "hr":
        envelopes = {name: {} for name in blocks}
        for name, raw in blocks.items():
            for band in cfg.hr_filterbanks_hz:
                sos = signal.butter(
                    4, [band[0], band[1]], btype="bandpass", fs=cfg.fs_hz, output="sos"
                )
                filtered = signal.sosfiltfilt(sos, raw, axis=0)
                envelopes[name][band] = np.sqrt(
                    np.sum(np.abs(signal.hilbert(filtered, axis=0)) ** 2, axis=1)
                )[:, None]

    spectral = np.zeros((total_seconds, len(grid)))
    block_score = np.zeros((total_seconds, len(blocks), len(grid)))
    consensus = np.zeros_like(spectral)
    consensus_center = np.full(total_seconds, np.nan)
    consensus_evidence = np.zeros(total_seconds)
    consensus_spread = np.full(total_seconds, np.nan)
    consensus_family_count = np.zeros(total_seconds, int)
    consensus_source_count = np.zeros(total_seconds, int)
    stationarity = np.zeros(total_seconds)
    motion_rows: list[dict] = []

    for sec in range(total_seconds):
        i0, i1, _ = second_window(n, cfg.fs_hz, sec, half, minimum)
        for block_i, (name, raw) in enumerate(blocks.items()):
            if vital == "rr":
                rr_spectral_high = 1.05 if cfg.rr_range_brpm[1] <= 30.0 else 1.60
                f, prom = fft_prominence(raw[i0:i1], cfg.fs_hz, 0.08, rr_spectral_high)
                fundamental = np.interp(grid / 60.0, f, prom)
                harmonic = np.interp(2.0 * grid / 60.0, f, prom, left=-8.0, right=-8.0)
                values = fundamental + 0.65 * np.maximum(harmonic, 0.0) + 0.5 * (fundamental > 0.5)
            else:
                values = np.zeros(len(grid))
                for band, weight in (
                    (cfg.hr_filterbanks_hz[0], 1.0),
                    (cfg.hr_filterbanks_hz[1], 1.0),
                    (cfg.hr_filterbanks_hz[2], 0.7),
                ):
                    hr_spectral_low = 0.65 if cfg.hr_range_bpm[0] >= 45.0 else 0.60
                    hr_spectral_high = 2.35 if cfg.hr_range_bpm[1] <= 130.0 else 2.85
                    f, prom = fft_prominence(
                        envelopes[name][band][i0:i1], cfg.fs_hz, hr_spectral_low, hr_spectral_high
                    )
                    values += weight * np.interp(grid / 60.0, f, prom)
            block_score[sec, block_i] = values
            spectral[sec] += values

        candidates = []
        per_source_motion = []
        for source, (acc, gyro) in streams.items():
            acc_win = np.asarray(acc[i0:i1], float)
            gyro_win = np.asarray(gyro[i0:i1], float)
            per_source_motion.append(motion_features(acc_win, gyro_win, cfg.fs_hz))
            candidates.extend(
                hr_candidates(acc_win, gyro_win, cfg, source)
                if vital == "hr"
                else rr_candidates(acc_win, gyro_win, cfg, source)
            )
        merged_motion = {
            key: float(max(row[key] for row in per_source_motion)) for key in per_source_motion[0]
        }
        motion_rows.append(merged_motion)
        stationarity[sec] = stationarity_score(merged_motion)
        density, center, evidence, spread, families, sources = _candidate_density(
            candidates, grid, sigma, len(streams)
        )
        consensus[sec] = density
        consensus_center[sec] = center
        consensus_evidence[sec] = evidence * (0.72 + 0.28 * stationarity[sec])
        consensus_spread[sec] = spread
        consensus_family_count[sec] = families
        consensus_source_count[sec] = sources

    spectral = ndimage.gaussian_filter(spectral, sigma=(1.2, 0.8) if vital == "rr" else (1.5, 1.0))
    spectral_z = np.vstack([robust_z(row) for row in spectral])
    if vital == "rr":
        anchor, alternatives, alternative_strengths = _whole_rr_anchor(blocks, cfg)
    else:
        anchor, alternatives, alternative_strengths = _hr_anchor(spectral, grid)
    return EvidenceBundle(
        vital=vital,
        grid=grid,
        times_s=times,
        spectral_score=spectral,
        spectral_z=spectral_z,
        block_score=block_score,
        consensus_score=consensus,
        consensus_center=consensus_center,
        consensus_evidence=consensus_evidence,
        consensus_spread=consensus_spread,
        consensus_family_count=consensus_family_count,
        consensus_source_count=consensus_source_count,
        stationarity=stationarity,
        motion=motion_rows,
        anchor=anchor,
        anchor_alternatives=alternatives,
        anchor_alternative_strengths=alternative_strengths,
    )


def combined_score(
    bundle: EvidenceBundle, cfg: ReferenceConfig, consensus_weight: float | None = None
):
    weight = (
        (cfg.hr_consensus_weight if bundle.vital == "hr" else cfg.rr_consensus_weight)
        if consensus_weight is None
        else consensus_weight
    )
    normalized_consensus = np.zeros_like(bundle.consensus_score)
    for i, row in enumerate(bundle.consensus_score):
        peak = float(np.max(row))
        if peak > EPS:
            normalized_consensus[i] = row / peak
    return (
        bundle.spectral_z + weight * bundle.consensus_evidence[:, None] * 3.0 * normalized_consensus
    )


def viterbi_track(
    score: np.ndarray,
    grid: np.ndarray,
    anchor: float,
    transition_scale: float,
    transition_penalty: float,
    prior_scale: float,
    prior_penalty: float,
):
    # Apply light time/rate smoothing before the non-causal dynamic program to reduce isolated score-surface jitter.
    smoothed = ndimage.gaussian_filter(score, sigma=(1.3, 0.8))
    prior = -prior_penalty * ((grid - anchor) / prior_scale) ** 2
    t_count, rate_count = smoothed.shape
    dp = np.full((t_count, rate_count), -1e12)
    previous = np.zeros((t_count, rate_count), np.int16)
    dp[0] = smoothed[0] + prior
    transition = -transition_penalty * ((grid[:, None] - grid[None, :]) / transition_scale) ** 2
    for t in range(1, t_count):
        values = dp[t - 1][:, None] + transition
        indices = np.argmax(values, axis=0)
        previous[t] = indices.astype(np.int16)
        dp[t] = values[indices, np.arange(rate_count)] + smoothed[t] + prior
    indices = np.zeros(t_count, int)
    indices[-1] = int(np.argmax(dp[-1]))
    for t in range(t_count - 2, -1, -1):
        indices[t] = previous[t + 1, indices[t + 1]]
    return grid[indices], smoothed
