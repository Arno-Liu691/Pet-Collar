from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd


def discover_human_recordings(root: str | Path):
    root = Path(root)
    found = []
    for path in root.rglob("input.csv"):
        if path.parent.name.startswith("human_test_"):
            found.append(path.parent)
    return sorted(set(found), key=lambda path: path.name)


def load_human_recording(folder: str | Path):
    folder = Path(folder)
    raw = pd.read_csv(folder / "input.csv")
    refs = list(folder.glob("*reference.csv")) + list(folder.glob("*validation.csv"))
    if len(refs) != 1:
        raise ValueError(f"Expected one reference CSV in {folder}, found {refs}")
    ref = pd.read_csv(refs[0], encoding="utf-8-sig")
    acc = raw[["ax", "ay", "az"]].to_numpy(float)
    gyro = raw[["gx", "gy", "gz"]].to_numpy(float)
    return raw, ref, {"left_chest": (acc, gyro)}


def _hr_reference_column(ref: pd.DataFrame):
    exact = [column for column in ref.columns if str(column).strip().upper() == "HR"]
    if exact:
        return exact[0]
    # Test 04 stores HR in an unnamed final column. Exclude the time axis and
    # respiratory metadata, then choose the slowly varying rate-like column.
    excluded = {
        str(ref.columns[0]),
        "instant_rr_bpm",
        "rr_10s_trailing_bpm",
        "rr_30s_trailing_bpm",
        "rr_40s_trailing_bpm",
        "breath_interval_no",
        "interval_start_s",
        "interval_end_s",
        "interval_duration_s",
    }
    candidates = []
    for column in ref.columns:
        if str(column) in excluded:
            continue
        values = pd.to_numeric(ref[column], errors="coerce")
        finite = values.dropna().to_numpy(float)
        if len(finite) < 100 or not (45.0 < np.median(finite) < 130.0):
            continue
        roughness = float(np.nanmedian(np.abs(np.diff(finite)))) if len(finite) > 1 else np.inf
        candidates.append((roughness, -list(ref.columns).index(column), column))
    if not candidates:
        raise ValueError("Could not identify the HR reference column")
    return sorted(candidates)[0][2]


def reference_arrays(ref: pd.DataFrame):
    time = pd.to_numeric(ref.iloc[:, 0], errors="coerce").to_numpy(float)
    hr = pd.to_numeric(ref[_hr_reference_column(ref)], errors="coerce").to_numpy(float)
    rr = pd.to_numeric(ref["instant_rr_bpm"], errors="coerce").to_numpy(float)
    return time, hr, rr


def centered_reference(ref: pd.DataFrame, times: np.ndarray, vital: str, half_s: float):
    ref_time, hr, rr = reference_arrays(ref)
    values = hr if vital == "hr" else rr
    result = np.full(len(times), np.nan)
    minimum_count = 12 if vital == "hr" else 22
    for i, center in enumerate(np.asarray(times, float)):
        mask = (ref_time >= center - half_s) & (ref_time <= center + half_s) & np.isfinite(values)
        if int(mask.sum()) >= minimum_count:
            result[i] = float(np.nanmedian(values[mask]))
    return result


def motion_condition(recording: str, vital: str, times: np.ndarray, half_s: float):
    if "04_disruption" not in recording:
        return np.full(len(times), "nominal", dtype=object)
    conditions = []
    for center in times:
        start, end = center - half_s, center + half_s
        if start <= 203 and end >= 201:
            conditions.append("severe_overlap")
        elif 203 < center <= 203 + 2 * half_s:
            conditions.append("post_severe_recovery")
        elif start <= 158 and end >= 155:
            conditions.append("moderate_overlap")
        elif start <= 100 and end >= 69:
            conditions.append("low_sway_overlap")
        else:
            conditions.append("nominal")
    return np.asarray(conditions, dtype=object)


def load_canine_segment(folder: str | Path):
    folder = Path(folder)
    streams = {}
    for location in ("neck", "back"):
        data = np.load(folder / location / f"{location}_raw.npz")
        streams[location] = (np.asarray(data["acc_g"], float), np.asarray(data["gyro_dps"], float))
    metadata = json.loads((folder / "segment_meta.json").read_text(encoding="utf-8"))
    return streams, metadata


def canine_segment_folders(root: str | Path):
    return sorted(path.parent for path in Path(root).rglob("segment_meta.json"))
