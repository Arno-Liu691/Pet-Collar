from __future__ import annotations

from typing import Mapping

import numpy as np
import pandas as pd
from scipy import signal

from .config import ReferenceConfig
from .core import EvidenceBundle, build_evidence, combined_score, viterbi_track
from .adjudication import apply_hr_location_adjudication, apply_rr_signed_adjudication

EPS = 1e-12


def _local_block_centers(bundle: EvidenceBundle, time_index: int, center: float):
    near = 15.0 if bundle.vital == "hr" else 4.0
    tolerance = 8.0 if bundle.vital == "hr" else 2.5
    mask = np.abs(bundle.grid - center) <= near
    indices = np.flatnonzero(mask)
    centers = []
    for block in bundle.block_score[time_index]:
        local_i = indices[int(np.argmax(block[mask]))]
        centers.append(float(bundle.grid[local_i]))
    centers = np.asarray(centers)
    inliers = centers[np.abs(centers - center) <= tolerance]
    return centers, inliers, tolerance


def _alternative_modes(row: np.ndarray, grid: np.ndarray, center: float, vital: str):
    separation = 12.0 if vital == "hr" else 4.0
    min_peak_distance = 5.0 if vital == "hr" else 1.5
    drop = 1.65 if vital == "hr" else 1.80
    distance = max(1, int(round(min_peak_distance / (grid[1] - grid[0]))))
    peaks = signal.find_peaks(row, distance=distance)[0]
    if len(peaks) == 0:
        return []
    best = float(np.max(row))
    alternatives = []
    for index in peaks[np.argsort(row[peaks])[::-1]]:
        value = float(grid[index])
        if abs(value - center) >= separation and row[index] >= best - drop:
            alternatives.append((value, float(np.exp(row[index] - best))))
    return alternatives[:3]


def _interval_rows(
    bundle: EvidenceBundle,
    track: np.ndarray,
    score: np.ndarray,
    cfg: ReferenceConfig,
    duration_s: float,
    enforce_formal_duration: bool,
    use_consensus_interval: bool,
):
    vital = bundle.vital
    low_limit, high_limit = cfg.hr_range_bpm if vital == "hr" else cfg.rr_range_brpm
    base = cfg.hr_base_halfwidth_bpm if vital == "hr" else cfg.rr_base_halfwidth_brpm
    max_half = cfg.hr_max_halfwidth_bpm if vital == "hr" else cfg.rr_max_halfwidth_brpm
    formal_min = cfg.hr_formal_min_duration_s if vital == "hr" else cfg.rr_formal_min_duration_s
    # A centered estimator changes branch over a finite interval. The local
    # p90-p10 trajectory excursion is therefore a direct, label-free cue that
    # the interval must widen during transitions rather than lag behind them.
    local_excursion = np.zeros(len(track))
    edge_fraction = np.zeros(len(track))
    radius = 8
    for index in range(len(track)):
        local = track[max(0, index - radius) : min(len(track), index + radius + 1)]
        local_excursion[index] = float(np.percentile(local, 90) - np.percentile(local, 10))
        available_half = min(
            float(bundle.times_s[index]), max(0.0, duration_s - float(bundle.times_s[index]))
        )
        nominal_half = (cfg.hr_window_s if vital == "hr" else cfg.rr_window_s) / 2.0
        edge_fraction[index] = float(
            np.clip((nominal_half - available_half) / nominal_half, 0.0, 1.0)
        )
    rows = []
    for i, center in enumerate(track):
        block_centers, inliers, tolerance = _local_block_centers(bundle, i, center)
        support_fraction = float(len(inliers) / max(1, len(block_centers)))
        block_spread = (
            float(1.4826 * np.median(np.abs(inliers - np.median(inliers))))
            if len(inliers)
            else tolerance
        )
        alternatives = _alternative_modes(score[i], bundle.grid, center, vital)
        if vital == "rr":
            primary_peak_for_ratio = float(np.max(score[i]))
            harmonic_anchor_candidates = [
                (bundle.anchor, 1.0),
                *zip(bundle.anchor_alternatives, bundle.anchor_alternative_strengths),
            ]
            for candidate, segment_strength in harmonic_anchor_candidates:
                harmonic_match = (
                    min(abs(2.0 * candidate - center), abs(candidate - 2.0 * center)) <= 6.0
                )
                if not harmonic_match or abs(candidate - center) < 4.0 or segment_strength < 0.35:
                    continue
                candidate_i = int(np.argmin(np.abs(bundle.grid - candidate)))
                candidate_ratio = float(
                    np.exp(np.clip(score[i, candidate_i] - primary_peak_for_ratio, -20.0, 0.0))
                )
                if not any(abs(value - candidate) < 1.0 for value, _ in alternatives):
                    # A segment-level f/2f relation is a reason to disclose an
                    # alternative only when it is genuinely strong.  Scaling
                    # by its relative whole-record spectral support suppresses
                    # the ubiquitous weak second harmonic seen in stable human
                    # breathing, while preserving D027/D046-like ambiguity.
                    alternatives.insert(
                        0, (float(candidate), max(candidate_ratio, 0.60 * segment_strength))
                    )
                    break
        second_mode = alternatives[0][0] if alternatives else np.nan
        second_ratio = alternatives[0][1] if alternatives else 0.0

        # Peak uniqueness is calculated from the combined evidence surface, not
        # from any reference labels.
        center_mask = np.abs(bundle.grid - center) <= (6.0 if vital == "hr" else 2.0)
        primary_peak = float(np.max(score[i, center_mask]))
        remote = score[i].copy()
        remote[center_mask] = -np.inf
        remote_peak = float(np.max(remote))
        uniqueness = float(np.clip((primary_peak - remote_peak + 0.25) / 2.0, 0.0, 1.0))
        consensus_evidence = float(bundle.consensus_evidence[i]) if use_consensus_interval else 0.0
        evidence = float(
            np.clip(
                0.48 * support_fraction
                + (0.24 * consensus_evidence if use_consensus_interval else 0.0)
                + (0.18 if not use_consensus_interval else 0.14) * uniqueness
                + (0.34 if not use_consensus_interval else 0.14) * bundle.stationarity[i],
                0.0,
                1.0,
            )
        )
        consensus_center = bundle.consensus_center[i]
        disagreement = (
            abs(consensus_center - center)
            if use_consensus_interval and np.isfinite(consensus_center)
            else 0.0
        )
        consensus_spread = (
            bundle.consensus_spread[i]
            if use_consensus_interval and np.isfinite(bundle.consensus_spread[i])
            else 0.0
        )
        if vital == "hr":
            halfwidth = (
                base
                + 0.50 * block_spread
                + 0.22 * consensus_spread
                + 0.18 * min(disagreement, 25.0)
                + 0.58 * local_excursion[i]
                + 6.0 * edge_fraction[i]
                + 4.8 * (1.0 - evidence)
                + 2.0 * max(0.0, 0.65 - bundle.stationarity[i])
            )
        else:
            halfwidth = (
                base
                + 0.52 * block_spread
                + 0.20 * consensus_spread
                + 0.16 * min(disagreement, 10.0)
                + 0.58 * local_excursion[i]
                + 1.5 * edge_fraction[i]
                + 2.2 * (1.0 - evidence)
                + 0.8 * max(0.0, 0.65 - bundle.stationarity[i])
            )
        halfwidth = float(np.clip(halfwidth, base, max_half))
        primary_low = float(max(low_limit, center - halfwidth))
        primary_high = float(min(high_limit, center + halfwidth))

        # A competing remote mode is kept as a disjoint interval. This avoids
        # averaging f and 2f and avoids claiming that the values between them are
        # supported by the signal.
        secondary_low = secondary_high = np.nan
        mode_count = 1
        if alternatives and second_ratio >= (0.55 if vital == "hr" else 0.45):
            secondary_half = float(base * (0.72 if vital == "hr" else 0.80))
            secondary_low = max(low_limit, second_mode - secondary_half)
            secondary_high = min(high_limit, second_mode + secondary_half)
            mode_count = 2
        conservative_low = (
            float(min(primary_low, secondary_low)) if np.isfinite(secondary_low) else primary_low
        )
        conservative_high = (
            float(max(primary_high, secondary_high))
            if np.isfinite(secondary_high)
            else primary_high
        )

        duration_eligible = duration_s >= formal_min if enforce_formal_duration else True
        rejection = ""
        if not duration_eligible:
            rejection = "insufficient_duration"
        elif bundle.stationarity[i] < cfg.reject_stationarity_below:
            rejection = "motion_contamination"
        elif (
            vital == "rr"
            and center <= low_limit + 0.5
            and use_consensus_interval
            and disagreement > 3.0
        ):
            rejection = "boundary_lock"
        elif evidence < cfg.reject_evidence_below:
            rejection = "weak_evidence"
        output_valid = rejection == ""
        motion = bundle.motion[i]
        rows.append(
            {
                "time_s": float(bundle.times_s[i]),
                "estimate": float(center),
                "primary_low": primary_low,
                "primary_high": primary_high,
                "secondary_mode": float(second_mode) if mode_count == 2 else np.nan,
                "secondary_low": float(secondary_low) if mode_count == 2 else np.nan,
                "secondary_high": float(secondary_high) if mode_count == 2 else np.nan,
                "conservative_low": conservative_low,
                "conservative_high": conservative_high,
                "primary_halfwidth": halfwidth,
                "interval_mode_count": mode_count,
                "second_mode_ratio": float(second_ratio),
                "evidence": evidence,
                "stationarity": float(bundle.stationarity[i]),
                "physical_block_support_fraction": support_fraction,
                "physical_block_centers": ";".join(f"{x:.2f}" for x in block_centers),
                "block_spread": block_spread,
                "consensus_center": (
                    float(consensus_center) if np.isfinite(consensus_center) else np.nan
                ),
                "consensus_evidence": float(bundle.consensus_evidence[i]),
                "consensus_spread": (
                    float(bundle.consensus_spread[i])
                    if np.isfinite(bundle.consensus_spread[i])
                    else np.nan
                ),
                "consensus_family_count": int(bundle.consensus_family_count[i]),
                "consensus_source_count": int(bundle.consensus_source_count[i]),
                "tracker_consensus_disagreement": float(disagreement),
                "local_track_excursion": float(local_excursion[i]),
                "edge_window_fraction": float(edge_fraction[i]),
                "anchor": float(bundle.anchor),
                "anchor_alternatives": ";".join(f"{x:.2f}" for x in bundle.anchor_alternatives),
                "anchor_alternative_strengths": ";".join(
                    f"{x:.3f}" for x in bundle.anchor_alternative_strengths
                ),
                "strong_alternatives": ";".join(
                    f"{value:.2f}:{ratio:.3f}" for value, ratio in alternatives
                ),
                "duration_eligible": bool(duration_eligible),
                "output_valid": bool(output_valid),
                "rejection_reason": rejection,
                **motion,
            }
        )
    return pd.DataFrame(rows)


def estimate_from_bundle(
    bundle: EvidenceBundle,
    cfg: ReferenceConfig,
    duration_s: float,
    enforce_formal_duration: bool = False,
    consensus_weight: float | None = None,
    use_consensus_interval: bool = True,
):
    score = combined_score(bundle, cfg, consensus_weight)
    if bundle.vital == "hr":
        track, tracked_score = viterbi_track(
            score,
            bundle.grid,
            bundle.anchor,
            cfg.hr_transition_scale_bpm,
            cfg.hr_transition_penalty,
            cfg.hr_anchor_prior_scale_bpm,
            cfg.hr_anchor_prior_penalty,
        )
    else:
        track, tracked_score = viterbi_track(
            score,
            bundle.grid,
            bundle.anchor,
            cfg.rr_transition_scale_brpm,
            cfg.rr_transition_penalty,
            cfg.rr_anchor_prior_scale_brpm,
            cfg.rr_anchor_prior_penalty,
        )
    rows = _interval_rows(
        bundle,
        track,
        tracked_score,
        cfg,
        duration_s,
        enforce_formal_duration,
        use_consensus_interval,
    )
    return rows, tracked_score


def estimate_recording(
    streams: Mapping[str, tuple[np.ndarray, np.ndarray]],
    cfg: ReferenceConfig | None = None,
    enforce_formal_duration: bool = False,
):
    cfg = cfg or ReferenceConfig()
    n = min(len(acc) for acc, _ in streams.values())
    duration_s = n / cfg.fs_hz
    result = {}
    diagnostics = {}
    for vital in ("hr", "rr"):
        bundle = build_evidence(streams, vital, cfg)
        rows, score = estimate_from_bundle(bundle, cfg, duration_s, enforce_formal_duration)
        if vital == "hr" and cfg.enable_hr_location_adjudication:
            source_frames = None
            # Offline canine reference construction can afford a complete
            # independent HR reconstruction per physical location. This is much
            # more defensible than deriving a remote mode from one mixed score
            # surface. Short records that cannot publish formal HR skip the extra
            # work. Human recordings have only one source and also skip it.
            if len(streams) >= 2 and (
                not enforce_formal_duration or duration_s >= cfg.hr_formal_min_duration_s
            ):
                source_frames = {}
                for source, source_stream in streams.items():
                    source_bundle = build_evidence({source: source_stream}, "hr", cfg)
                    source_rows, _ = estimate_from_bundle(
                        source_bundle, cfg, duration_s, enforce_formal_duration
                    )
                    source_frames[source] = source_rows
            rows = apply_hr_location_adjudication(
                rows, bundle, streams, cfg, source_frames=source_frames
            )
        elif vital == "rr" and cfg.enable_rr_signed_adjudication:
            rows = apply_rr_signed_adjudication(rows, streams, cfg)
        result[vital] = rows
        diagnostics[vital] = {"bundle": bundle, "score": score}
    result["diagnostics"] = diagnostics
    return result
