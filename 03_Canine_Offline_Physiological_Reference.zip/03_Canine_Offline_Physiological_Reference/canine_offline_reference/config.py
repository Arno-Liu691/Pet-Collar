from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple


@dataclass(frozen=True)
class ReferenceConfig:
    """Frozen configuration shared by human and canine inference.

    Search limits prevent numerical excursions; they are not population priors.
    The estimator remains centered and non-causal because it is intended to
    create an offline reference interval, not an MCU implementation.
    """

    fs_hz: float = 100.0
    hr_range_bpm: Tuple[float, float] = (40.0, 160.0)
    rr_range_brpm: Tuple[float, float] = (6.0, 45.0)
    hr_step_bpm: float = 0.5
    rr_step_brpm: float = 0.25
    hr_window_s: float = 16.0
    rr_window_s: float = 30.0
    hr_min_window_s: float = 12.0
    rr_min_window_s: float = 22.0
    hr_formal_min_duration_s: float = 20.0
    rr_formal_min_duration_s: float = 40.0
    hr_filterbanks_hz: Tuple[Tuple[float, float], ...] = (
        (3.0, 15.0),
        (8.0, 20.0),
        (15.0, 30.0),
    )
    # Published-family consensus is corroboration; the continuous carrier/
    # f+2f ridge remains the dominant time-series evidence.
    hr_consensus_weight: float = 0.60
    rr_consensus_weight: float = 0.20
    hr_consensus_sigma_bpm: float = 4.0
    rr_consensus_sigma_brpm: float = 1.35
    hr_transition_scale_bpm: float = 5.0
    rr_transition_scale_brpm: float = 1.5
    hr_transition_penalty: float = 1.10
    rr_transition_penalty: float = 0.70
    hr_anchor_prior_scale_bpm: float = 15.0
    rr_anchor_prior_scale_brpm: float = 3.0
    hr_anchor_prior_penalty: float = 0.30
    rr_anchor_prior_penalty: float = 0.025
    # Base intervals are widened only by observable block dispersion,
    # competing modes, tracker/consensus disagreement, and motion.
    hr_base_halfwidth_bpm: float = 8.2
    rr_base_halfwidth_brpm: float = 1.65
    hr_max_halfwidth_bpm: float = 28.0
    rr_max_halfwidth_brpm: float = 9.0
    min_candidate_score: float = 0.08
    reject_stationarity_below: float = 0.12
    reject_evidence_below: float = 0.20

    # Offline post-track adjudication. These gates do not enlarge either search
    # range. HR location adjudication is active only when >=2 synchronized
    # physical locations are present; human single-location recordings bypass it.
    enable_hr_location_adjudication: bool = True
    hr_location_split_min_bpm: float = 12.0
    hr_location_persistent_min_bpm: float = 10.0
    hr_location_min_source_confidence: float = 0.20
    hr_location_min_stationarity: float = 0.20
    hr_location_min_disjoint_halfwidth_bpm: float = 4.5

    # RR signed f-vs-2f adjudication uses raw signed XYZ cycle morphology only.
    # It is deliberately strict and abstains when votes are split.
    enable_rr_signed_adjudication: bool = True
    rr_signed_min_vote_confidence: float = 0.45
    rr_signed_min_winner_share: float = 0.60
    rr_signed_fold_advantage: float = 0.10
    # Explicit corroboration for low=fundamental / high=2f harmonic.
    rr_signed_abab_delta_min: float = 0.20
    rr_signed_abab_weight: float = 0.45
    rr_signed_phase_coupling_min: float = 0.60
    rr_signed_phase_weight: float = 0.20
    rr_signed_min_fold_repeatability: float = 0.20
    rr_signed_local_min_repeatability: float = 0.15
    # Preserve temporal sensitivity even after a confident branch decision.
    rr_signed_max_morphology_weight: float = 0.75
    # Segment-level safety: a full RR window persistently pinned to the
    # numerical lower search boundary is treated as estimator failure when
    # signed morphology cannot resolve the branch.
    rr_persistent_boundary_lock_s: float = 30.0
    # Triggered boundary rescue.  These parameters are used only after a
    # persistent lower-boundary lock has already been detected and the normal
    # signed f-vs-2f adjudicator has abstained.  Rescue is driven by independent
    # Back signed Acc+Gyro mechanical-cycle agreement, centred weakly on the
    # whole-record RR anchor; it never changes the global 6--45 brpm search domain.
    rr_boundary_rescue_anchor_margin_brpm: float = 6.0
    rr_boundary_rescue_anchor_search_halfwidth_brpm: float = 9.0
    rr_boundary_rescue_exclude_boundary_brpm: float = 2.0
    rr_boundary_rescue_min_axis_repeatability: float = 0.35
    rr_boundary_rescue_min_cluster_repeatability: float = 0.45
    rr_boundary_rescue_cluster_halfwidth_brpm: float = 2.5
    rr_boundary_rescue_min_axes: int = 4
    rr_boundary_rescue_max_axis_spread_brpm: float = 3.5
    rr_boundary_rescue_min_supported_window_fraction: float = 0.75
    random_state: int = 1729

    @property
    def hr_grid(self):
        import numpy as np

        return np.arange(self.hr_range_bpm[0], self.hr_range_bpm[1] + 1e-9, self.hr_step_bpm)

    @property
    def rr_grid(self):
        import numpy as np

        return np.arange(self.rr_range_brpm[0], self.rr_range_brpm[1] + 1e-9, self.rr_step_brpm)
