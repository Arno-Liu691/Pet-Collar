from __future__ import annotations

import numpy as np
import pandas as pd


def annotate_reference(
    df: pd.DataFrame, reference: np.ndarray, recording: str, vital: str, condition
):
    out = df.copy()
    out.insert(0, "recording", recording)
    out.insert(1, "vital", vital)
    out["reference"] = reference
    out["absolute_error"] = np.abs(out["estimate"] - out["reference"])
    in_primary = (out["reference"] >= out["primary_low"]) & (
        out["reference"] <= out["primary_high"]
    )
    in_secondary = (
        np.isfinite(out["secondary_low"])
        & (out["reference"] >= out["secondary_low"])
        & (out["reference"] <= out["secondary_high"])
    )
    out["covered_primary"] = out["output_valid"] & in_primary
    out["covered_union"] = out["output_valid"] & (in_primary | in_secondary)
    out["primary_width"] = out["primary_high"] - out["primary_low"]
    out["union_width"] = out["primary_width"] + np.where(
        np.isfinite(out["secondary_low"]), out["secondary_high"] - out["secondary_low"], 0.0
    )
    out["outer_width"] = out["conservative_high"] - out["conservative_low"]
    out["motion_condition"] = condition
    return out


def _safe_corr(a, b):
    if len(a) < 3 or np.nanstd(a) < 1e-12 or np.nanstd(b) < 1e-12:
        return np.nan
    return float(np.corrcoef(a, b)[0, 1])


def _best_lag(est: np.ndarray, ref: np.ndarray, max_lag: int = 10):
    best_lag, best_corr = 0, -np.inf
    for lag in range(-max_lag, max_lag + 1):
        if lag < 0:
            a, b = est[-lag:], ref[:lag]
        elif lag > 0:
            a, b = est[:-lag], ref[lag:]
        else:
            a, b = est, ref
        corr = _safe_corr(a, b)
        if np.isfinite(corr) and corr > best_corr:
            best_lag, best_corr = lag, corr
    return int(best_lag), float(best_corr) if np.isfinite(best_corr) else np.nan


def trajectory_metrics(df: pd.DataFrame, version: str, only_nominal: bool = False):
    mask = np.isfinite(df["reference"]) & df["output_valid"]
    if only_nominal:
        mask &= df["motion_condition"] == "nominal"
    valid = df.loc[mask].sort_values("time_s")
    reference_count = int(
        (
            np.isfinite(df["reference"])
            & ((df["motion_condition"] == "nominal") if only_nominal else True)
        ).sum()
    )
    if len(valid) == 0:
        return {
            "version": version,
            "recording": df["recording"].iloc[0],
            "vital": df["vital"].iloc[0],
            "reference_windows": reference_count,
            "valid_outputs": 0,
        }
    est = valid["estimate"].to_numpy(float)
    ref = valid["reference"].to_numpy(float)
    error = est - ref
    change_horizon = 5
    if len(est) > change_horizon:
        est_change = est[change_horizon:] - est[:-change_horizon]
        ref_change = ref[change_horizon:] - ref[:-change_horizon]
        change_mae = float(np.mean(np.abs(est_change - ref_change)))
        change_corr = _safe_corr(est_change, ref_change)
    else:
        change_mae = change_corr = np.nan
    best_lag, best_lag_corr = _best_lag(est, ref)
    total_variation_ref = float(np.sum(np.abs(np.diff(ref))))
    total_variation_ratio = float(np.sum(np.abs(np.diff(est))) / (total_variation_ref + 1e-12))
    alpha = 0.10
    primary_low = valid["primary_low"].to_numpy(float)
    primary_high = valid["primary_high"].to_numpy(float)
    secondary_low = valid["secondary_low"].to_numpy(float)
    secondary_high = valid["secondary_high"].to_numpy(float)
    primary_distance = np.maximum(primary_low - ref, 0) + np.maximum(ref - primary_high, 0)
    secondary_distance = np.maximum(secondary_low - ref, 0) + np.maximum(ref - secondary_high, 0)
    distance_to_union = np.where(
        np.isfinite(secondary_low),
        np.minimum(primary_distance, secondary_distance),
        primary_distance,
    )
    interval_score = valid["union_width"].to_numpy(float) + 2.0 / alpha * distance_to_union
    return {
        "version": version,
        "recording": valid["recording"].iloc[0],
        "vital": valid["vital"].iloc[0],
        "scope": "nominal_only" if only_nominal else "all",
        "reference_windows": reference_count,
        "valid_outputs": int(len(valid)),
        "output_rate": float(len(valid) / max(1, reference_count)),
        "mae": float(np.mean(np.abs(error))),
        "median_ae": float(np.median(np.abs(error))),
        "p95_ae": float(np.percentile(np.abs(error), 95)),
        "rmse": float(np.sqrt(np.mean(error**2))),
        "bias": float(np.mean(error)),
        "zero_lag_correlation": _safe_corr(est, ref),
        "best_lag_s": best_lag,
        "best_lag_correlation": best_lag_corr,
        "five_second_change_mae": change_mae,
        "five_second_change_correlation": change_corr,
        "total_variation_ratio": total_variation_ratio,
        "coverage_primary": float(valid["covered_primary"].mean()),
        "coverage_union": float(valid["covered_union"].mean()),
        "median_primary_width": float(valid["primary_width"].median()),
        "median_union_width": float(valid["union_width"].median()),
        "median_outer_width": float(valid["outer_width"].median()),
        "mean_90pct_interval_score": float(np.mean(interval_score)),
        "two_mode_fraction": float(np.mean(valid["interval_mode_count"] == 2)),
    }
