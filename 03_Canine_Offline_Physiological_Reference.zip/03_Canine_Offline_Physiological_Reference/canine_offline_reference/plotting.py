from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy import signal

from .config import ReferenceConfig
from .core import fft_prominence


def _save(path: str | Path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    plt.tight_layout()
    plt.savefig(path, dpi=180, bbox_inches="tight")
    plt.close()


def _interval_plot(ax, df, color, label, reference=None):
    time = df["time_s"].to_numpy(float)
    valid = df["output_valid"].to_numpy(bool)
    ax.fill_between(
        time,
        df["primary_low"],
        df["primary_high"],
        where=valid,
        color=color,
        alpha=0.20,
        label=f"{label} primary interval",
    )
    secondary = valid & np.isfinite(df["secondary_low"])
    if secondary.any():
        ax.fill_between(
            time,
            df["secondary_low"],
            df["secondary_high"],
            where=secondary,
            color=color,
            alpha=0.10,
            hatch="//",
            label=f"{label} secondary interval",
        )
    ax.plot(
        time[valid],
        df.loc[valid, "estimate"],
        color=color,
        linewidth=1.4,
        label=f"{label} estimate",
    )
    rejected = ~valid
    if rejected.any():
        ax.scatter(
            time[rejected],
            df.loc[rejected, "estimate"],
            marker="x",
            s=13,
            color="#c62828",
            label="Rejected",
        )
    if reference is not None:
        ax.plot(time, reference, color="#202124", linewidth=1.5, label="Centered reference")
    ax.grid(alpha=0.22)


def plot_human_final(recording, raw, hr, rr, output_path):
    fig, axes = plt.subplots(
        4, 1, figsize=(13, 11.2), sharex=True, gridspec_kw={"height_ratios": [0.9, 0.9, 1.45, 1.45]}
    )
    time = raw["time_s"].to_numpy(float)
    acc = raw[["ax", "ay", "az"]].to_numpy(float)
    gyro = raw[["gx", "gy", "gz"]].to_numpy(float)
    acc_dynamic = np.linalg.norm(acc, axis=1) - np.median(np.linalg.norm(acc, axis=1))
    gyro_dynamic = np.linalg.norm(gyro, axis=1) - np.median(np.linalg.norm(gyro, axis=1))
    axes[0].plot(time[::5], acc_dynamic[::5], color="#68737d", linewidth=0.55)
    axes[0].set_ylabel("Dynamic |ACC| (g)")
    axes[0].set_title(recording.replace("_", " "))
    axes[0].grid(alpha=0.22)
    axes[1].plot(time[::5], gyro_dynamic[::5], color="#6d5a72", linewidth=0.55)
    axes[1].set_ylabel("Dynamic |GYRO| (dps)")
    axes[1].grid(alpha=0.22)
    _interval_plot(axes[2], hr, "#1565c0", "Offline HR", hr["reference"].to_numpy(float))
    axes[2].set_ylabel("HR (bpm)")
    axes[2].legend(ncol=3, fontsize=8, loc="upper right")
    _interval_plot(axes[3], rr, "#00897b", "Offline RR", rr["reference"].to_numpy(float))
    axes[3].set_ylabel("RR (brpm)")
    axes[3].set_xlabel("Time (s)")
    axes[3].legend(ncol=3, fontsize=8, loc="upper right")
    _save(output_path)


def full_spectra(streams, cfg: ReferenceConfig):
    result = {}
    hr_grid = np.arange(cfg.hr_range_bpm[0], cfg.hr_range_bpm[1] + 0.05, 0.1)
    rr_grid = np.arange(cfg.rr_range_brpm[0], cfg.rr_range_brpm[1] + 0.05, 0.1)
    for source, (acc, gyro) in streams.items():
        rr_score = np.zeros_like(rr_grid)
        for raw in (acc, gyro):
            f, prom = fft_prominence(raw, cfg.fs_hz, 0.08, 1.60, nfft=32768)
            rr_score += np.interp(rr_grid / 60.0, f, prom)
        hr_score = np.zeros_like(hr_grid)
        for raw in (acc, gyro):
            for band, weight in (
                (cfg.hr_filterbanks_hz[0], 1.0),
                (cfg.hr_filterbanks_hz[1], 1.0),
                (cfg.hr_filterbanks_hz[2], 0.7),
            ):
                sos = signal.butter(
                    4, [band[0], band[1]], btype="bandpass", fs=cfg.fs_hz, output="sos"
                )
                filtered = signal.sosfiltfilt(sos, raw, axis=0)
                envelope = np.sqrt(np.sum(np.abs(signal.hilbert(filtered, axis=0)) ** 2, axis=1))[
                    :, None
                ]
                f, prom = fft_prominence(envelope, cfg.fs_hz, 0.60, 2.85, nfft=32768)
                hr_score += weight * np.interp(hr_grid / 60.0, f, prom)
        rr_score = (rr_score - np.median(rr_score)) / (np.std(rr_score) + 1e-12)
        hr_score = (hr_score - np.median(hr_score)) / (np.std(hr_score) + 1e-12)
        result[source] = {
            "hr_grid": hr_grid,
            "hr_score": hr_score,
            "rr_grid": rr_grid,
            "rr_score": rr_score,
        }
    return result


def plot_canine(segment_id, streams, hr, rr, spectra, output_path):
    fig, axes = plt.subplots(6, 1, figsize=(13, 15.8))
    for source, (acc, gyro) in streams.items():
        time = np.arange(len(acc)) / 100.0
        acc_dynamic = np.linalg.norm(acc, axis=1) - np.median(np.linalg.norm(acc, axis=1))
        gyro_dynamic = np.linalg.norm(gyro, axis=1) - np.median(np.linalg.norm(gyro, axis=1))
        axes[0].plot(time[::5], acc_dynamic[::5], linewidth=0.60, label=source)
        axes[1].plot(time[::5], gyro_dynamic[::5], linewidth=0.60, label=source)
    axes[0].set_ylabel("Dynamic |ACC| (g)")
    axes[0].set_title(segment_id)
    axes[0].legend()
    axes[0].grid(alpha=0.22)
    axes[1].set_ylabel("Dynamic |GYRO| (dps)")
    axes[1].legend()
    axes[1].grid(alpha=0.22)
    _interval_plot(axes[2], hr, "#1565c0", "HR")
    axes[2].set_ylabel("HR (bpm)")
    axes[2].legend(ncol=3, fontsize=8)
    _interval_plot(axes[3], rr, "#00897b", "RR")
    axes[3].set_ylabel("RR (brpm)")
    axes[3].legend(ncol=3, fontsize=8)
    # Compact audit annotation: distinguish final primary/active secondary from
    # a harmonic branch that existed pre-adjudication but was suppressed.
    if len(rr):
        state = str(rr["rr_signed_state"].iloc[0]) if "rr_signed_state" in rr.columns else ""
        label_map = {
            "high_confirmed": "RR: high confirmed",
            "low_confirmed": "RR: low confirmed",
            "ambiguous": "RR: ambiguous",
            "boundary_rescued": "RR: boundary rescued",
            "unresolved_persistent_boundary": "RR: unresolved",
            "not_eligible": "RR: not eligible",
        }
        audit = label_map.get(state, f"RR: {state.replace('_', ' ')}" if state else "")
        if "rr_suppressed_branch" in rr.columns:
            sb = rr["rr_suppressed_branch"].iloc[0]
            st = (
                str(rr["rr_suppressed_branch_type"].iloc[0])
                if "rr_suppressed_branch_type" in rr.columns
                else ""
            )
            if np.isfinite(sb):
                audit += f" | suppressed {st} ~{float(sb):.1f}"
        if audit:
            axes[3].text(
                0.01,
                0.97,
                audit,
                transform=axes[3].transAxes,
                va="top",
                ha="left",
                fontsize=8.5,
                bbox=dict(
                    boxstyle="round,pad=0.25", facecolor="white", alpha=0.78, edgecolor="0.75"
                ),
            )
    for source, values in spectra.items():
        axes[4].plot(values["hr_grid"], values["hr_score"], label=source)
        axes[5].plot(values["rr_grid"], values["rr_score"], label=source)
    axes[4].set_ylabel("HR spectral evidence (z)")
    axes[4].set_xlabel("HR candidate (bpm)")
    axes[4].legend()
    axes[4].grid(alpha=0.22)
    axes[5].set_ylabel("RR spectral evidence (z)")
    axes[5].set_xlabel("RR candidate (brpm)")
    axes[5].legend()
    axes[5].grid(alpha=0.22)
    _save(output_path)
