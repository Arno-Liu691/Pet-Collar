"""Canine offline physiological HR/RR reference estimator."""

from .config import ReferenceConfig
from .pipeline import estimate_recording

__all__ = ["ReferenceConfig", "estimate_recording"]
