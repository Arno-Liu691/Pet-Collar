# 03_Canine_Offline_Physiological_Reference

Offline HR/RR physiological-reference estimator for selected low-motion canine IMU recordings from the Movement Sensor Dataset for Dog Behavior Classification.

## Scope
The repository constructs evidence-supported HR/RR reference trajectories and intervals from synchronized Neck and Back six-axis IMU data. The canine outputs are research-use pseudo/external references, not synchronized canine physiological ground truth and not calibrated statistical confidence intervals. Human recordings with external HR/RR references are included to validate the core signal-processing and trajectory-tracking framework.

## Method summary
- HR: direct mechanical PSD/ACF plus multi-band mechanical-carrier envelope PSD/ACF/event evidence.
- RR: signed-axis/PCA PSD, ACF and cepstral evidence.
- Evidence fusion across Acc/Gyro, axes/projections and physical locations.
- Weak persistent anchor and non-causal Viterbi trajectory tracking.
- Dynamic evidence-dependent primary intervals and disjoint secondary modes.
- Canine RR signed f/2f adjudication using cycle repeatability, A-B-A-B morphology and low-weight phase coupling.
- Strict persistent-boundary rescue using independent Back Acc+Gyro cycle agreement.
- Explicit rejection/abstention when evidence is insufficient.

## Repository layout
- `canine_offline_reference/`: estimator implementation.
- `inputs/canine_selected_segments/`: exact selected canine Neck/Back NPZ inputs and segment metadata.
- `inputs/human_ground_truth/`: four human six-axis recordings and physiological reference files used for validation.
- `scripts/`: reproducible canine/human execution and result summarization.
- `results/config_frozen.json`: frozen estimator parameters.
- `results/tables/`: final numeric outputs.
- `results/figures/`: final figures.
- The README and frozen configuration provide the method and parameter context
  required to reproduce the packaged outputs.
- `tests/`: frozen semantic tests.

## Rebuild
From the repository root:

```bash
python scripts/rebuild_results.py --destination rebuilt_results --jobs 4
```

The rebuild uses only the packaged algorithm inputs. Human validation compares each output with a centered reference aggregated over the same temporal support as the estimator: 16 s for HR and 30 s for RR.

## Data and method references
The primary source dataset is the Movement Sensor Dataset for Dog Behavior Classification (Vehkaoja et al.; Mendeley Data DOI 10.17632/vxhx934tbn.1). Methodological context is summarised above and in the frozen configuration and result tables.

## Research boundary
Published canine physiology is used only for plausibility discussion, not as a hard branch label. Back sensing is privileged offline evidence and is not assumed to be available to a later collar-only embedded estimator.
