# 04_LRMAP_FullC_Runtime_Core — Dataset

本包将所有片段统一为 CSV 输入格式。

## 每段统一输入
每个 segment 均包含 `input/raw_imu.csv`，字段统一为：
- sample_index
- time_s
- acc_x_g, acc_y_g, acc_z_g
- gyro_x_dps, gyro_y_dps, gyro_z_dps

犬类记录额外保留 `source_time_from_test_s` 作为溯源列。

## 每段统一参考
每个 segment 均包含：
- `reference/hr_reference.csv`
- `reference/rr_reference.csv`
- `reference/reference_summary.csv`

参考表统一字段：
- time_s
- estimate
- range_low
- range_high
- output_valid
- reference_kind

犬类范围来自 offline V6 primary range。
人体范围是评估容差，不代表生理区间：HR 为 ±5 bpm，RR 为 ±3 brpm。

## 元数据
每段包含 `metadata/segment_metadata.csv`。

## 顶层文件
- `SPLIT_MANIFEST.csv`
- `COLUMN_MAPPING_AUDIT.csv`
