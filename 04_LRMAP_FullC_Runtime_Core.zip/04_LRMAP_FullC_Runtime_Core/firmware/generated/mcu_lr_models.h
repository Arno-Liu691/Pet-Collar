/* Generated interface for the frozen model coefficients. */
#ifndef MCU_LR_MODELS_H
#define MCU_LR_MODELS_H
#include <stdint.h>
#define MCU_HR_CAND_FEATURES 105U
#define MCU_RR_CAND_FEATURES 86U
#define MCU_RR_GATE_BASE_FEATURES 102U
#define MCU_RR_GATE_TERMS 114U
#define MCU_RR_GATE_IS_POLY 1U
#define MCU_HR_GATE_BASE_FEATURES 71U
#define MCU_HR_GATE_TERMS 165U
extern const float g_hr_cand_w[MCU_HR_CAND_FEATURES];
extern const float g_hr_cand_bias;
extern const float g_rr_cand_w[MCU_RR_CAND_FEATURES];
extern const float g_rr_cand_bias;
extern const float g_rr_gate_term_w[MCU_RR_GATE_TERMS];
extern const int16_t g_rr_gate_term_a[MCU_RR_GATE_TERMS];
extern const int16_t g_rr_gate_term_b[MCU_RR_GATE_TERMS];
extern const float g_rr_gate_bias;
extern const float g_hr_gate_term_w[MCU_HR_GATE_TERMS];
extern const int16_t g_hr_gate_term_a[MCU_HR_GATE_TERMS];
extern const int16_t g_hr_gate_term_b[MCU_HR_GATE_TERMS];
extern const float g_hr_gate_bias;
#define MCU_HR_GATE_THRESHOLD 0.33f
#define MCU_RR_GATE_THRESHOLD 0.4475f
float McuLr_Dot(const float *x, const float *w, uint16_t n, float bias);
float McuLr_HrCandidateUtility(const float *x);
float McuLr_RrCandidateUtility(const float *x);
float McuLr_HrGateLogit(const float *base);
float McuLr_RrGateLogit(const float *base);
uint8_t McuLr_HrReportable(const float *base);
uint8_t McuLr_RrReportable(const float *base);
#endif
