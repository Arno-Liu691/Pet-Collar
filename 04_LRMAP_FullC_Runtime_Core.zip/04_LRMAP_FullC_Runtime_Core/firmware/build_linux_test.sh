#!/bin/sh
set -eu
cc -std=c11 -O2 -Wall -Wextra -Ifirmware/algorithm -Ifirmware/generated \
 firmware/algorithm/mcu_hrrr_lrmap.c firmware/generated/mcu_lr_models.c firmware/tests/test_lrmap.c -lm -o firmware/tests/test_lrmap
./firmware/tests/test_lrmap
