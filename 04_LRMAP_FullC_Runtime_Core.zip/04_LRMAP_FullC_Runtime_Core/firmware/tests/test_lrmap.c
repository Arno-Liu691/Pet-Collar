#include <stdio.h>
#include "mcu_hrrr_lrmap.h"
#include "mcu_lr_models.h"
int main(void) {
    McuLrMapState s;
    McuLrMap_Reset(&s);
    McuBranchCandidate x[3] = {{17, 0.1f, 0}, {34, 1.2f, 1}, {35, 0.5f, 2}}, d[3];
    uint8_t n = McuLrMap_Dedup(x, 3, d, &g_mcu_rr_lrmap_config);
    McuLrMapDecision o = McuLrMap_Update(&s, d, n, &g_mcu_rr_lrmap_config);
    printf("n=%u selected=%.2f tracked=%.2f\n", n, o.selected_bpm, o.tracked_bpm);
    return (n >= 2 && o.selected_bpm > 30) ? 0 : 1;
}
