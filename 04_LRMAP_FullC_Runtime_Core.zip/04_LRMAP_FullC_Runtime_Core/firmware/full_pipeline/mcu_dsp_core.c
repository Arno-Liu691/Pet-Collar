#include "mcu_dsp_core.h"
#include <math.h>
#include <string.h>
static inline void fswap(float *a, float *b) {
    float t = *a;
    *a = *b;
    *b = t;
}
/* Deterministic in-place nth-element (3-way partition).  Median/quantile only
   need order statistics, not a fully sorted window.  This preserves the exact
   mathematical order statistic while avoiding O(n log n) full sorts. */
static float fselect_k(float *a, int n, int k) {
    int lo = 0, hi = n - 1;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        float x = a[lo], y = a[mid], z = a[hi], p;
        if (x < y) {
            if (y < z)
                p = y;
            else
                p = (x < z ? z : x);
        } else {
            if (x < z)
                p = x;
            else
                p = (y < z ? z : y);
        }
        int lt = lo, i = lo, gt = hi;
        while (i <= gt) {
            if (a[i] < p) {
                fswap(&a[i], &a[lt]);
                i++;
                lt++;
            } else if (a[i] > p) {
                fswap(&a[i], &a[gt]);
                gt--;
            } else
                i++;
        }
        if (k < lt)
            hi = lt - 1;
        else if (k > gt)
            lo = gt + 1;
        else
            return a[k];
    }
    return a[lo];
}
float McuBiquad_Step(const McuBiquadCoef *c, McuBiquadState *s, float x) {
    float y = c->b0 * x + s->z1;
    s->z1 = c->b1 * x - c->a1 * y + s->z2;
    s->z2 = c->b2 * x - c->a2 * y;
    return y;
}
float McuSos_Step(const McuSos *f, McuBiquadState *s, float x) {
    float y = x;
    for (uint8_t i = 0; i < f->nsec; i++)
        y = McuBiquad_Step(&f->sec[i], &s[i], y);
    return y;
}
void McuSos_Process(const McuSos *f, McuBiquadState *s, const float *x, float *y, int n) {
    for (int i = 0; i < n; i++)
        y[i] = McuSos_Step(f, s, x[i]);
}
float McuMean(const float *x, int n) {
    double s = 0;
    for (int i = 0; i < n; i++)
        s += x[i];
    return n ? (float)(s / n) : 0;
}
float McuStd(const float *x, int n) {
    if (n < 2)
        return 0;
    float m = McuMean(x, n);
    double s = 0;
    for (int i = 0; i < n; i++) {
        double d = x[i] - m;
        s += d * d;
    }
    return (float)sqrt(s / n);
}
float McuMedian(float *x, int n) {
    if (n <= 0)
        return 0;
    if (n & 1)
        return fselect_k(x, n, n / 2);
    float b = fselect_k(x, n, n / 2);
    float a = fselect_k(x, n, n / 2 - 1);
    return 0.5f * (a + b);
}
float McuQuantile(float *x, int n, float q) {
    if (n <= 0)
        return 0;
    float p = q * (n - 1);
    int i = (int)floorf(p);
    float f = p - i;
    float a = fselect_k(x, n, i);
    if (i >= n - 1)
        return a;
    float b = fselect_k(x, n, i + 1);
    return a * (1 - f) + b * f;
}
void McuNormSig(const float *x, float *y,
                int n) { /* x and y must be distinct. Reuse y as order-statistic scratch,
                            eliminating a 1600-float global buffer. */
    if (n > MCU_MAX_WIN_RAW)
        n = MCU_MAX_WIN_RAW;
    if (n <= 0)
        return;
    memcpy(y, x, n * sizeof(float));
    float med = McuMedian(y, n);
    for (int i = 0; i < n; i++)
        y[i] = fabsf(x[i] - med);
    float sc = McuMedian(y, n) * 1.4826f;
    if (sc < 1e-9f)
        sc = McuStd(x, n) + 1e-9f;
    for (int i = 0; i < n; i++)
        y[i] = (x[i] - med) / (sc + 1e-9f);
}
float McuCorr(const float *a, const float *b, int n) {
    float ma = McuMean(a, n), mb = McuMean(b, n);
    double sa = 0, sb = 0, sab = 0;
    for (int i = 0; i < n; i++) {
        double x = a[i] - ma, y = b[i] - mb;
        sab += x * y;
        sa += x * x;
        sb += y * y;
    }
    return (float)(sab / (sqrt(sa * sb) + 1e-12));
}
void McuSavgol7(const float *x, float *y, int n) {
    static const float c[7] = {-2.f / 21, 3.f / 21, 6.f / 21, 7.f / 21,
                               6.f / 21,  3.f / 21, -2.f / 21};
    /* scipy.signal.savgol_filter(window=7,polyorder=2,mode='interp') edge rows. */
    static const float e0[7] = {16.f / 21, 7.5f / 21,  1.5f / 21, -2.f / 21,
                                -3.f / 21, -1.5f / 21, 2.5f / 21};
    static const float e1[7] = {7.5f / 21, 6.f / 21, 4.5f / 21, 3.f / 21,
                                1.5f / 21, 0.f,      -1.5f / 21};
    static const float e2[7] = {1.5f / 21, 4.5f / 21, 6.f / 21, 6.f / 21,
                                4.5f / 21, 1.5f / 21, -3.f / 21};
    if (n <= 0)
        return;
    if (n < 7) {
        for (int i = 0; i < n; i++)
            y[i] = x[i];
        return;
    }
    for (int i = 3; i < n - 3; i++) {
        float s = 0;
        for (int k = -3; k <= 3; k++)
            s += c[k + 3] * x[i + k];
        y[i] = s;
    }
    float a0 = 0, a1 = 0, a2 = 0, b0 = 0, b1 = 0, b2 = 0;
    for (int k = 0; k < 7; k++) {
        a0 += e0[k] * x[k];
        a1 += e1[k] * x[k];
        a2 += e2[k] * x[k];
        b0 += e0[6 - k] * x[n - 7 + k];
        b1 += e1[6 - k] * x[n - 7 + k];
        b2 += e2[6 - k] * x[n - 7 + k];
    }
    y[0] = a0;
    y[1] = a1;
    y[2] = a2;
    y[n - 3] = b2;
    y[n - 2] = b1;
    y[n - 1] = b0;
}
static float g_goertzel_2048[301], g_goertzel_4096[301];
static uint8_t g_goertzel_init = 0;
static void goertzel_init(void) {
    if (g_goertzel_init)
        return;
    for (int k = 0; k <= 300; k++) {
        g_goertzel_2048[k] = 2.f * cosf(2.f * 3.14159265358979323846f * k / 2048.f);
        g_goertzel_4096[k] = 2.f * cosf(2.f * 3.14159265358979323846f * k / 4096.f);
    }
    g_goertzel_init = 1;
}
float McuGoertzelPower(const float *x, int n, int nfft, int k) {
    goertzel_init();
    float coef =
        (nfft == 2048 && k <= 300)
            ? g_goertzel_2048[k]
            : ((nfft == 4096 && k <= 300) ? g_goertzel_4096[k]
                                          : 2.f * cosf(2.f * 3.14159265358979323846f * k / nfft));
    float s0 = 0, s1 = 0, s2 = 0;
    for (int i = 0; i < n; i++) {
        s0 = x[i] + coef * s1 - s2;
        s2 = s1;
        s1 = s0;
    }
    return s1 * s1 + s2 * s2 - coef * s1 * s2;
}
float McuPca1_3(const float *x0, const float *x1, const float *x2, float *out, int n) {
    float m0 = McuMean(x0, n), m1 = McuMean(x1, n), m2 = McuMean(x2, n);
    double C[3][3] = {{0}};
    for (int i = 0; i < n; i++) {
        double v[3] = {x0[i] - m0, x1[i] - m1, x2[i] - m2};
        for (int a = 0; a < 3; a++)
            for (int b = 0; b < 3; b++)
                C[a][b] += v[a] * v[b] / (n ? n : 1);
    }
    double v[3] = {0.577350269, 0.577350269, 0.577350269};
    for (int it = 0; it < 5; it++) {
        double z[3] = {0};
        for (int a = 0; a < 3; a++)
            for (int b = 0; b < 3; b++)
                z[a] += C[a][b] * v[b];
        double norm = sqrt(z[0] * z[0] + z[1] * z[1] + z[2] * z[2]) + 1e-12;
        for (int a = 0; a < 3; a++)
            v[a] = z[a] / norm;
    }
    for (int i = 0; i < n; i++)
        out[i] = (float)((x0[i] - m0) * v[0] + (x1[i] - m1) * v[1] + (x2[i] - m2) * v[2]);
    return 1;
}
