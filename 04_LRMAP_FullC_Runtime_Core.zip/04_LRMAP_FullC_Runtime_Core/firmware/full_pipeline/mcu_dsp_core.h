#ifndef MCU_DSP_CORE_H
#define MCU_DSP_CORE_H
#include <stdint.h>
#define MCU_FS_RAW 100
#define MCU_FS_DEC 25
#define MCU_MAX_WIN_DEC 1000
#define MCU_MAX_WIN_RAW 1600
#define MCU_MAX_RAW_CAND 320
#define MCU_MAX_CLUSTER 32

typedef struct {
    float z1, z2;
} McuBiquadState;
typedef struct {
    float b0, b1, b2, a1, a2;
} McuBiquadCoef;
typedef struct {
    const McuBiquadCoef *sec;
    uint8_t nsec;
} McuSos;
float McuBiquad_Step(const McuBiquadCoef *c, McuBiquadState *s, float x);
float McuSos_Step(const McuSos *f, McuBiquadState *s, float x);
void McuSos_Process(const McuSos *f, McuBiquadState *s, const float *x, float *y, int n);
float McuMedian(float *x, int n);
float McuQuantile(float *x, int n, float q);
float McuMean(const float *x, int n);
float McuStd(const float *x, int n);
void McuNormSig(const float *x, float *y, int n);
float McuCorr(const float *a, const float *b, int n);
void McuSavgol7(const float *x, float *y, int n);
float McuGoertzelPower(const float *x, int n, int nfft, int k);
float McuPca1_3(const float *x0, const float *x1, const float *x2, float *out, int n);
#endif
