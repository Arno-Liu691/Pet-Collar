#ifndef MCU_FILTERS_H
#define MCU_FILTERS_H
#include "mcu_dsp_core.h"
extern const McuSos F_BP_RR, F_BP_HRDIR, F_BP_CARRIER[3], F_LP4, F_BP_ENV, F_BP_MOD, F_LP_G, F_HP_G,
    F_LP1, F_LP5;
#endif
