#ifndef MCU_HRRR_FULL_H
#define MCU_HRRR_FULL_H
#include <stdint.h>
#include "mcu_hrrr_frontend.h"
#include "../algorithm/mcu_rest_detector.h"
#include "../algorithm/mcu_hrrr_lrmap.h"
typedef struct {
    uint8_t valid, formal, reportable, rest_ready, motion_ok, severe, moderate, switched,
        tracker_state;
    float t, bpm_selected, bpm_tracked, gate_p, path_margin, path_velocity;
    uint8_t n_candidates;
} McuHrrrVitalOutput;
typedef struct {
    McuHrrrFrontend front;
    McuLrMapState hr_map, rr_map;
    McuRestState rest;
    McuRestDecision rest_dec;
    uint32_t rest_entry_sample;
    uint8_t have_entry;
    float prev_hr_sel, prev_rr_sel;
} McuHrrrFullState;
void McuHrrrFull_Init(McuHrrrFullState *s);
void McuHrrrFull_PushSample(McuHrrrFullState *s, const float sample6[6]);
uint8_t McuHrrrFull_HasOutputTick(const McuHrrrFullState *s);
void McuHrrrFull_ComputeTick(McuHrrrFullState *s, McuHrrrVitalOutput *hr, McuHrrrVitalOutput *rr,
                             McuHrFeatCandidate *hr_cands, uint8_t *nhr,
                             McuRrFeatCandidate *rr_cands, uint8_t *nrr,
                             float hr_gate[MCU_HR_GATE_BASE_N], float rr_gate[MCU_RR_GATE_N]);
#endif
