#include "mcu_hrrr_frontend.h"
#include "mcu_filters.h"
#include <math.h>
#include <string.h>
#include <float.h>
#include <stdlib.h>

#define MAX_RAW 320
#define MAX_CL 40
#define MAX_DEC 1000
#define PI 3.14159265358979323846f

typedef struct {
    float bpm, w, qual;
    uint8_t method, source, mod, band;
    float reg, ncc;
    uint16_t event_n;
} RawCand;
typedef struct {
    RawCand item[MAX_RAW];
    uint16_t n;
} RawList;
typedef struct {
    uint16_t n;
    float center, lo, hi;
} Cluster;
static int16_t g_cluster_member[MAX_RAW];
typedef struct {
    float bpm, span, spread, n_axes, n_mods, acc_axes, gyro_axes, env_axes, direct_axes,
        cross_family_axes, band_support, psd_axes, acf_axes, energy_acc, energy_gyro, energy_reg,
        energy_ncc, energy_count, energy_event_n, qual_acc, qual_gyro, qual_sum, fold_acc,
        fold_gyro, boundary, qual_minmod, fold_min;
} HrBase;
typedef struct {
    float bpm;
    float v[40]; /* exact RR_BASE order */
} RrBase;

enum {
    M_PSD = 1,
    M_ACF = 2,
    M_EVENT_PEAK = 3,
    M_EVENT_VALLEY = 4,
    M_EVENT_ZC = 5,
    M_PCA_PSD = 6,
    M_PCA_ACF = 7,
    M_PCA_EVENT = 8,
    M_GRAV_PSD = 9,
    M_GRAV_ACF = 10,
    M_GRAV_EVENT = 11,
    M_MOD_PSD = 12,
    M_ENV_PSD = 13,
    M_ENV_ACF = 14,
    M_DIRECT_PSD = 15,
    M_DIRECT_ACF = 16,
    M_ENERGY_MED = 17,
    M_ENERGY_SPAN = 18,
    M_ENERGY_COUNT = 19,
    M_HYP_HALF = 20,
    M_HYP_DOUBLE = 21,
    M_HYP_THIRD = 22,
    M_HYP_TRIPLE = 23
};
static int is_energy_method(uint8_t m) {
    return m >= M_ENERGY_MED && m <= M_ENERGY_COUNT;
}

/* Shared single-thread MCU scratch; reused by HR/RR paths. */
static union {
    float energy[3][MCU_MAX_WIN_RAW];
    float rr[5][MAX_DEC];
} g_outer;
static float g_inner[3][MAX_DEC];
static RawList g_raw_list;
static union {
    RrBase rr[MAX_CL];
    HrBase hr[MAX_CL];
} g_base_all;
/* Single-threaded candidate scratch: int16 indices are sufficient for <=1600-sample windows. */
static int16_t g_peak_cand[800], g_peak_kept[800], g_energy_idx[400], g_energy_valid[400];
static uint16_t g_cluster_ord[MAX_RAW];

static float fabs1(float x) {
    return x < 0 ? -x : x;
}
static float fmin1(float a, float b) {
    return a < b ? a : b;
}
static float fmax1(float a, float b) {
    return a > b ? a : b;
}
static float clip(float x, float a, float b) {
    return x < a ? a : (x > b ? b : x);
}
static float raw_qscale(int a) {
    return a < 3 ? MCU_Q_RAW_ACC : MCU_Q_RAW_GYRO;
}
static float proc_qscale(int a) {
    return (a % 6) < 3 ? MCU_Q_PROC_ACC : MCU_Q_PROC_GYRO;
}
static int16_t q16(float x, float s) {
    long q = lroundf(x * s);
    if (q > 32767)
        q = 32767;
    if (q < -32767)
        q = -32767;
    return (int16_t)q;
}
static float dq16(int16_t q, float s) {
    return ((float)q) / s;
}
float McuHrrrFrontend_RawAt(const McuHrrrFrontend *s, int axis, int ring_index) {
    return dq16(s->raw[axis][ring_index], raw_qscale(axis));
}
static void clear_states(McuBiquadState *p, int n) {
    memset(p, 0, n * sizeof(*p));
}

void McuHrrrFrontend_Reset(McuHrrrFrontend *s) {
    memset(s, 0, sizeof(*s));
}

void McuHrrrFrontend_Push(McuHrrrFrontend *s, const float x[6]) {
    /* raw ring */
    for (int a = 0; a < 6; a++)
        s->raw[a][s->raw_head] = q16(x[a], raw_qscale(a));
    s->raw_head = (s->raw_head + 1) % MCU_RAW_RING_N;
    if (s->raw_count < MCU_RAW_RING_N)
        s->raw_count++;
    float rrv[6], hrv[6], envv[18], modv[12], glp[3], gu[3], gout[3];
    for (int a = 0; a < 6; a++) {
        rrv[a] = McuSos_Step(&F_BP_RR, s->rr_s[a], x[a]);
        hrv[a] = McuSos_Step(&F_BP_HRDIR, s->hr_s[a], x[a]);
        for (int b = 0; b < 3; b++) {
            float car = McuSos_Step(&F_BP_CARRIER[b], s->car_s[b][a], x[a]);
            float amp = McuSos_Step(&F_LP4, s->amp_s[b][a], fabsf(car));
            envv[b * 6 + a] = McuSos_Step(&F_BP_ENV, s->env_s[b][a], amp);
            if (b < 2)
                modv[b * 6 + a] = McuSos_Step(&F_BP_MOD, s->mod_s[b][a], amp);
        }
    }
    for (int a = 0; a < 3; a++)
        glp[a] = McuSos_Step(&F_LP_G, s->grav_lp[a], x[a]);
    float gn = sqrtf(glp[0] * glp[0] + glp[1] * glp[1] + glp[2] * glp[2]) + 1e-6f;
    for (int a = 0; a < 3; a++) {
        gu[a] = glp[a] / gn;
        float hp = McuSos_Step(&F_HP_G, s->grav_hp[a], gu[a]);
        gout[a] = McuSos_Step(&F_LP1, s->grav_out[a], hp);
    }
    s->sample_count++;
    /* Python make_record_v2 uses [::4]: keep raw sample indices 0,4,8,... . sample_count is 1-based
     * after increment. */
    if ((s->sample_count & 3U) == 1U) {
        for (int a = 0; a < 6; a++) {
            s->rr[a][s->long_head] = q16(rrv[a], proc_qscale(a));
            s->hrdir[a][s->hr_head] = q16(hrv[a], proc_qscale(a));
        }
        for (int a = 0; a < 3; a++)
            s->grav[a][s->long_head] = q16(gout[a], MCU_Q_GRAV);
        for (int a = 0; a < 12; a++)
            s->mod[a][s->long_head] = q16(modv[a], proc_qscale(a));
        for (int a = 0; a < 18; a++)
            s->env[a][s->hr_head] = q16(envv[a], proc_qscale(a));
        s->long_head = (s->long_head + 1) % MCU_DEC_LONG_N;
        if (s->long_count < MCU_DEC_LONG_N)
            s->long_count++;
        s->hr_head = (s->hr_head + 1) % MCU_DEC_HR_N;
        if (s->hr_count < MCU_DEC_HR_N)
            s->hr_count++;
    }
    if ((s->sample_count % 200U) == 0) {
        s->snap_head = (s->snap_head + 1) % 9;
        memcpy(s->car_snap[s->snap_head], s->car_s, sizeof(s->car_s));
        if (s->snap_count < 9)
            s->snap_count++;
    }
}
uint8_t McuHrrrFrontend_TickReady(const McuHrrrFrontend *s) {
    return (uint8_t)(s->sample_count >= 800 && (s->sample_count % 200) == 0);
}
float McuHrrrFrontend_TimeS(const McuHrrrFrontend *s) {
    return s->sample_count / 100.f;
}

static int ring_get_dec(const int16_t *ring, int cap, int head, int count, int n, float scale,
                        float *out) {
    if (n > count)
        return 0;
    int start = (head - n + cap) % cap;
    for (int i = 0; i < n; i++)
        out[i] = dq16(ring[(start + i) % cap], scale);
    return 1;
}
static int ring_get_raw(const McuHrrrFrontend *s, int axis, int n, float *out) {
    if (n > s->raw_count)
        return 0;
    int start = (s->raw_head - n + MCU_RAW_RING_N) % MCU_RAW_RING_N;
    float sc = raw_qscale(axis);
    for (int i = 0; i < n; i++)
        out[i] = dq16(s->raw[axis][(start + i) % MCU_RAW_RING_N], sc);
    return 1;
}

/* ---------- spectral/event primitives on a single 25Hz series ---------- */
typedef struct {
    float bpm, a, b, pow;
} Peak4;
static int psd_peaks(const float *x, int n, float fs, float blo, float bhi, int maxp, float sep,
                     Peak4 *out) {
    float *z = g_inner[0], *pw = g_inner[1], *tmp = g_inner[2];
    if (n > MAX_DEC)
        return 0;
    McuNormSig(x, z, n);
    if (n > 1) {
        float step = 2.f * PI / (n - 1), cd = cosf(step), sd = sinf(step), cc = 1.f, ss = 0.f;
        for (int i = 0; i < n; i++) {
            z[i] *= (.5f - .5f * cc);
            float nc = cc * cd - ss * sd;
            ss = ss * cd + cc * sd;
            cc = nc;
        }
    }
    int nfft = 2048;
    while (nfft < n * 4)
        nfft *= 2;
    float df = fs / nfft;
    int k0 = (int)ceilf((blo / 60) / df), k1 = (int)floorf((bhi / 60) / df);
    int m = k1 - k0 + 1;
    if (m <= 2 || m > 300)
        return 0;
    for (int j = 0; j < m; j++)
        pw[j] = McuGoertzelPower(z, n, nfft, k0 + j);
    memcpy(tmp, pw, m * sizeof(float));
    float noise = McuMedian(tmp, m) + 1e-12f;
    int cand[300], nc = 0;
    for (int j = 1; j < m - 1; j++)
        if (pw[j] > pw[j - 1] && pw[j] >= pw[j + 1])
            cand[nc++] = j;
    if (!nc) {
        int im = 0;
        for (int j = 1; j < m; j++)
            if (pw[j] > pw[im])
                im = j;
        cand[nc++] = im;
    }
    /* sort candidate indices by power descending and enforce distance */
    for (int i = 1; i < nc; i++) {
        int v = cand[i], j = i - 1;
        while (j >= 0 && pw[cand[j]] < pw[v]) {
            cand[j + 1] = cand[j];
            j--;
        }
        cand[j + 1] = v;
    }
    int mind = (int)((sep / 60) / df);
    if (mind < 1)
        mind = 1;
    int accepted[20], na = 0;
    for (int ci = 0; ci < nc && na < maxp; ci++) {
        int j = cand[ci], ok = 1;
        for (int q = 0; q < na; q++)
            if (abs(j - accepted[q]) < mind)
                ok = 0;
        if (!ok)
            continue;
        accepted[na++] = j;
        int rad = (int)((4.f / 60) / df);
        if (rad < 2)
            rad = 2;
        int nt = 0;
        for (int q = j - rad; q <= j + rad; q++) {
            if (q < 0 || q >= m || abs(q - j) <= 1)
                continue;
            tmp[nt++] = pw[q];
        }
        float lm = nt ? McuMedian(tmp, nt) : noise;
        out[na - 1].bpm = (k0 + j) * df * 60;
        out[na - 1].a = log1pf(pw[j] / noise);
        out[na - 1].b = log1pf(pw[j] / (lm + 1e-12f));
        out[na - 1].pow = pw[j];
    }
    return na;
}
static int acf_peaks(const float *x, int n, float fs, float blo, float bhi, int maxp, Peak4 *out) {
    float *z = g_inner[0], *ac = g_inner[1];
    if (n > MAX_DEC)
        return 0;
    McuNormSig(x, z, n);
    int l0 = (int)(fs * 60 / bhi);
    if (l0 < 1)
        l0 = 1;
    int l1 = (int)(fs * 60 / blo);
    if (l1 > n - 2)
        l1 = n - 2;
    if (l1 <= l0)
        return 0;
    double ac0 = 0;
    for (int i = 0; i < n; i++)
        ac0 += (double)z[i] * z[i];
    ac0 /= n;
    if (ac0 <= 0)
        return 0;
    int m = l1 - l0 + 1;
    for (int q = 0; q < m; q++) {
        int lag = l0 + q;
        double s = 0;
        for (int i = 0; i < n - lag; i++)
            s += (double)z[i] * z[i + lag];
        ac[q] = (float)((s / (n - lag)) / ac0);
    }
    int cand[400], nc = 0;
    for (int q = 1; q < m - 1; q++)
        if (ac[q] > ac[q - 1] && ac[q] >= ac[q + 1])
            cand[nc++] = q;
    if (!nc) {
        int im = 0;
        for (int q = 1; q < m; q++)
            if (ac[q] > ac[im])
                im = q;
        cand[nc++] = im;
    }
    for (int i = 1; i < nc; i++) {
        int v = cand[i], j = i - 1;
        while (j >= 0 && ac[cand[j]] < ac[v]) {
            cand[j + 1] = cand[j];
            j--;
        }
        cand[j + 1] = v;
    }
    int dist = (int)(fs * 60 / bhi * .35f);
    if (dist < 1)
        dist = 1, nc = nc;
    int acci[10], na = 0;
    for (int c = 0; c < nc && na < maxp; c++) {
        int q = cand[c], ok = 1;
        for (int k = 0; k < na; k++)
            if (abs(q - acci[k]) < dist)
                ok = 0;
        if (!ok)
            continue;
        acci[na] = q;
        int lag = l0 + q;
        int rad = (int)(fs * .15f);
        float tmp[40];
        int nt = 0;
        for (int u = q - rad; u <= q + rad; u++)
            if (u >= 0 && u < m && nt < 40)
                tmp[nt++] = ac[u];
        float base = nt ? McuMedian(tmp, nt) : 0;
        out[na].bpm = 60 * fs / lag;
        out[na].a = ac[q];
        out[na].b = ac[q] - base;
        out[na].pow = ac[q];
        na++;
    }
    return na;
}

static int find_event_peaks(const float *y, int n, int mind, float prom, int16_t *idx, int maxidx) {
    /* Match scipy.find_peaks(y, distance=..., prominence=...): local maxima -> distance by peak
     * height -> prominence. */
    int16_t *cand = g_peak_cand;
    int nc = 0;
    for (int i = 1; i < n - 1 && nc < 800; i++) {
        if (y[i] > y[i - 1] && y[i] >= y[i + 1])
            cand[nc++] = i;
    }
    /* scipy distance pruning prioritises peak height. */
    for (int i = 1; i < nc; i++) {
        int v = cand[i], j = i - 1;
        while (j >= 0 && y[cand[j]] < y[v]) {
            cand[j + 1] = cand[j];
            j--;
        }
        cand[j + 1] = v;
    }
    int16_t *kept = g_peak_kept;
    int nk = 0;
    for (int c = 0; c < nc; c++) {
        int p = cand[c], ok = 1;
        for (int k = 0; k < nk; k++)
            if (abs(p - kept[k]) < mind) {
                ok = 0;
                break;
            }
        if (ok)
            kept[nk++] = p;
    }
    int na = 0;
    for (int k = 0; k < nk && na < maxidx; k++) {
        int p = kept[k];
        float h = y[p], lmin = h, rmin = h;
        /* Equal-height peaks do not stop scipy prominence search; only a strictly higher sample
         * does. */
        int L = p - 1;
        while (L >= 0 && y[L] <= h) {
            if (y[L] < lmin)
                lmin = y[L];
            L--;
        }
        int R = p + 1;
        while (R < n && y[R] <= h) {
            if (y[R] < rmin)
                rmin = y[R];
            R++;
        }
        float pr = h - fmax1(lmin, rmin);
        if (pr >= prom)
            idx[na++] = p;
    }
    /* Return chronological order, as numpy peak indices do. */
    for (int i = 1; i < na; i++) {
        int v = idx[i], j = i - 1;
        while (j >= 0 && idx[j] > v) {
            idx[j + 1] = idx[j];
            j--;
        }
        idx[j + 1] = v;
    }
    return na;
}
static int event_candidates(const float *x, int n, float fs, float blo, float bhi, Peak4 *out) {
    float *z = g_inner[0], *sm = g_inner[1], *neg = g_inner[2];
    float dv[100];
    McuNormSig(x, z, n);
    McuSavgol7(z, sm, n);
    int mind = (int)(fs * 60 / bhi * .65f);
    if (mind < 1)
        mind = 1;
    int no = 0;
    for (int sg = 0; sg < 2; sg++) {
        for (int i = 0; i < n; i++)
            neg[i] = sg ? -sm[i] : sm[i];
        float prom = fmax1(.25f, McuStd(neg, n) * .20f);
        int16_t idx[200];
        int ni = find_event_peaks(neg, n, mind, prom, idx, 200);
        if (ni >= 3) {
            int nd = 0;
            for (int i = 1; i < ni; i++) {
                float d = (idx[i] - idx[i - 1]) / fs;
                if (d >= 60 / bhi * .65f && d <= 60 / blo * 1.35f)
                    dv[nd++] = d;
            }
            if (nd >= 2) {
                float cpy[100];
                memcpy(cpy, dv, nd * 4);
                float med = McuMedian(cpy, nd);
                for (int i = 0; i < nd; i++)
                    cpy[i] = fabsf(dv[i] - med);
                float cv = McuMedian(cpy, nd) / (med + 1e-9f);
                float bpm = 60 / med, q = fmax1(0, 1 - cv / .30f) * fmin1(1, nd / 6.f);
                if (bpm >= blo && bpm <= bhi) {
                    out[no] =
                        (Peak4){bpm, q, (float)nd, (float)(sg ? M_EVENT_VALLEY : M_EVENT_PEAK)};
                    no++;
                }
            }
        }
    }
    int16_t idx[200];
    int ni = 0;
    for (int i = 0; i < n - 1 && ni < 200; i++)
        if (sm[i] < 0 && sm[i + 1] >= 0)
            idx[ni++] = i;
    if (ni >= 3) {
        int nd = 0;
        for (int i = 1; i < ni; i++) {
            float d = (idx[i] - idx[i - 1]) / fs;
            if (d >= 60 / bhi * .65f && d <= 60 / blo * 1.35f)
                dv[nd++] = d;
        }
        if (nd >= 2) {
            float cpy[100];
            memcpy(cpy, dv, nd * 4);
            float med = McuMedian(cpy, nd);
            for (int i = 0; i < nd; i++)
                cpy[i] = fabsf(dv[i] - med);
            float cv = McuMedian(cpy, nd) / (med + 1e-9f);
            float bpm = 60 / med, q = fmax1(0, 1 - cv / .30f) * fmin1(1, nd / 6.f);
            if (bpm >= blo && bpm <= bhi)
                out[no++] = (Peak4){bpm, q, (float)nd, (float)M_EVENT_ZC};
        }
    }
    return no;
}
static void fold_quality(const float *x, int n, float fs, float bpm, float *out_adj,
                         float *out_skip) {
    float *z = g_inner[0];
    float a[80];
    if (n > MAX_DEC) {
        *out_adj = -1;
        *out_skip = 0;
        return;
    }
    McuNormSig(x, z, n);
    int L = (int)lroundf(fs * 60 / bpm);
    if (L < 5) {
        *out_adj = -1;
        *out_skip = 0;
        return;
    }
    int nc = n / L;
    if (nc < 3) {
        *out_adj = -1;
        *out_skip = 0;
        return;
    }
    int start = n - nc * L, na = 0;
    for (int c = 0; c < nc - 1 && na < 80; c++) {
        float *p = &z[start + c * L], *q = &z[start + (c + 1) * L];
        a[na++] = McuCorr(p, q, L);
    }
    *out_adj = McuMedian(a, na);
    na = 0;
    for (int c = 0; c < nc - 2 && na < 80; c++)
        a[na++] = McuCorr(&z[start + c * L], &z[start + (c + 2) * L], L);
    *out_skip = na ? McuMedian(a, na) : 0;
}

static void raw_add(RawList *l, float bpm, float w, uint8_t meth, uint8_t src, uint8_t mod,
                    uint8_t band, float qual) {
    if (l->n >= MAX_RAW || !isfinite(bpm))
        return;
    RawCand *q = &l->item[l->n++];
    memset(q, 0, sizeof(*q));
    q->bpm = bpm;
    q->w = w;
    q->method = meth;
    q->source = src;
    q->mod = mod;
    q->band = band;
    q->qual = qual;
}
static int cluster_raw(const RawList *l, float radius, float maxspan, Cluster *out, int maxc) {
    uint16_t *ord = g_cluster_ord;
    float *vals = g_inner[1], *ws = g_inner[2];
    for (int i = 0; i < l->n; i++) {
        ord[i] = i;
        g_cluster_member[i] = -1;
    }
    for (int i = 1; i < l->n; i++) {
        uint16_t v = ord[i];
        int j = i - 1;
        while (j >= 0 && l->item[ord[j]].bpm > l->item[v].bpm) {
            ord[j + 1] = ord[j];
            j--;
        }
        ord[j + 1] = v;
    }
    int nc = 0;
    for (int oi = 0; oi < l->n; oi++) {
        int idx = ord[oi];
        float b = l->item[idx].bpm;
        int best = -1;
        float bd = 1e9f;
        for (int c = 0; c < nc; c++) {
            float nlo = fmin1(out[c].lo, b), nhi = fmax1(out[c].hi, b),
                  d = fabs1(b - out[c].center);
            if (nhi - nlo <= maxspan && d <= radius && d < bd) {
                best = c;
                bd = d;
            }
        }
        if (best < 0) {
            if (nc >= maxc)
                continue;
            best = nc++;
            out[best].n = 0;
            out[best].center = out[best].lo = out[best].hi = b;
        }
        Cluster *c = &out[best];
        g_cluster_member[idx] = best;
        c->n++;
        c->lo = fmin1(c->lo, b);
        c->hi = fmax1(c->hi, b);
        int n = 0;
        for (int r = 0; r < l->n; r++)
            if (g_cluster_member[r] == best) {
                vals[n] = l->item[r].bpm;
                ws[n] = clip(l->item[r].w, .05f, 2.f);
                n++;
            }
        for (int i = 1; i < n; i++) {
            float vv = vals[i], ww = ws[i];
            int j = i - 1;
            while (j >= 0 && vals[j] > vv) {
                vals[j + 1] = vals[j];
                ws[j + 1] = ws[j];
                j--;
            }
            vals[j + 1] = vv;
            ws[j + 1] = ww;
        }
        float sw = 0, cs = 0;
        for (int k = 0; k < n; k++)
            sw += ws[k];
        for (int k = 0; k < n; k++) {
            cs += ws[k];
            if (cs >= sw * .5f) {
                c->center = vals[k];
                break;
            }
        }
    }
    return nc;
}
static int get_dec(const McuHrrrFrontend *s, int family, int ch, int n, float *out) {
    if (family == 0)
        return ring_get_dec(s->rr[ch], MCU_DEC_LONG_N, s->long_head, s->long_count, n,
                            proc_qscale(ch), out);
    if (family == 1)
        return ring_get_dec(s->grav[ch], MCU_DEC_LONG_N, s->long_head, s->long_count, n, MCU_Q_GRAV,
                            out);
    if (family == 2)
        return ring_get_dec(s->mod[ch], MCU_DEC_LONG_N, s->long_head, s->long_count, n,
                            proc_qscale(ch), out);
    if (family == 3)
        return ring_get_dec(s->hrdir[ch], MCU_DEC_HR_N, s->hr_head, s->hr_count, n, proc_qscale(ch),
                            out);
    return ring_get_dec(s->env[ch], MCU_DEC_HR_N, s->hr_head, s->hr_count, n, proc_qscale(ch), out);
}

/* HR energy-event reconstruction: replay carrier filters from saved exact start state. */
static int carrier_start_state(const McuHrrrFrontend *s, int W, int band, int axis,
                               McuBiquadState st[2]) {
    int ticks = W / 2; /* A window starting at raw sample 0 must start from zero causal state. */
    if (s->sample_count == (uint32_t)W * 100) {
        memset(st, 0, 2 * sizeof(*st));
        return 1;
    }
    if ((int)(s->sample_count / 200) < ticks)
        return 0;
    if (ticks >= s->snap_count)
        return 0;
    int ix = (s->snap_head - ticks + 9) % 9;
    memcpy(st, s->car_snap[ix][band][axis], 2 * sizeof(*st));
    return 1;
}
static void energy_events(McuHrrrFrontend *s, int W, RawList *l) {
    int n = W * 100;
    if (n > s->raw_count)
        return;
    float *x = g_outer.energy[0], *en = g_outer.energy[1], *cpy = g_outer.energy[2];
    for (int b = 0; b < 3; b++)
        for (int mod = 0; mod < 2; mod++) {
            int a0 = mod ? 3 : 0;
            memset(en, 0, n * 4);
            for (int a = 0; a < 3; a++) {
                ring_get_raw(s, a0 + a, n, x);
                McuBiquadState st0[2];
                if (!carrier_start_state(s, W, b, a0 + a, st0))
                    continue;
                McuBiquadState st[2];
                memcpy(st, st0, sizeof(st));
                double ss = 0;
                for (int i = 0; i < n; i++) {
                    float car = McuSos_Step(&F_BP_CARRIER[b], st, x[i]);
                    ss += (double)car * car;
                }
                float rms = sqrtf(ss / n) + 1e-9f;
                memcpy(st, st0, sizeof(st));
                for (int i = 0; i < n; i++) {
                    float car = McuSos_Step(&F_BP_CARRIER[b], st, x[i]) / rms;
                    en[i] += car * car;
                }
            }
            for (int i = 0; i < n; i++)
                en[i] = sqrtf(en[i] / 3.f);
            McuBiquadState lp[1] = {{0}};
            McuSos_Process(&F_LP5, lp, en, en, n);
            memcpy(cpy, en, n * 4);
            float med = McuMedian(cpy, n);
            for (int i = 0; i < n; i++)
                en[i] -= med;
            memcpy(cpy, en, n * 4);
            float q75 = McuQuantile(cpy, n, .75f);
            float sd = McuStd(en, n);
            for (int qt = 0; qt < 3; qt++) {
                float qthr = (float[]){.45f, .60f, .75f}[qt];
                float prom = q75 > 0 ? q75 * qthr : sd * .3f;
                int16_t *idx = g_energy_idx;
                int np = find_event_peaks(en, n, (int)fmax1(20, 100 * 60 / 180 * .88f),
                                          fmax1(1e-5f, prom), idx, 400);
                if (np < 5)
                    continue;
                float *di = g_inner[0], *cp = g_inner[1], *cc = g_inner[2];
                for (int i = 1; i < np; i++)
                    di[i - 1] = (idx[i] - idx[i - 1]) / 100.f;
                memcpy(cp, di, (np - 1) * 4);
                float dmed = McuMedian(cp, np - 1);
                for (int i = 0; i < np - 1; i++)
                    cp[i] = fabsf(di[i] - dmed);
                float mad = McuMedian(cp, np - 1), reg = fmax1(0, 1 - mad / (dmed * .25f + 1e-9f));
                float rate_med = 60 / dmed,
                      rate_span = 60 * (np - 1) / ((idx[np - 1] - idx[0]) / 100.f),
                      rate_count = 60 * np / (float)W;
                float ncc = 0;
                if (np >= 4) {
                    float tmpl[41] = {0}, sn[41];
                    int16_t *valid = g_energy_valid;
                    int nv = 0;
                    for (int p = 0; p < np; p++)
                        if (idx[p] >= 20 && idx[p] + 20 < n && nv < 400)
                            valid[nv++] = idx[p];
                    if (nv >= 4) { /* Python uses element-wise median template, not mean. */
                        for (int k = -20; k <= 20; k++) {
                            for (int p = 0; p < nv; p++)
                                cpy[p] = en[valid[p] + k];
                            tmpl[k + 20] = McuMedian(cpy, nv);
                        }
                        int nc = 0;
                        for (int p = 0; p < nv; p++) {
                            for (int k = -20; k <= 20; k++)
                                sn[k + 20] = en[valid[p] + k];
                            cc[nc++] = McuCorr(sn, tmpl, 41);
                        }
                        ncc = McuMedian(cc, nc);
                    }
                }
                float rates[3] = {rate_med, rate_span, rate_count};
                uint8_t em[3] = {M_ENERGY_MED, M_ENERGY_SPAN, M_ENERGY_COUNT};
                for (int z = 0; z < 3; z++)
                    if (rates[z] >= 40 && rates[z] <= 180) {
                        raw_add(l, rates[z], 1 + reg + fmax1(0, ncc), em[z], (uint8_t)(mod ? 7 : 6),
                                (uint8_t)mod, (uint8_t)b, reg + fmax1(0, ncc));
                        RawCand *q = &l->item[l->n - 1];
                        q->reg = reg;
                        q->ncc = ncc;
                        q->event_n = np;
                    }
            }
        }
}
/* Build HR base candidates for any 8/10/16s window. */
static int hr_base(McuHrrrFrontend *s, int W, HrBase *out, int maxout) {
    int n = W * 25;
    if (n > s->hr_count)
        return 0;
    HrBase *alltmp = g_base_all.hr;
    RawList *raw = &g_raw_list;
    memset(raw, 0, sizeof(*raw));
    float *x = g_outer.rr[0];
    Peak4 pk[8];
    for (int a = 0; a < 6; a++) {
        get_dec(s, 3, a, n, x);
        int np = psd_peaks(x, n, 25, 40, 180, 2, 3, pk);
        for (int k = 0; k < np; k++)
            raw_add(raw, pk[k].bpm, fmin1(3, pk[k].a + pk[k].b), M_DIRECT_PSD, a, a >= 3, 0,
                    pk[k].a + pk[k].b);
        np = acf_peaks(x, n, 25, 40, 180, 1, pk);
        for (int k = 0; k < np; k++)
            raw_add(raw, pk[k].bpm, fmax1(.1f, pk[k].a), M_DIRECT_ACF, a, a >= 3, 0, pk[k].a);
    }
    for (int b = 0; b < 3; b++)
        for (int a = 0; a < 6; a++) {
            get_dec(s, 4, b * 6 + a, n, x);
            int np = psd_peaks(x, n, 25, 40, 180, 2, 3, pk);
            for (int k = 0; k < np; k++)
                raw_add(raw, pk[k].bpm, fmin1(3, pk[k].a + pk[k].b), M_ENV_PSD, a, a >= 3,
                        (uint8_t)b, pk[k].a + pk[k].b);
            np = acf_peaks(x, n, 25, 40, 180, 1, pk);
            for (int k = 0; k < np; k++)
                raw_add(raw, pk[k].bpm, fmax1(.1f, pk[k].a), M_ENV_ACF, a, a >= 3, (uint8_t)b,
                        pk[k].a);
        }
    energy_events(s, W, raw);
    Cluster cl[MAX_CL];
    int nc = cluster_raw(raw, 2.5f, 4.f, cl, MAX_CL), nf = 0;
    float *wx = g_outer.rr[1];
    for (int ci = 0; ci < nc && nf < MAX_CL; ci++) {
        Cluster *c = &cl[ci];
        float *vals = g_inner[1];
        int nm = 0;
        for (int ri = 0; ri < raw->n; ri++)
            if (g_cluster_member[ri] == ci)
                vals[nm++] = raw->item[ri].bpm;
        float *cp = g_inner[2];
        memcpy(cp, vals, nm * 4);
        float med = McuMedian(cp, nm);
        for (int k = 0; k < nm; k++)
            cp[k] = fabsf(vals[k] - med);
        HrBase f = {0};
        f.bpm = c->center;
        float mn = vals[0], mx = vals[0];
        for (int k = 1; k < nm; k++) {
            mn = fmin1(mn, vals[k]);
            mx = fmax1(mx, vals[k]);
        }
        f.span = mx - mn;
        f.spread = McuMedian(cp, nm);
        uint8_t axis_seen[6] = {0}, mod_seen[2] = {0}, env_seen[6] = {0}, dir_seen[6] = {0},
                psd_seen[6] = {0}, acf_seen[6] = {0};
        uint16_t bandmask = 0;
        uint32_t energymask = 0;
        float axisbest[6] = {0};
        for (int ri = 0; ri < raw->n; ri++)
            if (g_cluster_member[ri] == ci) {
                RawCand *q = &raw->item[ri];
                if (q->source < 6) {
                    axis_seen[q->source] = 1;
                    axisbest[q->source] = fmax1(axisbest[q->source], q->qual);
                    if (q->method == M_ENV_PSD || q->method == M_ENV_ACF)
                        env_seen[q->source] = 1;
                    if (q->method == M_DIRECT_PSD || q->method == M_DIRECT_ACF)
                        dir_seen[q->source] = 1;
                    if (q->method == M_ENV_PSD || q->method == M_DIRECT_PSD)
                        psd_seen[q->source] = 1;
                    if (q->method == M_ENV_ACF || q->method == M_DIRECT_ACF)
                        acf_seen[q->source] = 1;
                }
                mod_seen[q->mod] = 1; /* Python band_support counts unique (mod,str(band)): direct,
                                         env0..2 and E0..2 are distinct. */
                int bcat = -1;
                if (q->method == M_DIRECT_PSD || q->method == M_DIRECT_ACF)
                    bcat = 0;
                else if (q->method == M_ENV_PSD || q->method == M_ENV_ACF)
                    bcat = 1 + (q->band % 3);
                else if (is_energy_method(q->method))
                    bcat = 4 + (q->band % 3);
                if (bcat >= 0)
                    bandmask |= (uint16_t)(1u << (q->mod * 7 + bcat));
                if (is_energy_method(q->method)) {
                    if (q->mod == 0)
                        f.energy_acc = 1;
                    else
                        f.energy_gyro = 1;
                    f.energy_reg = fmax1(f.energy_reg, q->reg);
                    f.energy_ncc = fmax1(f.energy_ncc, q->ncc);
                    f.energy_event_n = fmax1(f.energy_event_n, q->event_n);
                    int et = (int)q->method - (int)M_ENERGY_MED;
                    int ek = ((int)q->mod * 3 + (int)(q->band % 3)) * 3 + et;
                    energymask |= (1u << ek);
                }
            }
        for (int a = 0; a < 6; a++) {
            f.n_axes += axis_seen[a];
            f.acc_axes += (a < 3 && axis_seen[a]);
            f.gyro_axes += (a >= 3 && axis_seen[a]);
            f.env_axes += env_seen[a];
            f.direct_axes += dir_seen[a];
            f.cross_family_axes += (env_seen[a] && dir_seen[a]);
            f.psd_axes += psd_seen[a];
            f.acf_axes += acf_seen[a];
            if (a < 3)
                f.qual_acc += fmin1(4, axisbest[a]);
            else
                f.qual_gyro += fmin1(4, axisbest[a]);
        }
        f.n_mods = mod_seen[0] + mod_seen[1];
        f.qual_sum = f.qual_acc + f.qual_gyro;
        f.qual_minmod = fmin1(f.qual_acc, f.qual_gyro);
        for (int b = 0; b < 14; b++)
            f.band_support += (bandmask >> b) & 1;
        f.energy_count = 0;
        for (int b = 0; b < 18; b++)
            f.energy_count += (energymask >> b) & 1;
        float fa[18], fg[18];
        int na = 0, ng = 0;
        for (int b = 0; b < 3; b++)
            for (int a = 0; a < 6; a++) {
                get_dec(s, 4, b * 6 + a, n, wx);
                float ad, sk;
                fold_quality(wx, n, 25, f.bpm, &ad, &sk);
                if (a < 3)
                    fa[na++] = ad;
                else
                    fg[ng++] = ad;
            }
        for (int i = 1; i < na; i++) {
            float v = fa[i];
            int j = i - 1;
            while (j >= 0 && fa[j] < v) {
                fa[j + 1] = fa[j];
                j--;
            }
            fa[j + 1] = v;
        }
        for (int i = 1; i < ng; i++) {
            float v = fg[i];
            int j = i - 1;
            while (j >= 0 && fg[j] < v) {
                fg[j + 1] = fg[j];
                j--;
            }
            fg[j + 1] = v;
        }
        float ta[3] = {fa[0], fa[1], fa[2]}, tg[3] = {fg[0], fg[1], fg[2]};
        f.fold_acc = McuMedian(ta, 3);
        f.fold_gyro = McuMedian(tg, 3);
        f.fold_min = fmin1(f.fold_acc, f.fold_gyro);
        f.boundary = fmin1(f.bpm - 40, 180 - f.bpm);
        alltmp[nf++] = f;
    }
    /* Python priority: (n_mods,cross_family_axes,n_axes,-span,qual_minmod), descending; build all
     * clusters before truncation. */
    for (int i = 1; i < nf; i++) {
        HrBase v = alltmp[i];
        int j = i - 1;
        while (j >= 0) {
            HrBase *a = &alltmp[j];
            int less =
                (a->n_mods < v.n_mods) ||
                (a->n_mods == v.n_mods && a->cross_family_axes < v.cross_family_axes) ||
                (a->n_mods == v.n_mods && a->cross_family_axes == v.cross_family_axes &&
                 a->n_axes < v.n_axes) ||
                (a->n_mods == v.n_mods && a->cross_family_axes == v.cross_family_axes &&
                 a->n_axes == v.n_axes && a->span > v.span) ||
                (a->n_mods == v.n_mods && a->cross_family_axes == v.cross_family_axes &&
                 a->n_axes == v.n_axes && a->span == v.span && a->qual_minmod < v.qual_minmod);
            if (!less)
                break;
            alltmp[j + 1] = alltmp[j];
            j--;
        }
        alltmp[j + 1] = v;
    }
    int keep = nf;
    if (keep > 14)
        keep = 14;
    if (keep > maxout)
        keep = maxout;
    for (int i = 0; i < keep; i++)
        out[i] = alltmp[i];
    return keep;
}

static void rank_pct(const HrBase *b, int n, int field, float *out) {
    float vals[16];
    for (int i = 0; i < n; i++) {
        switch (field) {
        case 0:
            vals[i] = b[i].n_axes;
            break;
        case 1:
            vals[i] = b[i].n_mods;
            break;
        case 2:
            vals[i] = b[i].cross_family_axes;
            break;
        case 3:
            vals[i] = b[i].band_support;
            break;
        case 4:
            vals[i] = b[i].energy_ncc;
            break;
        case 5:
            vals[i] = b[i].energy_reg;
            break;
        case 6:
            vals[i] = b[i].qual_sum;
            break;
        default:
            vals[i] = b[i].fold_min;
        }
    }
    for (int i = 0; i < n; i++) {
        int less = 0, equal = 0;
        for (int j = 0; j < n; j++) {
            if (vals[j] < vals[i])
                less++;
            else if (vals[j] == vals[i])
                equal++;
        }
        out[i] = (less + (equal + 1) * .5f) / n;
    }
}
static int nearest_hr(HrBase *b, int n, float target, float tol) {
    int best = -1;
    float bd = 1e9;
    for (int i = 0; i < n; i++) {
        float d = fabs1(b[i].bpm - target);
        if (d < bd) {
            bd = d;
            best = i;
        }
    }
    return bd <= tol ? best : -1;
}

uint8_t McuBuildHrCandidates(McuHrrrFrontend *s, McuHrFeatCandidate out[MCU_MAX_FEAT_CAND]) {
    HrBase L[16], S8[16], S10[16];
    int nl = hr_base(s, 16, L, 16), n8 = hr_base(s, 8, S8, 16), n10 = hr_base(s, 10, S10, 16);
    if (!nl)
        return 0;
    float maxq = 1e-6, maxax = 1, maxm = 1;
    for (int i = 0; i < nl; i++) {
        maxq = fmax1(maxq, L[i].qual_sum);
        maxax = fmax1(maxax, L[i].n_axes);
        maxm = fmax1(maxm, L[i].n_mods);
    }
    float ranks[8][16];
    for (int k = 0; k < 8; k++)
        rank_pct(L, nl, k, ranks[k]);
    int no = 0;
    for (int i = 0; i < nl && no < MCU_MAX_FEAT_CAND; i++) {
        float *f = out[no].feat;
        memset(f, 0, MCU_HR_FEAT_N * 4);
        HrBase *r = &L[i];
        float base[26] = {r->span,         r->spread,       r->n_axes,
                          r->n_mods,       r->acc_axes,     r->gyro_axes,
                          r->env_axes,     r->direct_axes,  r->cross_family_axes,
                          r->band_support, r->psd_axes,     r->acf_axes,
                          r->energy_acc,   r->energy_gyro,  r->energy_reg,
                          r->energy_ncc,   r->energy_count, r->energy_event_n,
                          r->qual_acc,     r->qual_gyro,    r->qual_sum,
                          r->fold_acc,     r->fold_gyro,    r->boundary,
                          r->qual_minmod,  r->fold_min};
        memcpy(f, base, 26 * 4);
        f[26] = (r->acc_axes > 0 && r->gyro_axes > 0);
        f[27] = (r->energy_acc > 0 && r->energy_gyro > 0);
        f[28] = r->qual_sum / maxq;
        f[29] = r->n_axes / maxax;
        f[30] = r->n_mods / maxm;
        f[31] = fmin1(r->qual_acc, r->qual_gyro) / (fmax1(r->qual_acc, r->qual_gyro) + 1e-6f);
        f[32] = fmin1(r->fold_acc, r->fold_gyro) /
                (fmax1(fmax1(fabs1(r->fold_acc), fabs1(r->fold_gyro)), 1e-3f));
        for (int k = 0; k < 8; k++)
            f[33 + k] = ranks[k][i];
        int off[2] = {41, 70};
        HrBase *ss[2] = {S8, S10};
        int ns[2] = {n8, n10};
        for (int w = 0; w < 2; w++) {
            int q = nearest_hr(ss[w], ns[w], r->bpm, 4);
            int o = off[w];
            float dmin = 8;
            if (ns[w]) {
                for (int z = 0; z < ns[w]; z++)
                    dmin = fmin1(dmin, fabs1(ss[w][z].bpm - r->bpm));
            }
            f[o] = q >= 0;
            f[o + 1] = fmin1(dmin, 8) / 8;
            if (q >= 0) {
                HrBase *a = &ss[w][q];
                f[o + 2] = a->n_axes;
                f[o + 3] = a->n_mods;
                f[o + 4] = a->acc_axes;
                f[o + 5] = a->gyro_axes;
                f[o + 6] = a->cross_family_axes;
                f[o + 7] = a->band_support;
                f[o + 8] = a->psd_axes;
                f[o + 9] = a->acf_axes;
                f[o + 10] = a->energy_acc;
                f[o + 11] = a->energy_gyro;
                f[o + 12] = a->energy_reg;
                f[o + 13] = a->energy_ncc;
                f[o + 14] = a->energy_count;
                f[o + 15] = a->energy_event_n;
                f[o + 16] = a->qual_sum;
                f[o + 17] = a->fold_min;
                f[o + 18] = a->qual_minmod;
                f[o + 19] = a->boundary;
                f[o + 20] = (a->energy_acc && a->energy_gyro);
            }
            int h = nearest_hr(ss[w], ns[w], r->bpm / 2, 4);
            f[o + 21] = h >= 0;
            if (h >= 0) {
                f[o + 22] = ss[w][h].cross_family_axes;
                f[o + 23] = ss[w][h].energy_ncc;
                f[o + 24] = ss[w][h].fold_min;
            }
            int db = nearest_hr(ss[w], ns[w], r->bpm * 2, 4);
            f[o + 25] = db >= 0;
            if (db >= 0) {
                f[o + 26] = ss[w][db].cross_family_axes;
                f[o + 27] = ss[w][db].energy_ncc;
                f[o + 28] = ss[w][db].fold_min;
            }
        }
        f[99] = f[41] * f[70];
        f[100] = f[61] + f[90];
        f[101] = fmax1(f[54], f[83]);
        f[102] = fmax1(f[53], f[82]);
        f[103] = f[47] + f[76];
        f[104] = (f[42] + f[71]) * .5f;
        out[no].bpm = r->bpm;
        out[no].utility = McuLr_HrCandidateUtility(f);
        memcpy(out[no].base, base, 26 * 4);
        no++;
    }
    return no;
}

/* RR base long/short construction */
static int rr_base(McuHrrrFrontend *s, int W, RrBase *out, int maxout) {
    int n = W * 25;
    if (n > s->long_count)
        return 0;
    RawList *raw = &g_raw_list;
    memset(raw, 0, sizeof(*raw));
    float *x = g_outer.rr[0], *pca = g_outer.rr[1], *x0 = g_outer.rr[2], *x1 = g_outer.rr[3],
          *x2 = g_outer.rr[4];
    Peak4 pk[8];
    for (int a = 0; a < 6; a++) {
        get_dec(s, 0, a, n, x);
        int np = psd_peaks(x, n, 25, 6, 60, 3, 1.2f, pk);
        for (int k = 0; k < np; k++)
            raw_add(raw, pk[k].bpm, fmin1(3, pk[k].a + pk[k].b), M_PSD, a, a >= 3, 0,
                    pk[k].a + pk[k].b);
        np = acf_peaks(x, n, 25, 6, 60, 2, pk);
        for (int k = 0; k < np; k++)
            raw_add(raw, pk[k].bpm, fmax1(.1f, pk[k].a), M_ACF, a, a >= 3, 0, pk[k].a);
        np = event_candidates(x, n, 25, 6, 60, pk);
        for (int k = 0; k < np; k++)
            raw_add(raw, pk[k].bpm, fmax1(.1f, pk[k].a), (uint8_t)pk[k].pow, a, a >= 3, 0, pk[k].a);
    }
    for (int mod = 0; mod < 2; mod++) {
        for (int a = 0; a < 3; a++)
            get_dec(s, 0, mod * 3 + a, n, a == 0 ? x0 : (a == 1 ? x1 : x2));
        McuPca1_3(x0, x1, x2, pca, n);
        int src = 6 + mod;
        int np = psd_peaks(pca, n, 25, 6, 60, 3, 1.2f, pk);
        for (int k = 0; k < np; k++)
            raw_add(raw, pk[k].bpm, fmin1(2, pk[k].a + pk[k].b), M_PCA_PSD, src, mod, 0,
                    pk[k].a + pk[k].b);
        np = acf_peaks(pca, n, 25, 6, 60, 2, pk);
        for (int k = 0; k < np; k++)
            raw_add(raw, pk[k].bpm, fmax1(.1f, pk[k].a), M_PCA_ACF, src, mod, 0, pk[k].a);
        np = event_candidates(pca, n, 25, 6, 60, pk);
        for (int k = 0; k < np; k++)
            raw_add(raw, pk[k].bpm, fmax1(.1f, pk[k].a), M_PCA_EVENT, src, mod, 0, pk[k].a);
    }
    for (int b = 0; b < 2; b++)
        for (int a = 0; a < 6; a++) {
            get_dec(s, 2, b * 6 + a, n, x);
            int np = psd_peaks(x, n, 25, 6, 60, 2, 1.2f, pk);
            for (int k = 0; k < np; k++)
                raw_add(raw, pk[k].bpm, fmin1(1.5f, pk[k].a + pk[k].b), M_MOD_PSD, a, a >= 3, b,
                        pk[k].a + pk[k].b);
        } /* gravity 3 + pca */
    for (int a = 0; a < 3; a++)
        get_dec(s, 1, a, n, a == 0 ? x0 : (a == 1 ? x1 : x2));
    for (int j = 0; j < 4; j++) {
        if (j < 3)
            memcpy(x, j == 0 ? x0 : (j == 1 ? x1 : x2), n * 4);
        else
            McuPca1_3(x0, x1, x2, x, n);
        int src = 8 + j;
        int np = psd_peaks(x, n, 25, 6, 60, 3, 1.0f, pk);
        for (int k = 0; k < np; k++)
            raw_add(raw, pk[k].bpm, fmin1(2.5f, pk[k].a + pk[k].b), M_GRAV_PSD, src, 0, 0,
                    pk[k].a + pk[k].b);
        np = acf_peaks(x, n, 25, 6, 60, 2, pk);
        for (int k = 0; k < np; k++)
            raw_add(raw, pk[k].bpm, fmax1(.1f, pk[k].a), M_GRAV_ACF, src, 0, 0, pk[k].a);
        np = event_candidates(x, n, 25, 6, 60, pk);
        for (int k = 0; k < np; k++)
            raw_add(raw, pk[k].bpm, fmax1(.1f, pk[k].a), M_GRAV_EVENT, src, 0, 0, pk[k].a);
    }
    /* harmonic hypotheses from top20 qual */ int idx[MAX_RAW];
    for (int i = 0; i < raw->n; i++)
        idx[i] = i;
    for (int i = 1; i < raw->n; i++) {
        int v = idx[i], j = i - 1;
        while (j >= 0 && raw->item[idx[j]].qual < raw->item[v].qual) {
            idx[j + 1] = idx[j];
            j--;
        }
        idx[j + 1] = v;
    }
    int orig = raw->n;
    for (int z = 0; z < orig && z < 20; z++) {
        RawCand q = raw->item[idx[z]];
        float fac[4] = {.5f, 2, 1.f / 3, 3};
        uint8_t mt[4] = {M_HYP_HALF, M_HYP_DOUBLE, M_HYP_THIRD, M_HYP_TRIPLE};
        for (int k = 0; k < 4; k++) {
            float b = q.bpm * fac[k];
            if (b >= 6 && b <= 60)
                raw_add(raw, b, .12f, mt[k], q.source, q.mod, 0,
                        fmin1(.25f, fmax1(.02f, q.qual * .04f)));
        }
    }
    Cluster cl[MAX_CL];
    int nc = cluster_raw(raw, 1.5f, 2.6f, cl, MAX_CL), nb = 0;
    RrBase *all = g_base_all.rr;
    for (int ci = 0; ci < nc; ci++) {
        Cluster *c = &cl[ci];
        float *v = all[nb].v;
        memset(v, 0, 40 * 4);
        float mn = 1e9, mx = -1e9;
        uint16_t srcmask = 0, accmask = 0, gymask = 0, gravmask = 0, dirmask = 0, modmask = 0,
                 psdmask = 0, acfmask = 0, evmask = 0;
        uint8_t mods = 0;
        float qbest[112] = {0};
        int real = 0, hyp = 0, pca_sup = 0;
        for (int ri = 0; ri < raw->n; ri++)
            if (g_cluster_member[ri] == ci) {
                RawCand *q = &raw->item[ri];
                mn = fmin1(mn, q->bpm);
                mx = fmax1(mx, q->bpm);
                int ish = q->method >= M_HYP_HALF;
                if (ish) {
                    hyp++;
                    continue;
                }
                real++;
                srcmask |= 1u << (q->source & 15);
                mods |= 1u << q->mod;
                if (q->method == M_GRAV_PSD || q->method == M_GRAV_ACF || q->method == M_GRAV_EVENT)
                    gravmask |= 1u << (q->source & 15);
                else if (q->mod == 0)
                    accmask |= 1u << (q->source & 15);
                else
                    gymask |= 1u << (q->source & 15);
                if (q->method == M_MOD_PSD)
                    modmask |= 1u << (q->source & 15);
                else
                    dirmask |= 1u << (q->source & 15);
                if (q->method == M_PSD || q->method == M_PCA_PSD || q->method == M_GRAV_PSD)
                    psdmask |= 1u << (q->source & 15);
                if (q->method == M_ACF || q->method == M_PCA_ACF || q->method == M_GRAV_ACF)
                    acfmask |= 1u << (q->source & 15);
                if (q->method == M_EVENT_PEAK || q->method == M_EVENT_VALLEY ||
                    q->method == M_EVENT_ZC || q->method == M_PCA_EVENT ||
                    q->method == M_GRAV_EVENT)
                    evmask |= 1u << (q->source & 15);
                if (q->method == M_PCA_PSD || q->method == M_PCA_ACF || q->method == M_PCA_EVENT)
                    pca_sup++;
                int fam;
                if (q->method == M_GRAV_PSD || q->method == M_GRAV_ACF || q->method == M_GRAV_EVENT)
                    fam = 3;
                else if (q->method == M_PCA_PSD || q->method == M_PCA_ACF ||
                         q->method == M_PCA_EVENT)
                    fam = 4;
                else if (q->method == M_MOD_PSD)
                    fam = 5 + q->band;
                else if (q->method == M_PSD)
                    fam = 0;
                else if (q->method == M_ACF)
                    fam = 1;
                else
                    fam = 2;
                int key = (q->source & 15) * 7 + fam;
                qbest[key] = fmax1(qbest[key], q->qual);
            }
        v[0] = mx - mn;
        for (int k = 0; k < 16; k++) {
            v[1] += !!(srcmask & (1u << k));
            v[3] += !!(accmask & (1u << k));
            v[4] += !!(gymask & (1u << k));
            v[5] += !!(gravmask & (1u << k));
            v[6] += !!(dirmask & (1u << k));
            v[7] += !!(modmask & (1u << k));
            v[8] += !!(psdmask & (1u << k));
            v[9] += !!(acfmask & (1u << k));
            v[10] += !!(evmask & (1u << k));
        }
        v[2] = !!(mods & 1) + !!(mods & 2);
        v[11] = pca_sup;
        for (int k = 0; k < 112; k++)
            v[12] += fmin1(3, qbest[k]);
        float facc[6], fgyr[6], fabacc[6], fabgyr[6], fgr[3], abgr[3];
        for (int a = 0; a < 6; a++) {
            get_dec(s, 0, a, n, x);
            float ad, sk;
            fold_quality(x, n, 25, c->center, &ad, &sk);
            if (a < 3) {
                facc[a] = ad;
                fabacc[a] = sk - ad;
            } else {
                fgyr[a - 3] = ad;
                fabgyr[a - 3] = sk - ad;
            }
        }
        for (int a = 0; a < 3; a++) {
            get_dec(s, 1, a, n, x);
            float ad, sk;
            fold_quality(x, n, 25, c->center, &ad, &sk);
            fgr[a] = ad;
            abgr[a] = sk - ad;
        } /* descending median top2 */
        for (int a = 1; a < 3; a++) {
            float z = facc[a];
            int j = a - 1;
            while (j >= 0 && facc[j] < z) {
                facc[j + 1] = facc[j];
                j--;
            }
            facc[j + 1] = z;
            z = fgyr[a];
            j = a - 1;
            while (j >= 0 && fgyr[j] < z) {
                fgyr[j + 1] = fgyr[j];
                j--;
            }
            fgyr[j + 1] = z;
            z = fgr[a];
            j = a - 1;
            while (j >= 0 && fgr[j] < z) {
                fgr[j + 1] = fgr[j];
                j--;
            }
            fgr[j + 1] = z;
        }
        v[13] = (facc[0] + facc[1]) * .5f;
        v[14] = (fgyr[0] + fgyr[1]) * .5f;
        v[15] = (fgr[0] + fgr[1]) * .5f;
        v[16] = fmin1(v[13], v[14]);
        float tt[3] = {v[13], v[14], v[15]};
        v[17] = McuMedian(tt, 3); /* abab top2 approximate median */
        for (int a = 1; a < 3; a++) {
            float z = fabacc[a];
            int j = a - 1;
            while (j >= 0 && fabacc[j] < z) {
                fabacc[j + 1] = fabacc[j];
                j--;
            }
            fabacc[j + 1] = z;
            z = fabgyr[a];
            j = a - 1;
            while (j >= 0 && fabgyr[j] < z) {
                fabgyr[j + 1] = fabgyr[j];
                j--;
            }
            fabgyr[j + 1] = z;
            z = abgr[a];
            j = a - 1;
            while (j >= 0 && abgr[j] < z) {
                abgr[j + 1] = abgr[j];
                j--;
            }
            abgr[j + 1] = z;
        }
        v[18] = (fabacc[0] + fabacc[1]) * .5f;
        v[19] = (fabgyr[0] + fabgyr[1]) * .5f;
        v[20] = (abgr[0] + abgr[1]) * .5f;
        v[21] = fmin1(c->center - 6, 60 - c->center);
        v[22] = real;
        v[23] = hyp;
        all[nb].bpm = c->center;
        nb++;
    }
    /* harmonic nearest on all base */ for (int i = 0; i < nb; i++) {
        float b = all[i].bpm;
        float targets[4] = {b / 2, b * 2, b / 3, b * 3};
        int off[4] = {24, 28, 32, 36};
        for (int h = 0; h < 4; h++) {
            if (targets[h] < 6 || targets[h] > 60)
                continue;
            int bj = -1;
            for (int j = 0; j < nb; j++) {
                float d = fabs1(all[j].bpm - targets[h]);
                if (d > 2)
                    continue; /* Python: max within tolerance by (n_sources, qual), not nearest BPM.
                               */
                if (bj < 0 || all[j].v[1] > all[bj].v[1] ||
                    (all[j].v[1] == all[bj].v[1] && all[j].v[12] > all[bj].v[12]))
                    bj = j;
            }
            if (bj >= 0) {
                int o = off[h];
                all[i].v[o] = all[bj].v[1];
                all[i].v[o + 1] = all[bj].v[12];
                all[i].v[o + 2] = all[bj].v[17];
                all[i].v[o + 3] = all[bj].v[5];
            }
        }
    }
    /* rank strong and harmonic representatives; reconstruct outputs in rank order */ int
        rank[MAX_CL];
    for (int i = 0; i < nb; i++)
        rank[i] = i;
    for (int i = 1; i < nb; i++) {
        int z = rank[i], j = i - 1;
        while (j >= 0) {
            RrBase *a = &all[rank[j]], *b = &all[z];
            int less = (a->v[1] < b->v[1]) || (a->v[1] == b->v[1] && a->v[5] < b->v[5]) ||
                       (a->v[1] == b->v[1] && a->v[5] == b->v[5] && a->v[2] < b->v[2]) ||
                       (a->v[1] == b->v[1] && a->v[5] == b->v[5] && a->v[2] == b->v[2] &&
                        a->v[12] < b->v[12]);
            if (!less)
                break;
            rank[j + 1] = rank[j];
            j--;
        }
        rank[j + 1] = z;
    }
    int keep[MAX_CL], nk = 0;
    for (int i = 0; i < nb && i < 9; i++)
        keep[nk++] = rank[i];
    for (int ii = 0; ii < nb && ii < 7 && nk < maxout; ii++) {
        int i = rank[ii];
        float b = all[i].bpm, targets[2] = {b / 2, b * 2};
        for (int h = 0; h < 2; h++)
            if (targets[h] >= 6 && targets[h] <= 60) {
                int bj = -1;
                for (int j = 0; j < nb; j++) {
                    float d = fabs1(all[j].bpm - targets[h]);
                    if (d > 2)
                        continue; /* Python keep rule: max(n_sources, grav_sources, hyp_count,
                                     qual). */
                    if (bj < 0 || all[j].v[1] > all[bj].v[1] ||
                        (all[j].v[1] == all[bj].v[1] && all[j].v[5] > all[bj].v[5]) ||
                        (all[j].v[1] == all[bj].v[1] && all[j].v[5] == all[bj].v[5] &&
                         all[j].v[23] > all[bj].v[23]) ||
                        (all[j].v[1] == all[bj].v[1] && all[j].v[5] == all[bj].v[5] &&
                         all[j].v[23] == all[bj].v[23] && all[j].v[12] > all[bj].v[12]))
                        bj = j;
                }
                int found = 0;
                for (int z = 0; z < nk; z++)
                    found |= keep[z] == bj;
                if (bj >= 0 && !found)
                    keep[nk++] = bj;
            }
    }
    for (int ii = 0; ii < nb && nk < maxout; ii++) {
        int found = 0;
        for (int z = 0; z < nk; z++)
            found |= keep[z] == rank[ii];
        if (!found)
            keep[nk++] = rank[ii];
    }
    for (int z = 0; z < nk; z++)
        out[z] = all[keep[z]];
    return nk;
}

static int nearest_rr(RrBase *b, int n, float target, float tol) {
    int best = -1;
    for (int i = 0; i < n; i++) {
        float d = fabs1(b[i].bpm - target);
        if (d > tol)
            continue;
        if (best < 0 || b[i].v[1] > b[best].v[1] ||
            (b[i].v[1] == b[best].v[1] && b[i].v[10] > b[best].v[10]) ||
            (b[i].v[1] == b[best].v[1] && b[i].v[10] == b[best].v[10] &&
             b[i].v[17] > b[best].v[17]) ||
            (b[i].v[1] == b[best].v[1] && b[i].v[10] == b[best].v[10] &&
             b[i].v[17] == b[best].v[17] && b[i].v[12] > b[best].v[12]))
            best = i;
    }
    return best;
}
uint8_t McuBuildRrCandidates(McuHrrrFrontend *s, McuRrFeatCandidate out[MCU_MAX_FEAT_CAND]) {
    RrBase L[16], S[16];
    int nl = rr_base(s, 40, L, 16), ns = rr_base(s, 22, S, 16);
    if (!nl)
        return 0;
    float maxq = 1e-6f, maxsrc = 1, maxev = 1;
    for (int i = 0; i < nl; i++) {
        maxq = fmax1(maxq, L[i].v[12]);
        maxsrc = fmax1(maxsrc, L[i].v[1]);
        maxev = fmax1(maxev, L[i].v[10]);
    }
    int no = 0;
    for (int i = 0; i < nl && no < MCU_MAX_FEAT_CAND; i++) {
        float *f = out[no].feat;
        memset(f, 0, MCU_RR_FEAT_N * 4);
        memcpy(f, L[i].v, 40 * 4);
        RrBase *r = &L[i];
        f[40] = (r->v[3] > 0 && r->v[4] > 0);
        f[41] = (r->v[8] > 0) + (r->v[9] > 0) + (r->v[10] > 0) + (r->v[5] > 0) + (r->v[7] > 0);
        f[42] = r->v[12] / maxq;
        f[43] = r->v[1] / maxsrc;
        f[44] = r->v[10] / maxev;
        f[45] = r->v[12] / (r->v[1] + .5f);
        f[46] = (r->v[13] + r->v[14] + r->v[15]) / 3;
        f[47] = (r->v[18] + r->v[19] + r->v[20]) / 3;
        int po[4] = {24, 28, 32, 36}, eo = 48;
        for (int h = 0; h < 4; h++) {
            int o = po[h];
            f[eo + h * 4] = r->v[1] - r->v[o];
            f[eo + h * 4 + 1] = r->v[17] - r->v[o + 2];
            f[eo + h * 4 + 2] = r->v[12] - r->v[o + 1];
            f[eo + h * 4 + 3] = r->v[5] - r->v[o + 3];
        }
        float target[3] = {r->bpm, r->bpm / 2, r->bpm * 2};
        int so[3] = {64, 70, 76};
        for (int h = 0; h < 3; h++) {
            int q = nearest_rr(S, ns, target[h], 2);
            int o = so[h];
            if (q >= 0) {
                f[o] = 1;
                f[o + 1] = S[q].v[1];
                f[o + 2] = S[q].v[10];
                f[o + 3] = S[q].v[17];
                f[o + 4] = S[q].v[12];
                f[o + 5] = S[q].v[5];
            }
        }
        f[82] = f[65] - f[71];
        f[83] = f[65] - f[77];
        f[84] = f[67] - f[73];
        f[85] = f[67] - f[79];
        out[no].bpm = r->bpm;
        out[no].utility = McuLr_RrCandidateUtility(f);
        no++;
    }
    return no;
}
