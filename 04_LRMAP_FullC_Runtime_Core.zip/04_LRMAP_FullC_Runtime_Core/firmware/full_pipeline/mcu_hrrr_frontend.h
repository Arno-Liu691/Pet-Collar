#ifndef MCU_HRRR_FRONTEND_H
#define MCU_HRRR_FRONTEND_H
#include <stdint.h>
#include "mcu_dsp_core.h"
#include "../algorithm/mcu_hrrr_lrmap.h"
#include "../generated/mcu_lr_models.h"
#define MCU_HR_FEAT_N 105
#define MCU_RR_FEAT_N 86
#define MCU_HR_GATE_BASE_N 71
#define MCU_RR_GATE_N 102
#define MCU_MAX_FEAT_CAND 16
#define MCU_RAW_RING_N 1600
#define MCU_DEC_LONG_N 1000
#define MCU_DEC_HR_N 400
/* Compact ring storage. Computation remains float32; only history storage is int16. */
#define MCU_Q_RAW_ACC 16000.0f
#define MCU_Q_RAW_GYRO 100.0f
#define MCU_Q_PROC_ACC 20000.0f
#define MCU_Q_PROC_GYRO 200.0f
#define MCU_Q_GRAV 30000.0f

typedef struct {
    float bpm;
    float feat[MCU_HR_FEAT_N];
    float utility;
    /* base physical fields used by gate; same source as feat */
    float base[26];
} McuHrFeatCandidate;
typedef struct {
    float bpm;
    float feat[MCU_RR_FEAT_N];
    float utility;
} McuRrFeatCandidate;

typedef struct {
    /* live causal filter states */
    McuBiquadState rr_s[6][2], hr_s[6][2];
    McuBiquadState car_s[3][6][2], amp_s[3][6][1], env_s[3][6][2], mod_s[2][6][2];
    McuBiquadState grav_lp[3][1], grav_hp[3][1], grav_out[3][1];
    /* last 16s raw for exact energy-event reconstruction */
    int16_t raw[6][MCU_RAW_RING_N];
    uint16_t raw_head, raw_count;
    /* 25Hz processed rings. Fixed-scale int16 storage; dequantized before DSP. */
    int16_t rr[6][MCU_DEC_LONG_N], grav[3][MCU_DEC_LONG_N], mod[12][MCU_DEC_LONG_N];
    uint16_t long_head, long_count;
    int16_t hrdir[6][MCU_DEC_HR_N], env[18][MCU_DEC_HR_N];
    uint16_t hr_head, hr_count;
    /* carrier state snapshots every 2s: current + last 8 */
    McuBiquadState car_snap[9][3][6][2];
    uint8_t snap_head, snap_count;
    uint32_t sample_count;
} McuHrrrFrontend;

void McuHrrrFrontend_Reset(McuHrrrFrontend *s);
void McuHrrrFrontend_Push(McuHrrrFrontend *s, const float sample6[6]);
uint8_t McuHrrrFrontend_TickReady(const McuHrrrFrontend *s);
float McuHrrrFrontend_TimeS(const McuHrrrFrontend *s);
float McuHrrrFrontend_RawAt(const McuHrrrFrontend *s, int axis, int ring_index);
uint8_t McuBuildHrCandidates(McuHrrrFrontend *s, McuHrFeatCandidate out[MCU_MAX_FEAT_CAND]);
uint8_t McuBuildRrCandidates(McuHrrrFrontend *s, McuRrFeatCandidate out[MCU_MAX_FEAT_CAND]);
#endif
