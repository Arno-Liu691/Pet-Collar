#include "mcu_hrrr_full.h"
#include <math.h>
#include <string.h>
static float sigm(float x) {
    if (x > 30)
        return 1;
    if (x < -30)
        return 0;
    return 1.f / (1.f + expf(-x));
}
static float clip01(float x) {
    return x < 0 ? 0 : (x > 1 ? 1 : x);
}
static float fmax1(float a, float b) {
    return a > b ? a : b;
}
static float fmin1(float a, float b) {
    return a < b ? a : b;
}
static float percentile(float *a, int n, float q) {
    for (int i = 1; i < n; i++) {
        float v = a[i];
        int j = i - 1;
        while (j >= 0 && a[j] > v) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = v;
    }
    float p = q * (n - 1);
    int i = (int)p;
    float f = p - i;
    return i >= n - 1 ? a[n - 1] : a[i] * (1 - f) + a[i + 1] * f;
}
static void motion_last2s(McuHrrrFullState *s, McuMotionFeatures *f) {
    float amag[200], gmag[200], jerk[199];
    int n = s->front.raw_count < 200 ? s->front.raw_count : 200;
    int start = (s->front.raw_head - n + MCU_RAW_RING_N) % MCU_RAW_RING_N;
    float amin = 1e30f, amax = -1e30f, prev[3] = {0};
    for (int i = 0; i < n; i++) {
        int ix = (start + i) % MCU_RAW_RING_N;
        float ax = McuHrrrFrontend_RawAt(&s->front, 0, ix),
              ay = McuHrrrFrontend_RawAt(&s->front, 1, ix),
              az = McuHrrrFrontend_RawAt(&s->front, 2, ix),
              gx = McuHrrrFrontend_RawAt(&s->front, 3, ix),
              gy = McuHrrrFrontend_RawAt(&s->front, 4, ix),
              gz = McuHrrrFrontend_RawAt(&s->front, 5, ix);
        amag[i] = sqrtf(ax * ax + ay * ay + az * az);
        gmag[i] = sqrtf(gx * gx + gy * gy + gz * gz);
        if (amag[i] < amin)
            amin = amag[i];
        if (amag[i] > amax)
            amax = amag[i];
        if (i) {
            float dx = ax - prev[0], dy = ay - prev[1], dz = az - prev[2];
            jerk[i - 1] = sqrtf(dx * dx + dy * dy + dz * dz) * 100.f;
        }
        prev[0] = ax;
        prev[1] = ay;
        prev[2] = az;
    }
    float t1[200], t2[200];
    memcpy(t1, gmag, n * 4);
    memcpy(t2, jerk, (n > 1 ? n - 1 : 0) * 4);
    f->acc_range_g = n ? amax - amin : 0;
    f->gyro_p95_dps = n ? percentile(t1, n, .95f) : 0;
    f->jerk_p95_gps = n > 1 ? percentile(t2, n - 1, .95f) : 0;
}
void McuHrrrFull_Init(McuHrrrFullState *s) {
    memset(s, 0, sizeof(*s));
    McuHrrrFrontend_Reset(&s->front);
    McuLrMap_Reset(&s->hr_map);
    McuLrMap_Reset(&s->rr_map);
    McuRest_Init(&s->rest);
}
void McuHrrrFull_PushSample(McuHrrrFullState *s, const float x[6]) {
    McuHrrrFrontend_Push(&s->front, x);
    if (s->front.sample_count >= 200 && s->front.sample_count % 100 == 0) {
        McuMotionFeatures f;
        motion_last2s(s, &f);
        uint8_t was = s->rest.in_rest;
        s->rest_dec = McuRest_Update(&s->rest, &f);
        if (!was && s->rest_dec.rest) {
            s->rest_entry_sample = s->front.sample_count;
            s->have_entry = 1;
        }
        if (s->rest_dec.severe) {
            s->have_entry = 0;
            McuLrMap_Reset(&s->hr_map);
            McuLrMap_Reset(&s->rr_map);
            s->prev_hr_sel = s->prev_rr_sel = 0;
        }
    }
}
uint8_t McuHrrrFull_HasOutputTick(const McuHrrrFullState *s) {
    return (uint8_t)(s->front.sample_count % 200 == 0);
}
static int cand_index_hr(McuHrFeatCandidate *c, int n, float bpm) {
    int bi = 0;
    float bd = 1e9;
    for (int i = 0; i < n; i++) {
        float d = fabsf(c[i].bpm - bpm);
        if (d < bd) {
            bd = d;
            bi = i;
        }
    }
    return bi;
}
static int cand_index_rr(McuRrFeatCandidate *c, int n, float bpm) {
    int bi = 0;
    float bd = 1e9;
    for (int i = 0; i < n; i++) {
        float d = fabsf(c[i].bpm - bpm);
        if (d < bd) {
            bd = d;
            bi = i;
        }
    }
    return bi;
}
static void make_hr_gate(const McuHrFeatCandidate *c, const McuLrMapDecision *d, float prev,
                         float out[MCU_HR_GATE_BASE_N]) {
    const float *f = c->feat;
    memset(out, 0, MCU_HR_GATE_BASE_N * sizeof(float));
    /* Frozen hr_gate_lr.json base_features order (71). Candidate fields come from the 105 rate-free
     * HR evidence vector. */
    for (int i = 0; i <= 32; i++)
        out[i] = f[i]; /* span..fold_balance */
    out[33] = f[40];   /* fold_min_erank */
    out[34] = f[37];
    out[35] = f[38];
    out[36] = f[39];
    out[37] = f[33];
    out[38] = f[34];
    out[39] = f[35];
    out[40] = f[36];
    out[41] = f[99];
    out[42] = f[100];
    out[43] = f[101];
    out[44] = f[102];
    out[45] = f[103];
    out[46] = f[104];
    out[47] = f[41];
    out[48] = f[70];
    out[49] = f[61];
    out[50] = f[90];
    out[51] = f[43];
    out[52] = f[72];
    out[53] = f[47];
    out[54] = f[76];
    out[55] = f[58];
    out[56] = f[87];
    out[57] = fmin1(fmax1(d->path_margin, 0), 6);
    out[58] = prev ? fabsf(d->selected_bpm - prev) : 0;
    out[59] = fabsf(d->selected_bpm - d->tracked_bpm);
    out[60] = d->switched;
    out[61] = d->tracker_state == MCU_TRACK_STABLE;
    out[62] = d->tracker_state == MCU_TRACK_CHANGING;
    out[63] = d->tracker_state == MCU_TRACK_REACQUIRE;
    out[64] = f[29] * clip01(f[25]);
    out[65] = clip01(f[8] / 6.f) * clip01(f[25]);
    out[66] = f[27] * clip01(f[15]) * clip01(f[14]);
    out[67] = f[99] * clip01(f[101]) * clip01(f[102]) * clip01(f[100] / 2.f);
    out[68] = f[99] * clip01((f[43] + f[72]) / 12.f);
    out[69] = clip01(f[7] / 6.f) * clip01(f[25]);
    out[70] = clip01(f[6] / 6.f) * clip01(f[25]);
}
static void make_rr_gate(const McuRrFeatCandidate *c, const McuLrMapDecision *d, float prev,
                         float out[102]) {
    const float *f = c->feat;
    memcpy(out, f, 86 * 4);
    float step = prev ? fabsf(d->selected_bpm - prev) : 0,
          gap = fabsf(d->selected_bpm - d->tracked_bpm);
    out[86] = d->path_margin;
    out[87] = d->path_velocity;
    out[88] = d->switched;
    out[89] = step;
    out[90] = gap;
    out[91] = fmin1(fmax1(d->path_margin, 0), 6);
    out[92] = d->switched;
    out[93] = d->tracker_state == MCU_TRACK_STABLE;
    out[94] = d->tracker_state == MCU_TRACK_CHANGING;
    out[95] = d->tracker_state == MCU_TRACK_REACQUIRE;
    out[96] = clip01(f[17]) * clip01(f[41] / 5.f);
    out[97] = clip01(f[44]) * clip01(f[40]);
    out[98] = clip01(f[17]) * fmin1(fmax1(f[67], -1), 1) * f[64];
    out[99] = clip01(f[43]) * clip01(f[65] / 6.f) * f[64];
    out[100] = fmax1(fmax1(f[24], f[28]), fmax1(f[32], f[36]));
    out[101] = fmax1(f[18], fmax1(f[19], f[20]));
}
static int dedup_hr(McuHrFeatCandidate *c, int n, McuBranchCandidate *out) {
    McuBranchCandidate in[16];
    for (int i = 0; i < n; i++)
        in[i] = (McuBranchCandidate){c[i].bpm, c[i].utility, (uint8_t)i};
    return McuLrMap_Dedup(in, n, out, &g_mcu_hr_lrmap_config);
}
static int dedup_rr(McuRrFeatCandidate *c, int n, McuBranchCandidate *out) {
    McuBranchCandidate in[16];
    for (int i = 0; i < n; i++)
        in[i] = (McuBranchCandidate){c[i].bpm, c[i].utility, (uint8_t)i};
    return McuLrMap_Dedup(in, n, out, &g_mcu_rr_lrmap_config);
}
void McuHrrrFull_ComputeTick(McuHrrrFullState *s, McuHrrrVitalOutput *ho, McuHrrrVitalOutput *ro,
                             McuHrFeatCandidate *hc, uint8_t *nhr, McuRrFeatCandidate *rc,
                             uint8_t *nrr, float hr_gate[MCU_HR_GATE_BASE_N],
                             float rr_gate[MCU_RR_GATE_N]) {
    memset(ho, 0, sizeof(*ho));
    memset(ro, 0, sizeof(*ro));
    float t = McuHrrrFrontend_TimeS(&s->front);
    ho->t = ro->t = t;
    uint8_t motion = s->rest_dec.publish, rest = s->rest_dec.rest;
    ho->motion_ok = ro->motion_ok = motion;
    ho->severe = ro->severe = s->rest_dec.severe;
    ho->moderate = ro->moderate = s->rest_dec.moderate;
    /* HR is fully consumed before RR candidates are built.  This permits the
       caller to alias HR/RR candidate workspaces in a union on memory-constrained MCU builds. */
    int nh = McuBuildHrCandidates(&s->front, hc);
    *nhr = nh;
    ho->n_candidates = nh;
    if (nh) {
        McuBranchCandidate dc[16];
        int nd = dedup_hr(hc, nh, dc);
        McuLrMapDecision d = McuLrMap_Update(&s->hr_map, dc, nd, &g_mcu_hr_lrmap_config);
        int ci = cand_index_hr(hc, nh, d.selected_bpm);
        float gb[MCU_HR_GATE_BASE_N];
        make_hr_gate(&hc[ci], &d, s->prev_hr_sel, gb);
        if (hr_gate)
            memcpy(hr_gate, gb, MCU_HR_GATE_BASE_N * sizeof(float));
        float logit = McuLr_HrGateLogit(gb), p = sigm(logit);
        uint8_t ready =
            rest && s->have_entry && s->front.sample_count >= s->rest_entry_sample + 1600;
        ho->valid = 1;
        ho->bpm_selected = d.selected_bpm;
        ho->bpm_tracked = d.tracked_bpm;
        ho->path_margin = d.path_margin;
        ho->path_velocity = d.path_velocity;
        ho->switched = d.switched;
        ho->tracker_state = d.tracker_state;
        ho->gate_p = p;
        ho->reportable = p >= MCU_HR_GATE_THRESHOLD;
        ho->rest_ready = ready;
        ho->formal = ready && motion && ho->reportable;
        s->prev_hr_sel = d.selected_bpm;
    }
    int nr = McuBuildRrCandidates(&s->front, rc);
    *nrr = nr;
    ro->n_candidates = nr;
    if (nr) {
        McuBranchCandidate dc[16];
        int nd = dedup_rr(rc, nr, dc);
        McuLrMapDecision d = McuLrMap_Update(&s->rr_map, dc, nd, &g_mcu_rr_lrmap_config);
        int ci = cand_index_rr(rc, nr, d.selected_bpm);
        float gf[MCU_RR_GATE_N];
        make_rr_gate(&rc[ci], &d, s->prev_rr_sel, gf);
        if (rr_gate)
            memcpy(rr_gate, gf, MCU_RR_GATE_N * sizeof(float));
        float logit = McuLr_RrGateLogit(gf), p = sigm(logit);
        uint8_t ready =
            rest && s->have_entry && s->front.sample_count >= s->rest_entry_sample + 4000;
        ro->valid = 1;
        ro->bpm_selected = d.selected_bpm;
        ro->bpm_tracked = d.tracked_bpm;
        ro->path_margin = d.path_margin;
        ro->path_velocity = d.path_velocity;
        ro->switched = d.switched;
        ro->tracker_state = d.tracker_state;
        ro->gate_p = p;
        ro->reportable = p >= MCU_RR_GATE_THRESHOLD;
        ro->rest_ready = ready;
        ro->formal = ready && motion && ro->reportable;
        s->prev_rr_sel = d.selected_bpm;
    }
}
