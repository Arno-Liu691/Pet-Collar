#include "mcu_rest_detector.h"
void McuRest_Init(McuRestState *s) {
    s->in_rest = 0;
    s->clean_count = 0;
}
McuRestDecision McuRest_Update(McuRestState *s, const McuMotionFeatures *f) {
    McuRestDecision d = {0};
    d.severe =
        (uint8_t)(f->acc_range_g >= 2.0f || f->gyro_p95_dps >= 150.0f || f->jerk_p95_gps >= 30.0f);
    d.moderate =
        (uint8_t)(f->acc_range_g >= 0.25f || f->gyro_p95_dps >= 50.0f || f->jerk_p95_gps >= 6.0f);
    d.clean =
        (uint8_t)(f->acc_range_g < 0.12f && f->gyro_p95_dps < 30.0f && f->jerk_p95_gps < 3.2f);
    if (d.severe) {
        s->in_rest = 0;
        s->clean_count = 0;
    } else if (!s->in_rest) {
        s->clean_count = d.clean ? (uint8_t)(s->clean_count + 1U) : 0U;
        if (s->clean_count >= 6U)
            s->in_rest = 1U;
    }
    d.rest = s->in_rest;
    d.publish = (uint8_t)(s->in_rest && !d.moderate && !d.severe);
    return d;
}
