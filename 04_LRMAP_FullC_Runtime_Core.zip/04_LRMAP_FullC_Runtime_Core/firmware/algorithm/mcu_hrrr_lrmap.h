#ifndef MCU_HRRR_LRMAP_H
#define MCU_HRRR_LRMAP_H
#include <stdint.h>
#define MCU_LRMAP_MAX_CAND 16U
#define MCU_HR_MIN_BPM 40.0f
#define MCU_HR_MAX_BPM 180.0f
#define MCU_RR_MIN_BRPM 6.0f
#define MCU_RR_MAX_BRPM 60.0f
#define MCU_HR_WINDOW_S 16U
#define MCU_RR_WINDOW_S 40U
#define MCU_OUTPUT_PERIOD_S 2U

typedef enum {
    MCU_TRACK_STABLE = 0,
    MCU_TRACK_CHANGING = 1,
    MCU_TRACK_REACQUIRE = 2
} McuTrackState;
typedef struct {
    float bpm;
    float utility;
    uint8_t original_index;
} McuBranchCandidate;
typedef struct {
    uint8_t valid, n;
    float bpm[MCU_LRMAP_MAX_CAND], score[MCU_LRMAP_MAX_CAND], velocity[MCU_LRMAP_MAX_CAND];
    float tracked;
    float hist[4];
    uint8_t hist_n;
} McuLrMapState;
typedef struct {
    float selected_bpm, tracked_bpm, path_margin, path_velocity;
    uint8_t switched, selected_index;
    McuTrackState tracker_state;
} McuLrMapDecision;
typedef struct {
    float obs_weight, local_span, local_penalty, quadratic_penalty, harmonic_switch_penalty,
        far_switch_penalty, jump_penalty, decay, accel_penalty, accel_cap;
    float dedup_radius, dedup_span;
    float alpha_stable, alpha_change, alpha_reacquire, change_span, max_step;
} McuLrMapConfig;
extern const McuLrMapConfig g_mcu_hr_lrmap_config;
extern const McuLrMapConfig g_mcu_rr_lrmap_config;
void McuLrMap_Reset(McuLrMapState *s);
uint8_t McuLrMap_Dedup(const McuBranchCandidate *in, uint8_t n, McuBranchCandidate *out,
                       const McuLrMapConfig *cfg);
McuLrMapDecision McuLrMap_Update(McuLrMapState *s, const McuBranchCandidate *cand, uint8_t n,
                                 const McuLrMapConfig *cfg);
#endif
