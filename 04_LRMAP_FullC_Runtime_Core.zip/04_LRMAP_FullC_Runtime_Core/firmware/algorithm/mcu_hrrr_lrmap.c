#include "mcu_hrrr_lrmap.h"
#include <math.h>
#include <string.h>
const McuLrMapConfig g_mcu_hr_lrmap_config = {1,  4, .25f, .01f, 2.5f, 3.5f, .06f, .98f, .1f,
                                              12, 1, 2,    .55f, .90f, .80f, 3,    8};
const McuLrMapConfig g_mcu_rr_lrmap_config = {1, 2.5f, .15f, .02f, 2,    2.5f, .06f, .98f, .35f,
                                              8, .75f, 1.5f, .45f, .80f, 1,    1.5f, 0};
static float ab(float x) {
    return x < 0 ? -x : x;
}
static int harm(float a, float b) {
    if (a <= 0 || b <= 0)
        return 0;
    float r = (a > b) ? a / b : b / a;
    return (r >= 1.82f && r <= 2.18f) || (r >= 2.70f && r <= 3.30f);
}
void McuLrMap_Reset(McuLrMapState *s) {
    memset(s, 0, sizeof(*s));
}
static void sort(McuBranchCandidate *a, uint8_t n) {
    for (uint8_t i = 1; i < n; i++) {
        McuBranchCandidate x = a[i];
        int j = i - 1;
        while (j >= 0 && a[j].bpm > x.bpm) {
            a[j + 1] = a[j];
            j--;
        }
        a[j + 1] = x;
    }
}
uint8_t McuLrMap_Dedup(const McuBranchCandidate *in, uint8_t n, McuBranchCandidate *out,
                       const McuLrMapConfig *c) {
    if (n > MCU_LRMAP_MAX_CAND)
        n = MCU_LRMAP_MAX_CAND;
    for (uint8_t i = 0; i < n; i++)
        out[i] = in[i];
    sort(out, n);
    uint8_t m = 0, i = 0;
    while (i < n) {
        float lo = out[i].bpm, hi = lo, center = lo;
        uint8_t best = i, j = i + 1;
        while (j < n) {
            float b = out[j].bpm;
            if (b - lo > c->dedup_span || ab(b - center) > c->dedup_radius)
                break;
            hi = b;
            center = .5f * (lo + hi);
            if (out[j].utility > out[best].utility)
                best = j;
            j++;
        }
        McuBranchCandidate keep = out[best];
        out[m++] = keep;
        i = j;
    }
    return m;
}
McuLrMapDecision McuLrMap_Update(McuLrMapState *s, const McuBranchCandidate *cand, uint8_t n,
                                 const McuLrMapConfig *c) {
    McuLrMapDecision o = {0};
    if (!n)
        return o;
    if (n > MCU_LRMAP_MAX_CAND)
        n = MCU_LRMAP_MAX_CAND;
    float obs[MCU_LRMAP_MAX_CAND], mean = 0, var = 0;
    for (uint8_t j = 0; j < n; j++)
        mean += cand[j].utility;
    mean /= n;
    for (uint8_t j = 0; j < n; j++) {
        float d = cand[j].utility - mean;
        var += d * d;
    }
    float sd = sqrtf(var / n) + 1e-6f;
    for (uint8_t j = 0; j < n; j++)
        obs[j] = (cand[j].utility - mean) / sd;
    float ns[MCU_LRMAP_MAX_CAND], nv[MCU_LRMAP_MAX_CAND];
    uint8_t parent[MCU_LRMAP_MAX_CAND];
    if (!s->valid) {
        for (uint8_t j = 0; j < n; j++) {
            ns[j] = c->obs_weight * obs[j];
            nv[j] = 0;
            parent[j] = 255;
        }
    } else
        for (uint8_t j = 0; j < n; j++) {
            float best = -1e30f;
            uint8_t bi = 0;
            float bv = 0;
            for (uint8_t i = 0; i < s->n; i++) {
                float d = cand[j].bpm - s->bpm[i], ad = ab(d), pen;
                if (ad <= c->local_span)
                    pen = c->local_penalty * ad + c->quadratic_penalty * ad * ad +
                          c->accel_penalty * fminf(ab(d - s->velocity[i]), c->accel_cap);
                else if (harm(cand[j].bpm, s->bpm[i]))
                    pen =
                        c->harmonic_switch_penalty + c->jump_penalty * fmaxf(0, ad - c->local_span);
                else
                    pen = c->far_switch_penalty + c->jump_penalty * fmaxf(0, ad - c->local_span);
                float v = c->decay * s->score[i] - pen;
                if (v > best) {
                    best = v;
                    bi = i;
                    bv = d;
                }
            }
            ns[j] = c->obs_weight * obs[j] + best;
            parent[j] = bi;
            nv[j] = bv;
        }
    float mx = ns[0];
    uint8_t win = 0;
    for (uint8_t j = 1; j < n; j++)
        if (ns[j] > mx) {
            mx = ns[j];
            win = j;
        }
    for (uint8_t j = 0; j < n; j++)
        ns[j] -= mx;
    float second = -1e30f;
    for (uint8_t j = 0; j < n; j++)
        if (j != win && ns[j] > second)
            second = ns[j];
    o.path_margin = (n > 1) ? -second : 9;
    o.selected_bpm = cand[win].bpm;
    o.path_velocity = nv[win];
    o.selected_index = cand[win].original_index;
    o.switched = (uint8_t)(s->valid && ab(cand[win].bpm - s->bpm[parent[win]]) > c->local_span);
    for (uint8_t j = 0; j < n; j++) {
        s->bpm[j] = cand[j].bpm;
        s->score[j] = ns[j];
        s->velocity[j] = nv[j];
    }
    s->n = n;
    s->valid = 1;
    if (s->tracked == 0) {
        s->tracked = o.selected_bpm;
        o.tracker_state = MCU_TRACK_REACQUIRE;
    } else {
        if (s->hist_n < 4)
            s->hist[s->hist_n++] = o.selected_bpm;
        else {
            for (uint8_t k = 0; k < 3; k++)
                s->hist[k] = s->hist[k + 1];
            s->hist[3] = o.selected_bpm;
        }
        uint8_t changing = 0;
        if (s->hist_n >= 3) {
            int up = 0, dn = 0;
            for (uint8_t k = 1; k < s->hist_n; k++) {
                float d = s->hist[k] - s->hist[k - 1];
                if (d > 0)
                    up++;
                else if (d < 0)
                    dn++;
            }
            changing = (uint8_t)(((up >= 2) || (dn >= 2)) &&
                                 ab(s->hist[s->hist_n - 1] - s->hist[0]) >= c->change_span);
        }
        float a = o.switched ? c->alpha_reacquire : (changing ? c->alpha_change : c->alpha_stable);
        float d = o.selected_bpm - s->tracked;
        if (c->max_step > 0) {
            if (d > c->max_step)
                d = c->max_step;
            if (d < -c->max_step)
                d = -c->max_step;
        }
        s->tracked += a * d;
        o.tracker_state =
            o.switched ? MCU_TRACK_REACQUIRE : (changing ? MCU_TRACK_CHANGING : MCU_TRACK_STABLE);
    }
    o.tracked_bpm = s->tracked;
    return o;
}
