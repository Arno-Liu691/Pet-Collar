#ifndef MCU_SIGNAL_PRIMITIVES_H
#define MCU_SIGNAL_PRIMITIVES_H
#include <stdint.h>

typedef struct {
    float adjacent_corr;
    float skip_corr;
    uint16_t cycle_count;
} McuFoldQuality;
float McuSignal_GoertzelPower(const float *x, uint16_t n, float fs, float freq_hz);
float McuSignal_Autocorrelation(const float *x, uint16_t n, uint16_t lag);
McuFoldQuality McuSignal_FoldQuality(const float *x, uint16_t n, float fs, float bpm);
void McuSignal_Pca3PowerIteration(const float *xyz, uint16_t n, float out_vec3[3]);
float McuSignal_PositiveZeroCrossRate(const float *x, uint16_t n, float fs, float min_bpm,
                                      float max_bpm);
#endif
