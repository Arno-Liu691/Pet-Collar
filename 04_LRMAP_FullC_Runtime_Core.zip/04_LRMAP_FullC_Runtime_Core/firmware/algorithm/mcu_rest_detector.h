#ifndef MCU_REST_DETECTOR_H
#define MCU_REST_DETECTOR_H
#include <stdint.h>
typedef struct {
    uint8_t in_rest;
    uint8_t clean_count;
} McuRestState;
typedef struct {
    float acc_range_g, gyro_p95_dps, jerk_p95_gps;
} McuMotionFeatures;
typedef struct {
    uint8_t rest;
    uint8_t publish;
    uint8_t severe;
    uint8_t moderate;
    uint8_t clean;
} McuRestDecision;
void McuRest_Init(McuRestState *s);
McuRestDecision McuRest_Update(McuRestState *s, const McuMotionFeatures *f);
#endif
