#include "mcu_signal_primitives.h"
#include <math.h>
#include <stddef.h>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
static float clampf_(float x, float a, float b) {
    return x < a ? a : (x > b ? b : x);
}
float McuSignal_GoertzelPower(const float *x, uint16_t n, float fs, float f) {
    float mean = 0.0f, q0 = 0.0f, q1 = 0.0f, q2 = 0.0f;
    uint16_t i;
    float w, c;
    if (!x || n < 2 || fs <= 0.0f)
        return 0.0f;
    for (i = 0; i < n; i++)
        mean += x[i];
    mean /= (float)n;
    w = 2.0f * (float)M_PI * f / fs;
    c = 2.0f * cosf(w);
    for (i = 0; i < n; i++) {
        q0 = c * q1 - q2 + (x[i] - mean);
        q2 = q1;
        q1 = q0;
    }
    q0 = q1 * q1 + q2 * q2 - c * q1 * q2;
    return q0 / ((float)n * (float)n + 1e-12f);
}
float McuSignal_Autocorrelation(const float *x, uint16_t n, uint16_t lag) {
    uint16_t i, m;
    if (!x || lag < 1 || lag >= n)
        return 0.0f;
    m = n - lag;
    float sx = 0, sy = 0, sx2 = 0, sy2 = 0, sxy = 0;
    for (i = 0; i < m; i++) {
        float a = x[i], b = x[i + lag];
        sx += a;
        sy += b;
        sx2 += a * a;
        sy2 += b * b;
        sxy += a * b;
    }
    float fm = (float)m, cov = sxy - sx * sy / fm, ex = sx2 - sx * sx / fm, ey = sy2 - sy * sy / fm,
          den = sqrtf(fmaxf(ex * ey, 0.0f));
    if (den < 1e-12f)
        return 0.0f;
    return clampf_(cov / den, -1.0f, 1.0f);
}
McuFoldQuality McuSignal_FoldQuality(const float *x, uint16_t n, float fs, float bpm) {
    McuFoldQuality o = {-1.0f, 0.0f, 0};
    if (!x || bpm <= 0.0f)
        return o;
    uint16_t L = (uint16_t)lroundf(fs * 60.0f / bpm);
    if (L < 5)
        return o;
    uint16_t nc = n / L;
    if (nc < 3)
        return o;
    /* Memory-light approximation: use per-cycle normalized sample correlation without storing
     * cycles. */
    float adj_sum = 0, skip_sum = 0;
    uint16_t adj_n = 0, skip_n = 0, c, k;
    uint16_t start = n - nc * L;
    for (c = 0; c + 1 < nc; c++) {
        float ma = 0, mb = 0;
        for (k = 0; k < L; k++) {
            ma += x[start + c * L + k];
            mb += x[start + (c + 1) * L + k];
        }
        ma /= L;
        mb /= L;
        float ab = 0, aa = 0, bb = 0;
        for (k = 0; k < L; k++) {
            float a = x[start + c * L + k] - ma, b = x[start + (c + 1) * L + k] - mb;
            ab += a * b;
            aa += a * a;
            bb += b * b;
        }
        float d = sqrtf(aa * bb);
        if (d > 1e-12f) {
            adj_sum += ab / d;
            adj_n++;
        }
    }
    for (c = 0; c + 2 < nc; c++) {
        float ma = 0, mb = 0;
        for (k = 0; k < L; k++) {
            ma += x[start + c * L + k];
            mb += x[start + (c + 2) * L + k];
        }
        ma /= L;
        mb /= L;
        float ab = 0, aa = 0, bb = 0;
        for (k = 0; k < L; k++) {
            float a = x[start + c * L + k] - ma, b = x[start + (c + 2) * L + k] - mb;
            ab += a * b;
            aa += a * a;
            bb += b * b;
        }
        float d = sqrtf(aa * bb);
        if (d > 1e-12f) {
            skip_sum += ab / d;
            skip_n++;
        }
    }
    o.adjacent_corr = adj_n ? adj_sum / adj_n : -1.0f;
    o.skip_corr = skip_n ? skip_sum / skip_n : 0.0f;
    o.cycle_count = nc;
    return o;
}
void McuSignal_Pca3PowerIteration(const float *xyz, uint16_t n, float v[3]) {
    uint16_t i, it;
    float m[3] = {0}, C[3][3] = {{0}};
    if (!xyz || !v || n < 2) {
        if (v) {
            v[0] = 1;
            v[1] = v[2] = 0;
        }
        return;
    }
    for (i = 0; i < n; i++) {
        m[0] += xyz[3 * i];
        m[1] += xyz[3 * i + 1];
        m[2] += xyz[3 * i + 2];
    }
    for (i = 0; i < 3; i++)
        m[i] /= n;
    for (i = 0; i < n; i++) {
        float a[3] = {xyz[3 * i] - m[0], xyz[3 * i + 1] - m[1], xyz[3 * i + 2] - m[2]};
        int r, c;
        for (r = 0; r < 3; r++)
            for (c = 0; c < 3; c++)
                C[r][c] += a[r] * a[c];
    }
    v[0] = v[1] = v[2] = 0.577350269f;
    for (it = 0; it < 5; it++) {
        float q[3];
        q[0] = C[0][0] * v[0] + C[0][1] * v[1] + C[0][2] * v[2];
        q[1] = C[1][0] * v[0] + C[1][1] * v[1] + C[1][2] * v[2];
        q[2] = C[2][0] * v[0] + C[2][1] * v[1] + C[2][2] * v[2];
        float d = sqrtf(q[0] * q[0] + q[1] * q[1] + q[2] * q[2]) + 1e-12f;
        v[0] = q[0] / d;
        v[1] = q[1] / d;
        v[2] = q[2] / d;
    }
}
float McuSignal_PositiveZeroCrossRate(const float *x, uint16_t n, float fs, float min_bpm,
                                      float max_bpm) {
    uint16_t i, last = 0, cnt = 0;
    float intervals = 0.0f;
    uint8_t have = 0;
    if (!x || n < 3)
        return 0.0f;
    float min_dt = 60.0f / max_bpm * 0.65f, max_dt = 60.0f / min_bpm * 1.35f;
    for (i = 1; i < n; i++)
        if (x[i - 1] < 0.0f && x[i] >= 0.0f) {
            if (have) {
                float dt = (i - last) / fs;
                if (dt >= min_dt && dt <= max_dt) {
                    intervals += dt;
                    cnt++;
                }
            }
            last = i;
            have = 1;
        }
    return cnt ? 60.0f / (intervals / (float)cnt) : 0.0f;
}
