# 04_LRMAP_FullC_Runtime_Core — Frozen Evaluation Summary

The stored `results/reference/all_results_summary.csv` is the numerical source of truth for the packaged frozen replay.

Development recordings satisfy the defined formal-output correctness requirement with per-recording coverage above the 70% minimum.

Human02 is the stable holdout regression check and retains high HR/RR formal correctness.

D046 remains the principal canine holdout limitation: valid high-RR candidates are present, but temporal/evidence arbitration does not consistently select the accepted RR branch. This indicates a remaining generalisation limitation in harmonic branch selection rather than simple candidate absence.

Challenge D016/D029 recordings are diagnostic stress cases and should be interpreted for branch switching, ambiguity, output suppression, and failure behaviour rather than combined into a single headline accuracy metric.
