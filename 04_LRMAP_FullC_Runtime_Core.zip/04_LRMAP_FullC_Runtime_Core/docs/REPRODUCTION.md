# 04_LRMAP_FullC_Runtime_Core — Reproduction

## Frozen inference

Run:

```bash
python scripts/check_dataset.py
python scripts/reproduce_all_c.py
```

`reproduce_all_c.py` compiles the host replay executable and runs the frozen Full-C runtime from raw normalized six-axis IMU samples. References are joined only after inference for evaluation.

## Figure regeneration

```bash
python scripts/plot_results.py
```

This redraws figures from stored output tables without rerunning inference.

## Model-development utilities

The scripts under `training/` implement Development-only training procedures using frozen feature definitions. They create a new model if executed and are not part of frozen-result reproduction. A newly trained model must be exported, re-evaluated on Development, frozen, and only then evaluated on Holdout/Challenge.
