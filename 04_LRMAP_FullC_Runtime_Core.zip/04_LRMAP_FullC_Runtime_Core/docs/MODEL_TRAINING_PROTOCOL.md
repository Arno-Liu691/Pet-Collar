# LRMAP model training protocol

## Candidate representation

Each HR candidate is represented by a fixed 105-dimensional rate-free physical-evidence vector. Each RR candidate is represented by a fixed 86-dimensional rate-free physical-evidence vector. Absolute candidate rate, species identity, recording identity, and reference distance are excluded from the learned feature vectors.

## Pairwise candidate training

For each eligible Development window, candidates inside the accepted reference/tolerance interval are positive candidates. Up to two representative positives are retained. Hard negatives prioritise harmonic competitors and nearby strong incorrect branches.

For a correct candidate c+ and competitor c-, training examples are constructed as:

`Delta x = x(c+) - x(c-) -> 1`

and the reverse difference is added as class 0.

Features are standardised and an L2-regularised Logistic Regression model is fitted with `C=0.03`.

Runtime candidate utility is:

`U(c) = w^T x(c) + b`

The utility is a relative local evidence score, not a calibrated physiological probability.

## Domain and sample weighting

HR domain weights: canine 0.60 / human 0.40.
RR domain weights: canine 0.75 / human 0.25.

Each domain weight is divided across recordings, then across windows, then across pairs. This prevents overlapping windows in longer recordings from dominating the learned coefficients.

## Reportability gate

The gate is trained separately from candidate selection. Its Development target is whether the tracked estimate lies within the accepted reference/tolerance range. The final gate uses interaction-only degree-2 features with sparse L1 Logistic Regression.

Final HR gate: C=10.0, threshold=0.33, 165 non-zero terms.
Final RR gate: C=1.0, threshold=0.4475, 114 non-zero terms.

Gate output is interpreted as a reportability/reliability score, not a calibrated probability of physiological correctness.
