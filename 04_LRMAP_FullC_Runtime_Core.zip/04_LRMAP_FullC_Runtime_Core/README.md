# 04_LRMAP_FullC_Runtime_Core

This repository contains the frozen Full-C implementation of LRMAP (Logistic-Regression-assisted MAP) used for offline host replay and deployment-oriented verification of the final HR/RR algorithm.

## Scope

The repository preserves the algorithmic path from normalized six-axis IMU input to formal HR/RR output:

`raw IMU -> causal preprocessing -> multi-physical candidate generation -> HR 105-D / RR 86-D rate-free evidence -> frozen candidate Logistic Regression -> causal MAP/DP branch selection -> adaptive tracking -> reportability gate -> formal output`

The package is intended as the report appendix for the final adopted LRMAP method. It does not include discarded implementation branches or development-history documents.

## Repository structure

- `dataset/` — normalized Development, Holdout, and Challenge recordings with frozen references.
- `firmware/` — Full-C runtime core, generated frozen model parameters, and host-build tests.
- `models/frozen/` — frozen candidate-LR and reportability-gate model files.
- `host_replay/` — host executable wrapper for running the same C algorithm core on recorded data.
- `scripts/` — dataset checking, full C reproduction, and figure generation.
- `training/` — Development-only training protocol utilities; these are not used during frozen inference.
- `results/reference/` — stored reference replay outputs, metrics, feature tables, and figures.
- `docs/` — frozen feature orders, reproduction instructions, and final validation summary.
- `FROZEN_CONFIG.json` — frozen algorithm configuration.

## Reproduce the frozen Full-C results

Install Python dependencies and ensure a C compiler is available:

```bash
pip install -r requirements.txt
python scripts/check_dataset.py
python scripts/reproduce_all_c.py
```

The reproduction script compiles `host_replay/replay_bin.c`, feeds normalized recorded IMU samples to the Full-C core, and attaches references only after inference.

## Frozen model semantics

The HR and RR candidate models are pairwise L2-regularised Logistic Regression models trained offline on Development recordings. The learned coefficients were frozen before final evaluation and are used as constant parameters during runtime inference.

The reportability gates are separate supervised Logistic Regression models. They decide whether a tracked result is suitable for formal publication; they do not modify the selected HR/RR value.

No online model fitting occurs in the Full-C runtime.

## Data protocol

Development:
- Canine: D027, D045, D057, D030
- Human: Human01, Human03, Human04

Holdout:
- D046
- Human02

Challenge:
- D016 and D029 segments

Domain weighting during candidate-model development:
- HR: canine 0.60 / human 0.40
- RR: canine 0.75 / human 0.25

Weights are balanced hierarchically by domain, recording, window, and pair so that long recordings with more overlapping windows do not dominate training.

## Important interpretation

LRMAP is not an end-to-end HR/RR regressor. Signal-processing stages first generate plausible physiological and harmonic candidates. Fixed rate-free physical-evidence vectors describe each candidate, Logistic Regression learns relative candidate preference, and causal MAP/DP resolves temporal branch identity. Tracking and reportability are separate downstream responsibilities.

Development-set formal correctness is a model-selection result. Holdout and Challenge results should be interpreted separately when assessing generalisation.
