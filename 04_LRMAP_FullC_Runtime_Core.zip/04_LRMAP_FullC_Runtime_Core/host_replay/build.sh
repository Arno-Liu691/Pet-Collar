#!/bin/sh
set -eu
cc -std=c11 -O3 -ffast-math -I../firmware/full_pipeline -I../firmware/algorithm -I../firmware/generated \
 replay_bin.c ../firmware/full_pipeline/mcu_dsp_core.c ../firmware/full_pipeline/mcu_filters.c ../firmware/full_pipeline/mcu_hrrr_frontend.c ../firmware/full_pipeline/mcu_hrrr_full.c \
 ../firmware/algorithm/mcu_hrrr_lrmap.c ../firmware/algorithm/mcu_rest_detector.c ../firmware/generated/mcu_lr_models.c -lm -o replay_bin
