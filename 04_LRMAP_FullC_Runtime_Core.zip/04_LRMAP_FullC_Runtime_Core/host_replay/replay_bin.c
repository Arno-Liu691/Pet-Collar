#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include "../firmware/full_pipeline/mcu_hrrr_full.h"
static McuHrrrFullState st;
static void path(char *out, const char *d, const char *f) {
    sprintf(out, "%s/%s", d, f);
}
int main(int argc, char **argv) {
    if (argc < 3) {
        fprintf(stderr, "usage: %s raw6_float32.bin outdir\n", argv[0]);
        return 2;
    }
    mkdir(argv[2], 0777);
    FILE *fi = fopen(argv[1], "rb");
    if (!fi) {
        perror("raw");
        return 2;
    }
    char p[1024];
    path(p, argv[2], "hr_features.csv");
    FILE *hf = fopen(p, "w");
    path(p, argv[2], "rr_features.csv");
    FILE *rf = fopen(p, "w");
    path(p, argv[2], "hr_output.csv");
    FILE *ho = fopen(p, "w");
    path(p, argv[2], "rr_output.csv");
    FILE *ro = fopen(p, "w");
    path(p, argv[2], "hr_gate_features.csv");
    FILE *hgfout = fopen(p, "w");
    path(p, argv[2], "rr_gate_features.csv");
    FILE *rgfout = fopen(p, "w");
    fprintf(hf, "t,bpm");
    for (int i = 0; i < 105; i++)
        fprintf(hf, ",f%d", i);
    fprintf(hf, ",utility\n");
    fprintf(rf, "t,bpm");
    for (int i = 0; i < 86; i++)
        fprintf(rf, ",f%d", i);
    fprintf(rf, ",utility\n");
    fprintf(ho, "t,valid,selected,tracked,gate_p,reportable,rest_ready,motion_ok,formal,path_"
                "margin,path_velocity,switched,tracker_state,n_candidates\n");
    fprintf(ro, "t,valid,selected,tracked,gate_p,reportable,rest_ready,motion_ok,formal,path_"
                "margin,path_velocity,switched,tracker_state,n_candidates\n");
    fprintf(hgfout, "t");
    for (int i = 0; i < MCU_HR_GATE_BASE_N; i++)
        fprintf(hgfout, ",g%d", i);
    fprintf(hgfout, "\n");
    fprintf(rgfout, "t");
    for (int i = 0; i < 102; i++)
        fprintf(rgfout, ",g%d", i);
    fprintf(rgfout, "\n");
    McuHrrrFull_Init(&st);
    float x[6];
    while (fread(x, sizeof(float), 6, fi) == 6) {
        McuHrrrFull_PushSample(&st, x);
        if (st.front.sample_count % 200 == 0) {
            McuHrrrVitalOutput h, r;
            McuHrFeatCandidate hc[16];
            McuRrFeatCandidate rc[16];
            uint8_t nh = 0, nr = 0;
            float hgf[MCU_HR_GATE_BASE_N] = {0}, rgf[102] = {0};
            McuHrrrFull_ComputeTick(&st, &h, &r, hc, &nh, rc, &nr, hgf, rgf);
            float t = st.front.sample_count / 100.f;
            for (int j = 0; j < nh; j++) {
                fprintf(hf, "%.6f,%.9g", t, hc[j].bpm);
                for (int k = 0; k < 105; k++)
                    fprintf(hf, ",%.9g", hc[j].feat[k]);
                fprintf(hf, ",%.9g\n", hc[j].utility);
            }
            for (int j = 0; j < nr; j++) {
                fprintf(rf, "%.6f,%.9g", t, rc[j].bpm);
                for (int k = 0; k < 86; k++)
                    fprintf(rf, ",%.9g", rc[j].feat[k]);
                fprintf(rf, ",%.9g\n", rc[j].utility);
            }
            fprintf(ho, "%.6f,%d,%.9g,%.9g,%.9g,%d,%d,%d,%d,%.9g,%.9g,%d,%d,%d\n", t, h.valid,
                    h.bpm_selected, h.bpm_tracked, h.gate_p, h.reportable, h.rest_ready,
                    h.motion_ok, h.formal, h.path_margin, h.path_velocity, h.switched,
                    h.tracker_state, h.n_candidates);
            fprintf(ro, "%.6f,%d,%.9g,%.9g,%.9g,%d,%d,%d,%d,%.9g,%.9g,%d,%d,%d\n", t, r.valid,
                    r.bpm_selected, r.bpm_tracked, r.gate_p, r.reportable, r.rest_ready,
                    r.motion_ok, r.formal, r.path_margin, r.path_velocity, r.switched,
                    r.tracker_state, r.n_candidates);
            if (h.valid) {
                fprintf(hgfout, "%.6f", t);
                for (int k = 0; k < MCU_HR_GATE_BASE_N; k++)
                    fprintf(hgfout, ",%.9g", hgf[k]);
                fprintf(hgfout, "\n");
            }
            if (r.valid) {
                fprintf(rgfout, "%.6f", t);
                for (int k = 0; k < 102; k++)
                    fprintf(rgfout, ",%.9g", rgf[k]);
                fprintf(rgfout, "\n");
            }
        }
    }
    fclose(fi);
    fclose(hf);
    fclose(rf);
    fclose(ho);
    fclose(ro);
    fclose(hgfout);
    fclose(rgfout);
    return 0;
}
