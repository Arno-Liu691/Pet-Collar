#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np, pandas as pd
from sklearn.preprocessing import StandardScaler, PolynomialFeatures
from sklearn.linear_model import LogisticRegression

ROOT = Path(__file__).resolve().parents[1]
DEV_DOG = [
    "D027_T2_S0079288_E0088525",
    "D045_T2_S0117696_E0129865",
    "D057_T1_S0053821_E0072336",
    "D030_T2_S0135049_E0142493",
]
DEV_HUM = [
    "human_test_01_stable_vali",
    "human_test_03_RR_change_ref",
    "human_test_04_disruption_ref",
]


def nearest(ref, t):
    rt = ref.time_s.to_numpy(float)
    return ref.iloc[int(np.argmin(np.abs(rt - float(t))))]


def load(vital, ds, rs):
    rows = []
    recs = DEV_DOG + DEV_HUM
    manifest = pd.read_csv(ds / "SPLIT_MANIFEST.csv")
    for rec in recs:
        mr = next(r for _, r in manifest.iterrows() if str(r.segment_id) == rec)
        split = str(mr["split"])
        o = pd.read_csv(rs / split / rec / f"{vital}_output.csv")
        g = pd.read_csv(rs / split / rec / f"{vital}_gate_features.csv")
        ref = pd.read_csv(ds / split / rec / "reference" / f"{vital}_reference.csv")
        gc = [c for c in g if c != "t"]
        names = [f"g{i}" for i in range(len(gc))]
        g = g.rename(columns={a: b for a, b in zip(gc, names)})
        d = o.merge(g, on="t", how="inner")
        r = [nearest(ref, t) for t in d.t]
        d["reference"] = [float(x.estimate) for x in r]
        d["lo"] = [float(x.range_low) for x in r]
        d["hi"] = [float(x.range_high) for x in r]
        d["reference_valid"] = [bool(x.output_valid) for x in r]
        tracked = "tracked" if "tracked" in d else "tracked_bpm"
        d["hit"] = d[tracked].between(d.lo, d.hi) & d.reference_valid
        d["rec"] = rec
        d["domain"] = "dog" if rec in DEV_DOG else "human"
        rows.append(d)
    return pd.concat(rows, ignore_index=True), names


def sample_weights(D, vital):
    elig = D.rest_ready.astype(bool).to_numpy() & D.reference_valid.astype(bool).to_numpy()
    w = np.zeros(len(D))
    dw = {"dog": 0.60 if vital == "hr" else 0.75, "human": 0.40 if vital == "hr" else 0.25}
    for dom, recs in [("dog", DEV_DOG), ("human", DEV_HUM)]:
        for rec in recs:
            ix = np.where(elig & (D.rec.to_numpy() == rec))[0]
            if len(ix):
                w[ix] = dw[dom] / len(recs) / len(ix)
    return elig, w, dw


def table(D, p, th):
    out = []
    for rec in DEV_DOG + DEV_HUM:
        m = D.rec.to_numpy() == rec
        den = m & D.rest_ready.astype(bool).to_numpy() & D.reference_valid.astype(bool).to_numpy()
        formal = den & D.motion_ok.astype(bool).to_numpy() & (p >= th)
        hit = D.hit.to_numpy(bool)
        out.append(
            {
                "record": rec,
                "coverage": formal.sum() / max(1, den.sum()),
                "wrong_n": int(np.sum(formal & ~hit)),
                "correct_fraction": float(hit[formal].mean()) if formal.any() else 0.0,
            }
        )
    return pd.DataFrame(out)


def choose(D, p):
    best = None
    for th in np.linspace(0.02, 0.98, 385):
        q = table(D, p, float(th))
        if q.coverage.min() < 0.70 - 1e-12:
            continue
        wrong = int(q.wrong_n.sum())
        score = (
            (1e9 if wrong == 0 else 0)
            + 1e5 * q.correct_fraction.min()
            + 100 * q.coverage.min()
            + q.coverage.mean()
        )
        if best is None or score > best[0]:
            best = (score, float(th), q)
    return best


def train(vital, ds, rs, out_path):
    D, names = load(vital, ds, rs)
    elig, w, dw = sample_weights(D, vital)
    ix = np.where(elig)[0]
    X0 = D[names].replace([np.inf, -np.inf], 0).fillna(0).to_numpy(float)
    y = D.hit.astype(int).to_numpy()
    poly = PolynomialFeatures(degree=2, interaction_only=True, include_bias=False)
    XP = poly.fit_transform(X0)
    PN = list(poly.get_feature_names_out(names))
    best = None
    for C in [0.01, 0.03, 0.1, 0.3, 1, 3, 10]:
        sc = StandardScaler()
        Z = sc.fit_transform(XP[ix])
        m = LogisticRegression(C=C, max_iter=30000, solver="liblinear", penalty="l1")
        m.fit(Z, y[ix], sample_weight=w[ix] / w[ix].mean())
        p = m.predict_proba((XP - sc.mean_) / sc.scale_)[:, 1]
        ch = choose(D, p)
        nz = int(np.count_nonzero(np.abs(m.coef_[0]) > 1e-10))
        if ch:
            rank = (ch[0], -nz)
            if best is None or rank > best[0]:
                best = (rank, C, ch[1], ch[2], sc, m, nz)
    if best is None:
        raise RuntimeError("No gate reached development coverage/correctness criteria.")
    _, C, th, q, sc, m, nz = best
    inz = np.where(np.abs(m.coef_[0]) > 1e-10)[0]
    model = {
        "kind": f"{vital}_poly",
        "feature_expr": [PN[i].replace(" ", "*") for i in inz],
        "base_features": names,
        "mean": sc.mean_[inz].tolist(),
        "scale": sc.scale_[inz].tolist(),
        "coef": m.coef_[0, inz].tolist(),
        "intercept": float(m.intercept_[0]),
        "threshold": float(th),
        "C": float(C),
        "n_nonzero": int(len(inz)),
        "domain_weights": dw,
        "weighting": "domain_recording_eligible_window_balanced",
        "training_split": "development_only",
        "note": "Optional gate retraining. This writes a newly trained gate model and requires explicit model freezing before evaluation use.",
    }
    out_path.write_text(json.dumps(model, indent=2), encoding="utf-8")
    q.to_csv(out_path.with_suffix(".development_summary.csv"), index=False)
    print("wrote", out_path, "threshold", th, "nz", len(inz))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset-root", type=Path, default=ROOT / "dataset")
    ap.add_argument("--c-results-root", type=Path, default=ROOT / "results" / "reference")
    ap.add_argument("--output-model-dir", type=Path, default=ROOT / "models" / "retrained")
    ap.add_argument("--vital", choices=["hr", "rr", "both"], default="both")
    a = ap.parse_args()
    a.output_model_dir.mkdir(parents=True, exist_ok=True)
    if a.vital in ("hr", "both"):
        train("hr", a.dataset_root, a.c_results_root, a.output_model_dir / "hr_gate_lr.json")
    if a.vital in ("rr", "both"):
        train("rr", a.dataset_root, a.c_results_root, a.output_model_dir / "rr_gate_lr.json")
