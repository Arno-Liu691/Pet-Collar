# Offline LRMAP model-development utilities

The Full-C runtime uses the frozen model parameters in `models/frozen/` and `firmware/generated/`. Training is not executed during runtime inference.

## Candidate Logistic Regression

`train_candidate_lr_from_fullc_features.py` implements the Development-only pairwise candidate-ranking protocol on regenerated Full-C candidate feature tables. It preserves the domain weighting and hard-competitor construction used by the final methodology. Running it creates a new candidate model and does not replace the frozen model automatically.

## Reportability gate

`train_reportability_gates.py` trains the Development-only reportability model from selected/tracked outputs and gate features. The gate changes publication eligibility only; it does not change the selected rate.

## Model export

`export_models_to_c.py` converts JSON model parameters to C constants for the runtime.

Any newly trained model must be Development-evaluated and frozen before Holdout or Challenge evaluation.
