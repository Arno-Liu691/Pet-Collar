#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression

ROOT = Path(__file__).resolve().parents[1]
DEV_DOG = [
    "D027_T2_S0079288_E0088525",
    "D045_T2_S0117696_E0129865",
    "D057_T1_S0053821_E0072336",
    "D030_T2_S0135049_E0142493",
]
DEV_HUM = [
    "human_test_01_stable_vali",
    "human_test_03_RR_change_ref",
    "human_test_04_disruption_ref",
]


def nearest_ref(ref, t):
    rt = ref.time_s.to_numpy(float)
    i = int(np.argmin(np.abs(rt - float(t))))
    return ref.iloc[i]


def harm(a, b):
    if a <= 0 or b <= 0:
        return False
    r = max(a, b) / min(a, b)
    return (1.75 <= r <= 2.25) or (2.65 <= r <= 3.35)


def train_one(vital, dataset_root, c_results_root, out_model, C=0.03):
    recs = DEV_DOG + DEV_HUM
    nfeat = 105 if vital == "hr" else 86
    F = [f"f{i}" for i in range(nfeat)]
    X = []
    Y = []
    W = []
    dom_total = {"dog": 0.60 if vital == "hr" else 0.75, "human": 0.40 if vital == "hr" else 0.25}
    manifest = pd.read_csv(dataset_root / "SPLIT_MANIFEST.csv")
    for rec in recs:
        row = next(r for _, r in manifest.iterrows() if str(r.segment_id) == rec)
        split = str(row["split"])
        dom = "dog" if rec in DEV_DOG else "human"
        feat = pd.read_csv(c_results_root / split / rec / f"{vital}_features.csv")
        ref = pd.read_csv(dataset_root / split / rec / "reference" / f"{vital}_reference.csv")
        groups = list(feat.groupby("t"))
        rec_w = dom_total[dom] / (len(DEV_DOG) if dom == "dog" else len(DEV_HUM))
        for t, g in groups:
            rr = nearest_ref(ref, t)
            if not bool(rr.output_valid):
                continue
            inside = g.bpm.between(float(rr.range_low), float(rr.range_high))
            pos = g[inside].copy()
            neg = g[~inside].copy()
            if len(pos) == 0 or len(neg) == 0:
                continue
            pos["dref"] = (pos.bpm - float(rr.estimate)).abs()
            ps = pos.sort_values("dref").head(2)
            pb = ps.bpm.to_numpy(float)
            neg["near"] = neg.bpm.apply(lambda b: np.min(np.abs(pb - float(b))))
            neg["harm"] = neg.bpm.apply(lambda b: any(harm(float(b), float(x)) for x in pb))
            neg["hard"] = neg.harm.astype(float) * 3.0 + np.maximum(0, 20 - neg.near) / 20.0 * 2.0
            hs = neg.sort_values("hard", ascending=False).head(6)
            pairs = [(a, b) for _, a in ps.iterrows() for _, b in hs.iterrows()]
            if not pairs:
                continue
            window_w = rec_w / max(1, len(groups))
            pair_w = window_w / len(pairs)
            for a, b in pairs:
                dv = np.nan_to_num(
                    a[F].to_numpy(float) - b[F].to_numpy(float), nan=0, posinf=0, neginf=0
                )
                X.extend([dv, -dv])
                Y.extend([1, 0])
                W.extend([pair_w, pair_w])
    X = np.asarray(X, float)
    Y = np.asarray(Y, int)
    W = np.asarray(W, float)
    W /= W.mean()
    sc = StandardScaler()
    Z = sc.fit_transform(X)
    m = LogisticRegression(C=C, max_iter=10000, solver="liblinear", penalty="l2")
    m.fit(Z, Y, sample_weight=W)
    model = {
        "kind": "candidate_pairwise_lr",
        "features": F,
        "mean": sc.mean_.tolist(),
        "scale": sc.scale_.tolist(),
        "coef": m.coef_[0].tolist(),
        "intercept": float(m.intercept_[0]),
        "C": float(C),
        "domain_weights": {"dog": dom_total["dog"], "human": dom_total["human"]},
        "weighting": "domain_recording_window_pair_balanced",
        "training_split": "development_only",
        "note": "Model-development training from C-generated candidate features. This writes a newly trained model; the frozen runtime remains unchanged unless the model is explicitly re-exported and re-frozen.",
    }
    out_model.write_text(json.dumps(model, indent=2), encoding="utf-8")
    print("wrote", out_model, "pairs", len(Y), "features", nfeat)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(
        description="Optional candidate-LR retraining using Development C-generated feature tables."
    )
    ap.add_argument("--dataset-root", type=Path, default=ROOT / "dataset")
    ap.add_argument("--c-results-root", type=Path, default=ROOT / "results" / "reference")
    ap.add_argument("--output-model-dir", type=Path, default=ROOT / "models" / "retrained")
    ap.add_argument("--vital", choices=["hr", "rr", "both"], default="both")
    a = ap.parse_args()
    a.output_model_dir.mkdir(parents=True, exist_ok=True)
    if a.vital in ("hr", "both"):
        train_one(
            "hr", a.dataset_root, a.c_results_root, a.output_model_dir / "hr_candidate_lr.json"
        )
    if a.vital in ("rr", "both"):
        train_one(
            "rr", a.dataset_root, a.c_results_root, a.output_model_dir / "rr_candidate_lr.json"
        )
