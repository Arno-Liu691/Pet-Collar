#!/usr/bin/env python3
import json
from pathlib import Path
import numpy as np
import argparse

ROOT = Path(__file__).resolve().parents[1]
MD = ROOT / "models" / "frozen"
OUT = ROOT / "firmware" / "generated"


def carray(name, a):
    a = np.asarray(a, float)
    return f"const float {name}[{len(a)}] = {{\n  " + ", ".join(f"{x:.9g}f" for x in a) + "\n};\n"


def raw_linear(m):
    mean = np.asarray(m["mean"], float)
    scale = np.asarray(m["scale"], float)
    coef = np.asarray(m["coef"], float)
    w = coef / scale
    b = float(m.get("intercept", 0)) - float(np.sum(mean * w))
    return w, b


def sparse_poly(m):
    coef = np.asarray(m["coef"], float)
    mean = np.asarray(m["mean"], float)
    scale = np.asarray(m["scale"], float)
    w = coef / scale
    b = float(m.get("intercept", 0)) - float(np.sum(mean * w))
    bases = list(m.get("base_features", []))
    if not bases:
        for e in m["feature_expr"]:
            for x in e.split("*"):
                if x not in bases:
                    bases.append(x)
    bi = {x: i for i, x in enumerate(bases)}
    a = []
    bb = []
    for e in m["feature_expr"]:
        p = e.split("*")
        a.append(bi[p[0]])
        bb.append(bi[p[1]] if len(p) == 2 else -1)
    return bases, w, b, a, bb


ap = argparse.ArgumentParser()
ap.add_argument("--model-dir", type=Path, default=MD)
ap.add_argument("--output-dir", type=Path, default=OUT)
a = ap.parse_args()
MD = a.model_dir
OUT = a.output_dir
OUT.mkdir(parents=True, exist_ok=True)
mods = {
    x: json.loads((MD / f"{x}.json").read_text())
    for x in ["hr_candidate_lr", "rr_candidate_lr", "hr_gate_lr", "rr_gate_lr"]
}
hrw, hrb = raw_linear(mods["hr_candidate_lr"])
rrw, rrb = raw_linear(mods["rr_candidate_lr"])
hg = mods["hr_gate_lr"]
hbases, hgw, hgb, hta, htb = sparse_poly(hg)
rg = mods["rr_gate_lr"]
if rg.get("kind") == "linear_gate_lr":
    rg_kind = "linear"
    rgbases = list(rg["features"])
    rgw, rgb = raw_linear(rg)
    rgta = rgtb = []
elif rg.get("kind") == "rr_poly":
    rg_kind = "poly"
    rgbases, rgw, rgb, rgta, rgtb = sparse_poly(rg)
else:
    raise ValueError(rg.get("kind"))

H = """#ifndef MCU_LR_MODELS_H\n#define MCU_LR_MODELS_H\n#include <stdint.h>\n"""
H += f'#define MCU_HR_CAND_FEATURES {len(hrw)}U\n#define MCU_RR_CAND_FEATURES {len(rrw)}U\n#define MCU_RR_GATE_BASE_FEATURES {len(rgbases)}U\n#define MCU_RR_GATE_TERMS {len(rgw)}U\n#define MCU_RR_GATE_IS_POLY {1 if rg_kind=="poly" else 0}U\n#define MCU_HR_GATE_BASE_FEATURES {len(hbases)}U\n#define MCU_HR_GATE_TERMS {len(hgw)}U\n'
H += "extern const float g_hr_cand_w[MCU_HR_CAND_FEATURES]; extern const float g_hr_cand_bias;\nextern const float g_rr_cand_w[MCU_RR_CAND_FEATURES]; extern const float g_rr_cand_bias;\n"
H += "extern const float g_rr_gate_term_w[MCU_RR_GATE_TERMS]; extern const int16_t g_rr_gate_term_a[MCU_RR_GATE_TERMS]; extern const int16_t g_rr_gate_term_b[MCU_RR_GATE_TERMS]; extern const float g_rr_gate_bias;\n"
H += "extern const float g_hr_gate_term_w[MCU_HR_GATE_TERMS]; extern const int16_t g_hr_gate_term_a[MCU_HR_GATE_TERMS]; extern const int16_t g_hr_gate_term_b[MCU_HR_GATE_TERMS]; extern const float g_hr_gate_bias;\n"
H += f'#define MCU_HR_GATE_THRESHOLD {float(hg["threshold"]):.9g}f\n#define MCU_RR_GATE_THRESHOLD {float(rg["threshold"]):.9g}f\n'
H += "float McuLr_Dot(const float *x,const float *w,uint16_t n,float bias);\nfloat McuLr_HrCandidateUtility(const float *x);\nfloat McuLr_RrCandidateUtility(const float *x);\nfloat McuLr_HrGateLogit(const float *base);\nfloat McuLr_RrGateLogit(const float *base);\nuint8_t McuLr_HrReportable(const float *base);\nuint8_t McuLr_RrReportable(const float *base);\n#endif\n"
(OUT / "mcu_lr_models.h").write_text(H)
C = '#include "mcu_lr_models.h"\n#include <math.h>\n'
C += carray("g_hr_cand_w", hrw) + f"const float g_hr_cand_bias={hrb:.9g}f;\n"
C += carray("g_rr_cand_w", rrw) + f"const float g_rr_cand_bias={rrb:.9g}f;\n"
# RR gate as generic sparse terms. For linear gate, a=i,b=-1. For poly use expressions.
if rg_kind == "linear":
    rgta = list(range(len(rgw)))
    rgtb = [-1] * len(rgw)
C += carray("g_rr_gate_term_w", rgw) + f"const float g_rr_gate_bias={rgb:.9g}f;\n"
C += f"const int16_t g_rr_gate_term_a[{len(rgta)}]={{" + ",".join(map(str, rgta)) + "};\n"
C += f"const int16_t g_rr_gate_term_b[{len(rgtb)}]={{" + ",".join(map(str, rgtb)) + "};\n"
C += carray("g_hr_gate_term_w", hgw) + f"const float g_hr_gate_bias={hgb:.9g}f;\n"
C += f"const int16_t g_hr_gate_term_a[{len(hta)}]={{" + ",".join(map(str, hta)) + "};\n"
C += f"const int16_t g_hr_gate_term_b[{len(htb)}]={{" + ",".join(map(str, htb)) + "};\n"
C += """float McuLr_Dot(const float *x,const float *w,uint16_t n,float bias){float s=bias;for(uint16_t i=0;i<n;i++)s+=x[i]*w[i];return s;}\nfloat McuLr_HrCandidateUtility(const float *x){return McuLr_Dot(x,g_hr_cand_w,MCU_HR_CAND_FEATURES,g_hr_cand_bias);}\nfloat McuLr_RrCandidateUtility(const float *x){return McuLr_Dot(x,g_rr_cand_w,MCU_RR_CAND_FEATURES,g_rr_cand_bias);}\nfloat McuLr_RrGateLogit(const float *base){float s=g_rr_gate_bias;for(uint16_t i=0;i<MCU_RR_GATE_TERMS;i++){float v=base[g_rr_gate_term_a[i]];if(g_rr_gate_term_b[i]>=0)v*=base[g_rr_gate_term_b[i]];s+=v*g_rr_gate_term_w[i];}return s;}\nfloat McuLr_HrGateLogit(const float *base){float s=g_hr_gate_bias;for(uint16_t i=0;i<MCU_HR_GATE_TERMS;i++){float v=base[g_hr_gate_term_a[i]];if(g_hr_gate_term_b[i]>=0)v*=base[g_hr_gate_term_b[i]];s+=v*g_hr_gate_term_w[i];}return s;}\nstatic uint8_t report(float logit,float p){float th=logf(p/(1.0f-p));return (uint8_t)(logit>=th);}\nuint8_t McuLr_HrReportable(const float *x){return report(McuLr_HrGateLogit(x),MCU_HR_GATE_THRESHOLD);}\nuint8_t McuLr_RrReportable(const float *x){return report(McuLr_RrGateLogit(x),MCU_RR_GATE_THRESHOLD);}\n"""
(OUT / "mcu_lr_models.c").write_text(C)
(ROOT / "docs" / "HR_CANDIDATE_FEATURE_ORDER.txt").write_text(
    "\n".join(f"{i},{n}" for i, n in enumerate(mods["hr_candidate_lr"]["features"]))
)
(ROOT / "docs" / "RR_CANDIDATE_FEATURE_ORDER.txt").write_text(
    "\n".join(f"{i},{n}" for i, n in enumerate(mods["rr_candidate_lr"]["features"]))
)
(ROOT / "docs" / "RR_GATE_FEATURE_ORDER.txt").write_text(
    "\n".join(f"{i},{n}" for i, n in enumerate(rgbases))
)
(ROOT / "docs" / "HR_GATE_BASE_FEATURE_ORDER.txt").write_text(
    "\n".join(f"{i},{n}" for i, n in enumerate(hbases))
)
print(
    "generated",
    len(hrw),
    len(rrw),
    "RR gate",
    rg_kind,
    len(rgbases),
    len(rgw),
    "HR gate",
    len(hbases),
    len(hgw),
)
