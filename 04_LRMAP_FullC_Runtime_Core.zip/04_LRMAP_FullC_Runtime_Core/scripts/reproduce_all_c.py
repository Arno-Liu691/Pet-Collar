#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, shutil, subprocess, sys, tempfile
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DATASET = ROOT / "dataset"
DEFAULT_OUTPUT = ROOT / "results" / "reproduced"
HOST_DIR = ROOT / "host_replay"
BIN = HOST_DIR / "replay_bin"


def build_host_replay():
    subprocess.run(["sh", "build.sh"], cwd=HOST_DIR, check=True)


def nearest_reference(ref: pd.DataFrame, t: np.ndarray) -> pd.DataFrame:
    rt = ref["time_s"].to_numpy(float)
    idx = np.searchsorted(rt, t, side="left")
    idx = np.clip(idx, 0, len(rt) - 1)
    left = np.maximum(idx - 1, 0)
    choose_left = np.abs(rt[left] - t) <= np.abs(rt[idx] - t)
    idx = np.where(choose_left, left, idx)
    return ref.iloc[idx].reset_index(drop=True)


def attach_reference(out_df: pd.DataFrame, ref_df: pd.DataFrame) -> pd.DataFrame:
    d = out_df.copy()
    ref = nearest_reference(ref_df, d["t"].to_numpy(float))
    d["reference"] = ref["estimate"].to_numpy(float)
    d["range_low"] = ref["range_low"].to_numpy(float)
    d["range_high"] = ref["range_high"].to_numpy(float)
    d["reference_valid"] = ref["output_valid"].astype(bool).to_numpy()
    tracked_col = "tracked" if "tracked" in d.columns else "tracked_bpm"
    d["correct"] = d["reference_valid"] & d[tracked_col].between(d["range_low"], d["range_high"])
    return d


def metrics(d: pd.DataFrame) -> dict:
    tracked_col = "tracked" if "tracked" in d.columns else "tracked_bpm"
    den = d["rest_ready"].astype(bool) & d["reference_valid"].astype(bool)
    formal = den & d["motion_ok"].astype(bool) & d["formal"].astype(bool)
    return {
        "coverage": float(formal.sum() / max(1, den.sum())),
        "correct_fraction": float(d.loc[formal, "correct"].mean()) if formal.any() else 0.0,
        "formal_n": int(formal.sum()),
        "eligible_n": int(den.sum()),
        "mae": (
            float(np.abs(d.loc[formal, tracked_col] - d.loc[formal, "reference"]).mean())
            if formal.any()
            else None
        ),
        "median_output": float(d.loc[formal, tracked_col].median()) if formal.any() else None,
    }


def csv_to_raw_bin(csv_path: Path, bin_path: Path):
    df = pd.read_csv(csv_path)
    cols = ["acc_x_g", "acc_y_g", "acc_z_g", "gyro_x_dps", "gyro_y_dps", "gyro_z_dps"]
    arr = df[cols].to_numpy(np.float32, copy=True)
    arr.tofile(bin_path)


def run_segment(dataset_root: Path, split: str, segment: str, out_dir: Path):
    seg = dataset_root / split / segment
    out_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        raw_bin = Path(td) / "raw6_float32.bin"
        csv_to_raw_bin(seg / "input" / "raw_imu.csv", raw_bin)
        subprocess.run([str(BIN), str(raw_bin), str(out_dir)], check=True)
    result = {}
    for vital in ["hr", "rr"]:
        raw_out = pd.read_csv(out_dir / f"{vital}_output.csv")
        ref = pd.read_csv(seg / "reference" / f"{vital}_reference.csv")
        evaluated = attach_reference(raw_out, ref)
        evaluated.to_csv(out_dir / f"{vital}_output.csv", index=False)
        result[vital] = metrics(evaluated)
    (out_dir / "metrics.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    return result


def main(dataset_root: Path, output_root: Path, splits: list[str], make_plots: bool):
    build_host_replay()
    manifest = pd.read_csv(dataset_root / "SPLIT_MANIFEST.csv")
    manifest = manifest[manifest["split"].isin(splits)].copy()
    rows = []
    for _, r in manifest.iterrows():
        split = str(r["split"])
        segment = str(r["segment_id"])
        print(f"[{split}] {segment}", flush=True)
        res = run_segment(dataset_root, split, segment, output_root / split / segment)
        q = {"split": split, "segment_id": segment, "domain": r.get("domain", "")}
        for vital in ["hr", "rr"]:
            for k, v in res[vital].items():
                q[f"{vital}_{k}"] = v
        rows.append(q)
    output_root.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output_root / "all_results_summary.csv", index=False)
    if make_plots:
        subprocess.run(
            [
                sys.executable,
                str(ROOT / "scripts" / "plot_results.py"),
                "--dataset-root",
                str(dataset_root),
                "--results-root",
                str(output_root),
                "--fig-root",
                str(output_root / "figures"),
            ],
            check=True,
        )
    print("Finished. Summary:", output_root / "all_results_summary.csv")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(
        description="Authoritative reproduction: compile and run the frozen Full-C LRMAP core on all normalized CSV segments."
    )
    ap.add_argument("--dataset-root", type=Path, default=DEFAULT_DATASET)
    ap.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT)
    ap.add_argument(
        "--splits",
        default="development,holdout,challenge",
        help="Comma-separated subset of development,holdout,challenge",
    )
    ap.add_argument("--no-plots", action="store_true")
    a = ap.parse_args()
    main(
        a.dataset_root,
        a.output_root,
        [x.strip() for x in a.splits.split(",") if x.strip()],
        not a.no_plots,
    )
