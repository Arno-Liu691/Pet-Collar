#!/usr/bin/env python3
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]


def top3(feat: pd.DataFrame) -> pd.DataFrame:
    if feat.empty:
        return feat.copy()
    d = feat.sort_values(["t", "utility"], ascending=[True, False]).copy()
    d["rank"] = d.groupby("t").cumcount() + 1
    return d[d["rank"] <= 3]


def plot_vital(ax, out, feat, ref, title, ylabel):
    # Reference as one shaded range + one center line.
    ax.fill_between(
        ref["time_s"], ref["range_low"], ref["range_high"], alpha=0.16, label="Reference range"
    )
    ax.plot(ref["time_s"], ref["estimate"], lw=1.2, label="Reference")
    # Only top three candidates, visually secondary.
    d = top3(feat)
    markers = {1: "o", 2: "s", 3: "^"}
    for rk in [1, 2, 3]:
        q = d[d["rank"] == rk]
        if len(q):
            ax.scatter(
                q["t"], q["bpm"], s=10, alpha=0.20, marker=markers[rk], label=f"Candidate {rk}"
            )
    tracked_col = "tracked" if "tracked" in out.columns else "tracked_bpm"
    tr = out[tracked_col].copy()
    if "valid" in out.columns:
        tr = tr.where(out["valid"].astype(bool), np.nan)
    ax.plot(out["t"], tr, lw=2.5, label="Tracked output", zorder=4)
    formal = out["formal"].astype(bool)
    if formal.any():
        ax.scatter(
            out.loc[formal, "t"],
            out.loc[formal, tracked_col],
            s=28,
            label="Formal output",
            zorder=5,
        )
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.grid(alpha=0.20)
    ax.legend(loc="upper right", fontsize=8, ncol=2, framealpha=0.9)


def main(dataset_root: Path, results_root: Path, fig_root: Path):
    manifest = pd.read_csv(dataset_root / "SPLIT_MANIFEST.csv")
    fig_root.mkdir(parents=True, exist_ok=True)
    rows = []
    for _, r in manifest.iterrows():
        split = str(r["split"])
        seg = str(r["segment_id"])
        rd = results_root / split / seg
        if not (rd / "hr_output.csv").exists():
            continue
        hr_o = pd.read_csv(rd / "hr_output.csv")
        rr_o = pd.read_csv(rd / "rr_output.csv")
        hr_f = pd.read_csv(rd / "hr_features.csv")
        rr_f = pd.read_csv(rd / "rr_features.csv")
        hr_r = pd.read_csv(dataset_root / split / seg / "reference" / "hr_reference.csv")
        rr_r = pd.read_csv(dataset_root / split / seg / "reference" / "rr_reference.csv")
        od = fig_root / split
        od.mkdir(parents=True, exist_ok=True)
        fig, axs = plt.subplots(2, 1, figsize=(12.6, 8.0), sharex=True)
        plot_vital(axs[0], hr_o, hr_f, hr_r, f"{seg} | {split} | HR", "HR (bpm)")
        plot_vital(axs[1], rr_o, rr_f, rr_r, f"{seg} | {split} | RR", "RR (brpm)")
        axs[1].set_xlabel("Time (s)")
        fig.tight_layout()
        fp = od / f"{seg}.png"
        fig.savefig(fp, dpi=180, bbox_inches="tight")
        plt.close(fig)
        rows.append({"split": split, "segment_id": seg, "figure": str(fp.relative_to(fig_root))})
    pd.DataFrame(rows).to_csv(fig_root / "figure_manifest.csv", index=False)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(
        description="Redraw figures from existing result CSVs only; does not rerun the algorithm."
    )
    ap.add_argument("--dataset-root", type=Path, default=ROOT / "dataset")
    ap.add_argument("--results-root", type=Path, default=ROOT / "results" / "reference")
    ap.add_argument("--fig-root", type=Path, default=ROOT / "results" / "reference" / "figures")
    a = ap.parse_args()
    main(a.dataset_root, a.results_root, a.fig_root)
