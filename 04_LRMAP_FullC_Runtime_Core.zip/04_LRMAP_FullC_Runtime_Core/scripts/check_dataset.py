#!/usr/bin/env python3
import argparse
from pathlib import Path
import pandas as pd

REQ_IN = [
    "sample_index",
    "time_s",
    "acc_x_g",
    "acc_y_g",
    "acc_z_g",
    "gyro_x_dps",
    "gyro_y_dps",
    "gyro_z_dps",
]
REQ_REF = ["time_s", "estimate", "range_low", "range_high", "output_valid", "reference_kind"]
if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--dataset-root", type=Path, default=Path(__file__).resolve().parents[1] / "dataset"
    )
    a = ap.parse_args()
    m = pd.read_csv(a.dataset_root / "SPLIT_MANIFEST.csv")
    ok = True
    for _, r in m.iterrows():
        p = a.dataset_root / str(r["split"]) / str(r["segment_id"])
        d = pd.read_csv(p / "input" / "raw_imu.csv", nrows=2)
        if any(x not in d for x in REQ_IN):
            print("input schema error", p)
            ok = False
        for v in ["hr", "rr"]:
            q = pd.read_csv(p / "reference" / f"{v}_reference.csv", nrows=2)
            if any(x not in q for x in REQ_REF):
                print("reference schema error", p, v)
                ok = False
    print("DATASET_OK" if ok else "DATASET_HAS_ERRORS")
    raise SystemExit(0 if ok else 2)
