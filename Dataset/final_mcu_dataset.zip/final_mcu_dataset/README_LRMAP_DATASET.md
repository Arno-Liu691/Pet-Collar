# LRMAP Development and Evaluation Dataset

This package contains the final dataset used to develop and evaluate the LRMAP heart-rate (HR) and respiratory-rate (RR) estimator described in the thesis.

The package combines selected canine recordings from the public Movement Sensor Dataset with author-recorded human IMU data. All segments are converted to a common CSV structure so that the same LRMAP data-loading and evaluation code can be used across the Development, Holdout and diagnostic Challenge splits.

## Dataset role

The dataset is organised into three splits:

| Split | Canine data | Human data | Purpose |
|---|---|---|---|
| **Development** | D027, D045, D057 and D030; one segment from each dog | Human01, Human03 and Human04 | LRMAP model fitting, parameter selection and optimisation |
| **Holdout** | D046; one segment from an unseen dog | Human02 | Independent evaluation after Development decisions are fixed |
| **Challenge** | Six fragments from D016 and D029 | None | Diagnostic stress cases for branch ranking, recovery, trajectory stability and selective reporting |

The Development and Holdout canine sets contain five segments from five different dogs. The Challenge set contains repeated fragments from two additional dogs and is used for diagnostic analysis rather than the primary aggregate performance estimate.

Across all splits, the package contains 15 segments in total:

- 11 canine segments/fragments;
- 4 human recordings.

## Input used by LRMAP

Each segment contains:

```text
input/raw_imu.csv
```

with the common fields:

- `sample_index`
- `time_s`
- `acc_x_g`
- `acc_y_g`
- `acc_z_g`
- `gyro_x_dps`
- `gyro_y_dps`
- `gyro_z_dps`

The input is six-axis IMU data sampled at 100 Hz.

- Accelerometer values are stored in **g**.
- Gyroscope values are stored in **degrees per second**; the existing CSV column names use the suffix `dps`.
- For canine segments, `source_time_from_test_s` is additionally retained as a provenance column linking the extracted segment to its position in the source recording.

For canine LRMAP inference, the model input is the **Neck six-axis IMU only**. Back IMU data, behavioural context, DogInfo metadata and retrospective evidence were used during offline reference construction and are not runtime LRMAP input features.

For human recordings, the corresponding six-axis chest IMU is used as the estimator input. The independently measured physiological references are retained only for supervision and evaluation.

## Reference files

Each segment contains:

```text
reference/hr_reference.csv
reference/rr_reference.csv
reference/reference_summary.csv
```

The reference tables use the common fields:

- `time_s`
- `estimate`
- `range_low`
- `range_high`
- `output_valid`
- `reference_kind`

### Canine references

The canine reference files contain the final evidence-supported HR/RR reference used in the thesis. These ranges were produced by the offline V6 reference procedure using complementary mechanical evidence from the canine recordings.

The offline reference construction could use information that is not available to the deployed LRMAP estimator, including Neck and Back IMU signals and retrospective evidence. The resulting reference ranges are therefore stored separately from the LRMAP input files.

### Human references

The human recordings have independent physiological references.

For LRMAP evaluation, the accepted tolerance around the human reference is:

- HR: **±5 bpm**
- RR: **±3 brpm**

These values are evaluation tolerances and do not represent physiological population intervals.

## Metadata

Each segment contains:

```text
metadata/segment_metadata.csv
```

The metadata file records the segment identity and the available source information required for traceability. For canine segments, this includes information carried over from the source Movement dataset.

Metadata are provided for provenance and analysis. They are not used as LRMAP runtime input features.

## Directory structure

The package follows the same structure for every segment:

```text
<split>/
└── <segment>/
    ├── input/
    │   └── raw_imu.csv
    ├── reference/
    │   ├── hr_reference.csv
    │   ├── rr_reference.csv
    │   └── reference_summary.csv
    └── metadata/
        └── segment_metadata.csv
```

The exact segment names and split assignments are listed in `SPLIT_MANIFEST.csv`.

## Top-level files

### `SPLIT_MANIFEST.csv`

Records the final Development, Holdout and Challenge allocation for every segment.

Use this file as the authoritative split definition when reproducing LRMAP training or evaluation.

### `COLUMN_MAPPING_AUDIT.csv`

Records the mapping used to convert the original source files into the unified CSV schema.

This file is included for provenance and to make the preprocessing and column conversion traceable.

## Recommended use

For LRMAP reproduction:

1. Read the split assignment from `SPLIT_MANIFEST.csv`.
2. Load `input/raw_imu.csv` as the estimator input.
3. Use the reference files for Development supervision or evaluation according to the assigned split.
4. Use metadata only for traceability, grouping or offline analysis.
5. Do not use reference values, source dog information, Back IMU information or retrospective evidence as runtime LRMAP input features.
6. Keep the Holdout and Challenge data separate from model fitting and threshold selection.

## Split interpretation

- **Development** data are used to fit the pairwise Logistic Regression models, tune estimator parameters and select reporting settings.
- **Holdout** data provide independent evaluation after Development decisions have been made.
- **Challenge** data are diagnostic cases with difficult or ambiguous physiological structure. They are used to examine estimator behaviour and failure mechanisms, not to extend the Development set.

## Relationship to the thesis

The data allocation follows the final LRMAP dataset definition in Chapter 4 of the thesis. The runtime estimator described in Chapter 5 uses only the six-axis IMU input for physiological inference, while the stored reference and metadata files provide supervision, evaluation and provenance.

The canine Development set contains D027, D045, D057 and D030; D046 is reserved as the canine Holdout. Human01, Human03 and Human04 are used in Development, while Human02 is the human Holdout. The six D016/D029 fragments form the diagnostic Challenge set.
